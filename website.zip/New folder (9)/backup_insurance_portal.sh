#!/bin/bash
# ==============================================================================
# backup_insurance_portal.sh
# ------------------------------------------------------------------------------
# Full backup of the Insurance Portal: application files, config, uploaded
# company data folders, and the MySQL database -- all into one timestamped,
# compressed archive per run, with automatic pruning of old backups.
#
# WHAT GETS BACKED UP:
#   1. Application code       -> /u01/data/site/  (excluding venv/ and __pycache__)
#   2. Uploaded company data  -> /u01/data/site/templates/company/
#   3. Site branding config   -> /u01/data/site/site_config.json + static/branding/
#   4. MySQL database         -> full mysqldump of corporate_portal
#
# WHAT'S DELIBERATELY EXCLUDED:
#   - venv/            (rebuildable from `pip install -r requirements.txt`,
#                        and including it would 10x the archive size for no
#                        benefit)
#   - __pycache__/, *.pyc
#
# USAGE:
#   sudo ./backup_insurance_portal.sh
#
# AUTOMATING IT (recommended: daily at 2 AM):
#   sudo crontab -e
#   0 2 * * * /u01/data/site/backup_insurance_portal.sh >> /var/log/portal_backup.log 2>&1
#
# RESTORING:
#   See restore_insurance_portal.sh (companion script) -- extracts the archive
#   and replays the SQL dump. Always test a restore on a spare box periodically;
#   an untested backup is not a backup.
# ==============================================================================

set -euo pipefail  # stop on first error, undefined variable, or failed pipe -- a
                    # backup script that silently half-completes is worse than
                    # one that fails loudly

# --- Configuration -- adjust these to match your environment ----------------
SITE_ROOT="/u01/data/site"                  # application root
DB_NAME="corporate_portal"
DB_USER="admin"
DB_PASSWORD="Admin123"                      # matches get_db_connection() in app.py
                                             # -- move both to a .my.cnf or env
                                             # var once the credentials themselves
                                             # move out of app.py (see security notes)
BACKUP_DEST="/u01/backups"                  # where archives land -- ideally a
                                             # different physical disk/volume
                                             # than SITE_ROOT, so a disk failure
                                             # doesn't take out backups too
RETENTION_DAYS=14                           # how many days of backups to keep

# --- Derived paths -- no need to edit below this line ------------------------
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
WORK_DIR="/tmp/portal_backup_${TIMESTAMP}"
ARCHIVE_NAME="portal_backup_${TIMESTAMP}.tar.gz"
ARCHIVE_PATH="${BACKUP_DEST}/${ARCHIVE_NAME}"
SQL_DUMP_PATH="${WORK_DIR}/corporate_portal.sql"

echo "=============================================="
echo "Insurance Portal Backup -- ${TIMESTAMP}"
echo "=============================================="

mkdir -p "${BACKUP_DEST}"
mkdir -p "${WORK_DIR}"

# --- Step 1: Dump the database -----------------------------------------------
# --single-transaction takes a consistent InnoDB snapshot without locking
# tables for the duration of the dump, so imports/validations running at 2 AM
# (unlikely, but possible) aren't blocked or corrupted by the backup itself.
# --routines/--triggers/--events capture anything beyond plain table data.
echo "[1/3] Dumping MySQL database '${DB_NAME}'..."
mysqldump \
    --user="${DB_USER}" \
    --password="${DB_PASSWORD}" \
    --single-transaction \
    --routines \
    --triggers \
    --events \
    --add-drop-table \
    "${DB_NAME}" > "${SQL_DUMP_PATH}"
echo "      -> $(du -h "${SQL_DUMP_PATH}" | cut -f1) dumped."

# --- Step 2: Copy application files + config ---------------------------------
# rsync (not cp) so we get proper exclusion of venv/__pycache__ without
# needing a second cleanup pass, and it's resumable if interrupted.
echo "[2/3] Copying application files..."
rsync -a \
    --exclude 'venv/' \
    --exclude 'venv.broken/' \
    --exclude '__pycache__/' \
    --exclude '*.pyc' \
    --exclude '*.log' \
    "${SITE_ROOT}/" "${WORK_DIR}/site/"
echo "      -> $(du -sh "${WORK_DIR}/site" | cut -f1) copied."

# --- Step 3: Compress everything into one archive -----------------------------
echo "[3/3] Compressing archive..."
tar -czf "${ARCHIVE_PATH}" -C "${WORK_DIR}" .
ARCHIVE_SIZE=$(du -h "${ARCHIVE_PATH}" | cut -f1)
echo "      -> ${ARCHIVE_PATH} (${ARCHIVE_SIZE})"

# --- Cleanup working directory -----------------------------------------------
rm -rf "${WORK_DIR}"

# --- Prune backups older than RETENTION_DAYS ---------------------------------
echo "Pruning backups older than ${RETENTION_DAYS} days..."
DELETED_COUNT=$(find "${BACKUP_DEST}" -name 'portal_backup_*.tar.gz' -mtime "+${RETENTION_DAYS}" -print -delete | wc -l)
echo "      -> ${DELETED_COUNT} old archive(s) removed."

echo "=============================================="
echo "Backup complete: ${ARCHIVE_PATH} (${ARCHIVE_SIZE})"
echo "=============================================="

# --- Optional: sync to off-box storage ---------------------------------------
# A backup that lives on the same server it's protecting doesn't protect
# against disk failure, ransomware, or "someone did `rm -rf` in the wrong
# terminal". Uncomment and configure ONE of these once you've picked a target:
#
#   # rclone (works with S3, Backblaze B2, Google Drive, etc. -- you already
#   # have /opt/rclone mounted per the VM Resources disk list)
#   # rclone copy "${ARCHIVE_PATH}" remote:insurance-portal-backups/
#
#   # plain rsync to a second server
#   # rsync -a "${ARCHIVE_PATH}" backup-user@backup-host:/backups/portal/
