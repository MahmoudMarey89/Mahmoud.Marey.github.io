#!/bin/bash
# ==============================================================================
# restore_insurance_portal.sh
# ------------------------------------------------------------------------------
# Restores a backup produced by backup_insurance_portal.sh: extracts the
# archive and replays the SQL dump into MySQL.
#
# USAGE:
#   sudo ./restore_insurance_portal.sh /u01/backups/portal_backup_20260705_020000.tar.gz
#
# WHAT THIS DOES NOT DO:
#   It does NOT stop/start the myapp service or touch nginx -- do that
#   yourself before/after, since you may want to restore into a fresh box
#   rather than overwrite a currently-running one. It also does NOT drop the
#   existing database first; the dump uses --add-drop-table so each table
#   is dropped and recreated individually as it's restored, but the database
#   itself must already exist.
# ==============================================================================

set -euo pipefail

if [ $# -ne 1 ]; then
    echo "Usage: $0 <path-to-backup-archive.tar.gz>"
    exit 1
fi

ARCHIVE_PATH="$1"
DB_NAME="corporate_portal"
DB_USER="admin"
DB_PASSWORD="Admin123"
SITE_ROOT="/u01/data/site"

if [ ! -f "${ARCHIVE_PATH}" ]; then
    echo "Error: ${ARCHIVE_PATH} not found."
    exit 1
fi

RESTORE_DIR="/tmp/portal_restore_$(date +%s)"
mkdir -p "${RESTORE_DIR}"

echo "=============================================="
echo "Restoring from: ${ARCHIVE_PATH}"
echo "=============================================="

echo "[1/3] Extracting archive..."
tar -xzf "${ARCHIVE_PATH}" -C "${RESTORE_DIR}"

echo "[2/3] Restoring database '${DB_NAME}'..."
echo "      This will DROP AND RECREATE every table in the dump."
read -p "      Type 'yes' to continue: " CONFIRM
if [ "${CONFIRM}" != "yes" ]; then
    echo "Aborted."
    rm -rf "${RESTORE_DIR}"
    exit 1
fi
mysql --user="${DB_USER}" --password="${DB_PASSWORD}" "${DB_NAME}" < "${RESTORE_DIR}/corporate_portal.sql"
echo "      -> Database restored."

echo "[3/3] Application files extracted to: ${RESTORE_DIR}/site"
echo "      Review the diff before overwriting the live app, e.g.:"
echo "         diff -rq ${RESTORE_DIR}/site ${SITE_ROOT}"
echo "      Then, once you're satisfied:"
echo "         sudo systemctl stop myapp"
echo "         rsync -a --delete ${RESTORE_DIR}/site/ ${SITE_ROOT}/ --exclude venv/"
echo "         sudo systemctl start myapp"

echo "=============================================="
echo "Restore staged at ${RESTORE_DIR} -- nothing live has been touched yet"
echo "except the database (confirmed above)."
echo "=============================================="
