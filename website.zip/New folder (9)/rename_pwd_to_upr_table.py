"""
One-off migration: renames the pwd_calculations table to upr_calculations.

Run once from the site root (same place you run the other add_*_table.py
migrations), e.g.:

    python3 rename_pwd_to_upr_table.py

Safe to re-run: if pwd_calculations no longer exists (already renamed) it
does nothing. If upr_calculations already exists, it aborts rather than
silently overwriting/losing data -- check things manually in that case.
"""
from app import get_db_connection  # reuses the exact same DB config app.py uses


def table_exists(cursor, table_name):
    cursor.execute(
        """SELECT COUNT(*) AS cnt FROM information_schema.TABLES
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s""",
        (table_name,)
    )
    return cursor.fetchone()['cnt'] > 0


def main():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            old_exists = table_exists(cursor, 'pwd_calculations')
            new_exists = table_exists(cursor, 'upr_calculations')

            if new_exists:
                print("upr_calculations already exists -- nothing to do (aborting to avoid data loss).")
                return

            if not old_exists:
                print("pwd_calculations not found -- nothing to rename.")
                return

            cursor.execute("RENAME TABLE pwd_calculations TO upr_calculations")
        conn.commit()
        print("Renamed pwd_calculations -> upr_calculations successfully.")
    finally:
        conn.close()


if __name__ == '__main__':
    main()
