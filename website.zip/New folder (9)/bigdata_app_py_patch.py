# =============================================================================
# PATCH FOR app.py -- Big-Data Bulk Import pipeline
#
# Same convention as app_py_patch.py: this is NOT a standalone module. Paste
# these blocks into your real app.py at the noted locations. Nothing here
# touches the existing save_validation_file / validate_stream /
# import_to_database routes -- the small-file flow keeps working exactly as
# it does today. This adds a second, parallel path for big files:
#
#   Overview / Data Validation page -> "Bulk Import (large files)" button
#     -> GET/POST /<company_slug>/bulk-import   (upload N files, creates a job)
#     -> GET      /<company_slug>/bulk-import/<job_id>          (status page)
#     -> GET      /<company_slug>/bulk-import/<job_id>/status   (JSON, polled)
#     -> GET      /<company_slug>/bulk-import/<job_id>/errors   (download error report)
#
# The actual file processing happens in bigdata_worker.py, a separate
# long-running process (see bigdata_worker.service) -- these routes only
# ever touch import_jobs / import_job_files rows and staged files on disk;
# they return in well under a second regardless of job size.
#
# Requires migrations/add_bigdata_pipeline.py to have been run first.
# =============================================================================


# -----------------------------------------------------------------------------
# 1) IMPORT -- add near the top of app.py, with your other imports
# -----------------------------------------------------------------------------
from validation_core import EXPECTED_HEADERS as BULK_EXPECTED_HEADERS  # noqa: F401 (kept for template use)


# -----------------------------------------------------------------------------
# 2) CONSTANTS -- add near COMPANY_DATA_ROOT / VALIDATION_DATA_TYPES
# -----------------------------------------------------------------------------
BULK_STAGING_UPLOAD_ROOT = '/u01/data/site/bulk_import_uploads'
os.makedirs(BULK_STAGING_UPLOAD_ROOT, exist_ok=True)

# Excel's own hard ceiling is 1,048,576 rows/sheet; this is set comfortably
# below that so pandas/openpyxl always have header-row + margin to spare, and
# so files stay a manageable size to re-upload/retry individually.
BULK_MAX_ROWS_PER_FILE_HINT = 1_000_000


# -----------------------------------------------------------------------------
# 3) ROUTES -- add anywhere near the existing save_validation_file /
#    validate_stream routes
# -----------------------------------------------------------------------------
@app.route('/<company_slug>/bulk-import', methods=['GET', 'POST'])
@require_company_access
def bulk_import(company_slug):
    """
    Entry point for the big-data path: accepts MULTIPLE Excel/CSV files in
    one submission (each individually under Excel's ~1M row/sheet limit),
    stages them to disk, and creates one `import_jobs` row + one
    `import_job_files` row per file -- all with status='queued'.

    Does NOT validate or import anything itself -- bigdata_worker.py (a
    separate process) picks the job up within POLL_INTERVAL_SECONDS and does
    the actual work, so this request returns almost immediately no matter
    how many files or how large they are.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    if request.method == 'GET':
        return render_template(
            'company/bulk-import.html',
            company=comp,
            components=VALIDATION_DATA_TYPES,
        )

    component = request.form.get('component')
    year = request.form.get('year')
    period = (request.form.get('period') or 'ALL').upper()

    if not component:
        flash("No validation data type selected.", "error")
        return redirect(url_for('bulk_import', company_slug=company_slug))

    try:
        target_year = int(year)
    except (ValueError, TypeError):
        flash("Invalid year selected.", "error")
        return redirect(url_for('bulk_import', company_slug=company_slug))

    files = request.files.getlist('excel_files')
    files = [f for f in files if f and f.filename]
    if not files:
        flash("No files selected. Choose one or more files (each under ~1M rows).", "error")
        return redirect(url_for('bulk_import', company_slug=company_slug))

    for f in files:
        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in ('.xlsx', '.xls', '.csv'):
            flash(f"Unsupported file type: {f.filename}. Use .xlsx, .xls or .csv.", "error")
            return redirect(url_for('bulk_import', company_slug=company_slug))

    dest_dir = os.path.join(BULK_STAGING_UPLOAD_ROOT, company_slug, component, str(target_year))
    os.makedirs(dest_dir, exist_ok=True)

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """INSERT INTO import_jobs
                   (company_id, component_name, data_year, period, status, total_files, created_by)
                   VALUES (%s, %s, %s, %s, 'queued', %s, %s)""",
                (comp['id'], component, target_year, period, len(files), session['user_id'])
            )
            job_id = cursor.lastrowid

            for idx, f in enumerate(files):
                timestamp_tag = datetime.now().strftime('%Y%m%d_%H%M%S%f')
                ext = os.path.splitext(f.filename)[1].lower()
                saved_filename = f"job{job_id}_{idx:04d}_{timestamp_tag}{ext}"
                saved_path = os.path.join(dest_dir, saved_filename)
                f.save(saved_path)
                cursor.execute(
                    """INSERT INTO import_job_files
                       (job_id, file_index, original_filename, staged_path)
                       VALUES (%s, %s, %s, %s)""",
                    (job_id, idx, f.filename, saved_path)
                )
        conn.commit()
    except Exception as e:
        conn.rollback()
        flash(f"Could not create the import job: {str(e)}", "error")
        return redirect(url_for('bulk_import', company_slug=company_slug))
    finally:
        conn.close()

    log_action(
        session['user_id'], 'BULK_IMPORT_QUEUED',
        f"Queued bulk import job #{job_id} for {component} ({target_year}, {period}): {len(files)} file(s)",
        comp['id'], component
    )
    flash(f"Import job #{job_id} queued with {len(files)} file(s). Processing runs in the background.", "success")
    return redirect(url_for('bulk_import_status_page', company_slug=company_slug, job_id=job_id))


@app.route('/<company_slug>/bulk-import/<int:job_id>')
@require_company_access
def bulk_import_status_page(company_slug, job_id):
    """Renders the polling page -- the page itself just calls the JSON
    status endpoint below every few seconds via fetch()."""
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))
    return render_template('company/bulk-import-status.html', company=comp, job_id=job_id)


@app.route('/<company_slug>/bulk-import/<int:job_id>/status')
@require_company_access
def bulk_import_status(company_slug, job_id):
    """JSON progress endpoint, polled by bulk-import-status.html. Cheap: one
    indexed SELECT by primary key, no matter how large the job is."""
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"error": "Company not found"}), 404

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT * FROM import_jobs WHERE id = %s AND company_id = %s",
                (job_id, comp['id'])
            )
            job = cursor.fetchone()
            if not job:
                return jsonify({"error": "Job not found"}), 404

            cursor.execute(
                """SELECT original_filename, status, rows_in_file, rows_valid, rows_invalid, error_message
                   FROM import_job_files WHERE job_id = %s ORDER BY file_index""",
                (job_id,)
            )
            files = cursor.fetchall()
    finally:
        conn.close()

    return jsonify({
        "job_id": job['id'],
        "status": job['status'],
        "total_files": job['total_files'],
        "files_done": job['files_done'],
        "rows_processed": job['rows_processed'],
        "rows_valid": job['rows_valid'],
        "rows_invalid": job['rows_invalid'],
        "current_file_name": job['current_file_name'],
        "error_message": job['error_message'],
        "has_error_report": bool(job['error_report_path']),
        "created_at": str(job['created_at']),
        "started_at": str(job['started_at']) if job['started_at'] else None,
        "finished_at": str(job['finished_at']) if job['finished_at'] else None,
        "files": files,
    })


@app.route('/<company_slug>/bulk-import/<int:job_id>/errors')
@require_company_access
def bulk_import_errors(company_slug, job_id):
    """Downloads the capped error-report file bigdata_worker.py wrote
    (JSON-lines: one {"row": N, "details": "..."} per invalid row, capped at
    ERROR_SAMPLE_CAP rows -- rows_invalid on the job is the exact total even
    past that cap)."""
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT error_report_path FROM import_jobs WHERE id = %s AND company_id = %s",
                (job_id, comp['id'])
            )
            row = cursor.fetchone()
    finally:
        conn.close()

    if not row or not row['error_report_path'] or not os.path.exists(row['error_report_path']):
        flash("No error report available for this job.", "error")
        return redirect(url_for('bulk_import_status_page', company_slug=company_slug, job_id=job_id))

    return send_file(row['error_report_path'], as_attachment=True,
                      download_name=f"import_job_{job_id}_errors.jsonl")


# -----------------------------------------------------------------------------
# 4) NAV LINK -- add a "Bulk Import (large files)" link/button next to the
#    existing "Data Validation" entry in company_sider.html, pointing at:
#    url_for('bulk_import', company_slug=company['slug'])
# -----------------------------------------------------------------------------
