"""
add_bigdata_pipeline.py
------------------------
One-time migration for the big-data (20M-100M row) import pipeline.

Adds:
  1. `import_jobs`       -- one row per bulk-import batch (a set of staged
                             Excel/CSV files uploaded together), tracked
                             asynchronously by bigdata_worker.py.
  2. `import_job_files`  -- one row per staged file within a job.
  3. Typed, indexed columns on `company_data` -- populated by the new bulk
     pipeline (LOAD DATA INFILE) so Dashboard/Overview-style aggregation can
     run as SQL SUM()/COUNT()/GROUP BY instead of pulling every JSON row_data
     blob into Python. `row_data` is left in place and still populated, so
     every existing route (Dashboard, Exports, KPIs) keeps working exactly
     as before -- this is purely additive.

Safe to run more than once: checks INFORMATION_SCHEMA first.

Usage:
    python3 add_bigdata_pipeline.py

Uses the same connection settings as add_performance_indexes.py / app.py's
get_db_connection(). Edit the CONNECTION block below if your credentials
differ.
"""
import pymysql

CONNECTION = dict(
    host='localhost',
    user='admin',
    password='Admin123',
    database='corporate_portal',
    cursorclass=pymysql.cursors.DictCursor,
)


def table_exists(cursor, table):
    cursor.execute(
        """SELECT COUNT(*) AS cnt FROM information_schema.tables
           WHERE table_schema = DATABASE() AND table_name = %s""",
        (table,)
    )
    return cursor.fetchone()['cnt'] > 0


def column_exists(cursor, table, column):
    cursor.execute(
        """SELECT COUNT(*) AS cnt FROM information_schema.columns
           WHERE table_schema = DATABASE() AND table_name = %s AND column_name = %s""",
        (table, column)
    )
    return cursor.fetchone()['cnt'] > 0


def index_exists(cursor, table, index_name):
    cursor.execute(
        """SELECT COUNT(*) AS cnt FROM information_schema.statistics
           WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s""",
        (table, index_name)
    )
    return cursor.fetchone()['cnt'] > 0


CREATE_IMPORT_JOBS = """
CREATE TABLE `import_jobs` (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    company_id          INT NOT NULL,
    component_name      VARCHAR(100) NOT NULL,
    data_year           INT NOT NULL,
    period              VARCHAR(10) NOT NULL DEFAULT 'ALL',
    -- queued: waiting for the worker; running: worker has claimed it;
    -- done: every file processed; error: worker hit an unrecoverable
    -- problem (see error_message); cancelled: user-cancelled before pickup.
    status              ENUM('queued','running','done','error','cancelled') NOT NULL DEFAULT 'queued',
    total_files         INT NOT NULL DEFAULT 0,
    files_done          INT NOT NULL DEFAULT 0,
    rows_processed      BIGINT NOT NULL DEFAULT 0,
    rows_valid          BIGINT NOT NULL DEFAULT 0,
    rows_invalid        BIGINT NOT NULL DEFAULT 0,
    current_file_name   VARCHAR(255) NULL,
    error_message       TEXT NULL,
    error_report_path   VARCHAR(500) NULL,
    created_by          INT NOT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    started_at          DATETIME NULL,
    finished_at         DATETIME NULL,
    INDEX idx_import_jobs_status (status),
    INDEX idx_import_jobs_company (company_id, component_name, data_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""

CREATE_IMPORT_JOB_FILES = """
CREATE TABLE `import_job_files` (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    job_id          INT NOT NULL,
    file_index      INT NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    staged_path     VARCHAR(500) NOT NULL,
    status          ENUM('pending','processing','done','error') NOT NULL DEFAULT 'pending',
    rows_in_file    BIGINT NOT NULL DEFAULT 0,
    rows_valid      BIGINT NOT NULL DEFAULT 0,
    rows_invalid    BIGINT NOT NULL DEFAULT 0,
    error_message   TEXT NULL,
    FOREIGN KEY (job_id) REFERENCES import_jobs(id) ON DELETE CASCADE,
    INDEX idx_import_job_files_job (job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
"""

# Typed columns added to company_data. All nullable so the existing
# small-file import_to_database() path (which doesn't populate these) keeps
# working unmodified -- rows it writes simply have NULLs here and are still
# read normally via row_data by every existing route.
COMPANY_DATA_NEW_COLUMNS = [
    ("policy_number",           "VARCHAR(100) NULL"),
    ("issue_date",              "DATE NULL"),
    ("lob_detailed",            "VARCHAR(50) NULL"),
    ("gross_ri",                "VARCHAR(10) NULL"),
    ("gross_premium_amount",    "DECIMAL(18,3) NULL"),
    ("ri_premium_amount",       "DECIMAL(18,3) NULL"),
    ("financial_year_quarter",  "VARCHAR(10) NULL"),
]

COMPANY_DATA_NEW_INDEXES = [
    ("idx_company_data_bulk_issue_date", ["company_id", "component_name", "data_year", "issue_date"]),
    ("idx_company_data_bulk_lob",        ["company_id", "component_name", "data_year", "lob_detailed"]),
]


def main():
    conn = pymysql.connect(**CONNECTION)
    try:
        with conn.cursor() as cursor:
            if table_exists(cursor, 'import_jobs'):
                print("[skip]   import_jobs already exists")
            else:
                print("[create] import_jobs")
                cursor.execute(CREATE_IMPORT_JOBS)

            if table_exists(cursor, 'import_job_files'):
                print("[skip]   import_job_files already exists")
            else:
                print("[create] import_job_files")
                cursor.execute(CREATE_IMPORT_JOB_FILES)

            for col_name, col_def in COMPANY_DATA_NEW_COLUMNS:
                if column_exists(cursor, 'company_data', col_name):
                    print(f"[skip]   company_data.{col_name} already exists")
                    continue
                sql = f"ALTER TABLE `company_data` ADD COLUMN `{col_name}` {col_def}"
                print(f"[create] {sql}")
                cursor.execute(sql)

            for index_name, columns in COMPANY_DATA_NEW_INDEXES:
                if index_exists(cursor, 'company_data', index_name):
                    print(f"[skip]   company_data.{index_name} already exists")
                    continue
                col_list = ", ".join(f"`{c}`" for c in columns)
                sql = f"ALTER TABLE `company_data` ADD INDEX `{index_name}` ({col_list})"
                print(f"[create] {sql}")
                cursor.execute(sql)

        conn.commit()
        print("\nDone. Big-data pipeline schema is in place.")
        print(
            "\nReminder: LOAD DATA INFILE (used by bigdata_worker.py) needs "
            "local_infile enabled on both the server and the client connection:\n"
            "  - Server: add `local_infile=1` under [mysqld] in my.cnf and restart, "
            "or run `SET GLOBAL local_infile = 1;`\n"
            "  - Client: bigdata_worker.py already passes local_infile=True to "
            "pymysql.connect() -- no action needed there."
        )
    finally:
        conn.close()


if __name__ == '__main__':
    main()
