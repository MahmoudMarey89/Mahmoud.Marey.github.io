# IFRS 17 Validation — Streaming Fix (real root cause)

## What actually changed since the last patch

The session-cookie fix was real and needed, but it wasn't sufficient — your
follow-up test (same 450K-row file working in Custom, failing in IFRS17)
confirmed the real cause: **IFRS17 validation ran as one single, fully
synchronous HTTP request that produces zero output until the entire file is
validated.** Custom validation avoids this by splitting into two requests —
a fast "save the file" step, then a separate streaming (SSE) step that
emits progress continuously while it works. IFRS17 never had that split, so
a large/slow-to-validate file could sit silently past whatever timeout your
Nginx/gunicorn is configured with, which is what "Operation failed" was
actually reporting (a 502/504 from the proxy layer, not a code exception).

This delivery ports IFRS17 validation to that same two-step streaming
pattern.

## Files in this delivery

Both are **complete replacement files** (not diffs/patches) — this touches
enough different places that a snippet patch was getting error-prone to
apply by hand. Back up your current `app.py` and
`templates/company/data-validation-ifrs17.html`, then replace them
with these.

| File | Replaces |
|---|---|
| `app.py` | `/u01/data/site/app.py` |
| `data-validation-ifrs17.html` | `templates/company/data-validation-ifrs17.html` |

`ifrs17_engine.py` is **unchanged** — nothing in the column rules themselves
needed to change, only how/when they run.

## What's different, concretely

1. **`save_validation_file_ifrs17`** (new route) — Step 3's file upload now
   saves the file to `/tmp` and returns immediately (just a disk write),
   regardless of file size.
2. **`validate_ifrs17_stream`** (new route, replaces the old blocking
   `validate_ifrs17` as the active path) — validates in 50,000-row chunks
   (`IFRS17_STREAM_CHUNK_ROWS`), emitting an SSE progress message after each
   chunk. For a 450K-row file that's roughly every 1–2 seconds based on
   throughput measured in this session — the connection is never silent
   for long, so there's nothing for a proxy timeout to trip on.
3. **Ready-file pickup hook**, added to `company_validation_ifrs17`'s `GET`
   handler — a streaming response can't set session cookies mid-stream
   (Flask fixes the `Set-Cookie` header before the generator body runs), so
   the stream writes its finished result to a small file on disk instead;
   this hook picks that file up on the very next page load and moves it
   into the session normally, then deletes it. This is what lets the
   existing server-rendered results section (pass/fail badge, preview
   table, reconciliation numbers) keep working completely unchanged.
4. **Old `validate_ifrs17` (POST) route left in place, unused** — still has
   last session's fix (disk-staged payload + chunked `executemany`), so
   nothing breaks if anything still points at it, but the template no
   longer uses it.
5. **Template**: Step 3's "Run Validation" button now does upload → SSE
   progress → reload, instead of upload-and-wait. The progress bar shows
   real row counts (`Validated 150,000 of 450,000 row(s)…`) instead of the
   old fake time-based animation.

## Verified before sending

- `app.py` parses cleanly (`ast.parse`).
- The modified template renders cleanly through Jinja in both the empty
  and populated-report states (mock-rendered with all referenced routes
  registered).
- The actual chunked validation loop (`validate_ifrs17_dataframe` called
  per 50,000-row chunk) was run end-to-end against a synthetic 220,000-row
  dataset built to the real `Gross Premium Data` schema — completed in
  ~9 seconds, emitting a progress point roughly every 2 seconds.

**Not verified**: against your live server/Nginx/gunicorn, or your actual
450,000-row file — I don't have access to either from this sandbox. Please
test with that exact file once deployed.

## One thing still worth watching

`import_ifrs17_to_database` (the "Import to Production DB" step after a
passing validation) is still a single synchronous POST — now using chunked
`executemany` (fast), but still one request. If imports of very large
passing datasets ever start timing out the same way validation did, the fix
is the same shape: split it into a stage step + SSE/polling step. Flag it
if you see that happen; I didn't port it preemptively since chunked
`executemany` alone is usually fast enough to stay well under typical
timeouts for datasets in the hundreds of thousands of rows.
