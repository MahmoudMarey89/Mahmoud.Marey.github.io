import os
import re
import json
import time
import pymysql
import threading
import pandas as pd
from datetime import datetime
from functools import wraps
from flask import (
    Flask, render_template, request, redirect, url_for, session, flash,
    send_file, send_from_directory, abort, Response, stream_with_context, jsonify
)
from ifrs17_engine import (
    IFRS17_SHEET_SCHEMAS, IFRS17_DATA_TYPES,
    read_ifrs17_upload_dataframe, validate_ifrs17_dataframe, TOTAL_AMOUNT_COLUMNS,
    AMOUNT_GROUP_COLUMNS, AMOUNT_GROUP_LABELS, VALID_LOBS,
    IFRS17_UPR_FIELD_MAP, mapping_is_complete, remap_uploaded_headers,
    lob_mapping_is_complete, remap_lob_values,
)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    # Site Administration -> VM Resources degrades to a clear error message
    # instead of crashing the whole app if psutil isn't installed yet.
    PSUTIL_AVAILABLE = False


app = Flask(__name__)
# the content 500 --> Byte * 1024 --> KB * 1024 --> MB * 1024 --> GB
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024 * 1024
app.config.from_object('config.Config')

# CSRF protection on every state-changing (POST/PUT/DELETE) request. Forms
# get a hidden csrf_token() field; the two JS fetch()-based POSTs (Fulfil
# Data, and any others added later) send it back via the X-CSRFToken header
# instead, read client-side from the same hidden meta tag every page now
# renders (see base template comments).
csrf = CSRFProtect(app)

# Login rate limiting: without this, nothing stopped repeated password
# guessing against /login. 5 attempts/minute per IP is generous enough for a
# real user who mistypes a password twice, but makes brute-forcing
# impractical. Applied to POST only (see the @limiter.limit(...) on login()
# itself) -- scoping it to POST, not GET, matters: without that, every page
# load/refresh of the login form would burn from the same budget as actual
# submit attempts, and a handful of reloads while troubleshooting could
# trigger 429 before a single real login was even attempted. storage_uri
# defaults to in-memory, which is fine for a single-process deployment; move
# to Redis if this ever runs multiple worker processes, since in-memory
# counters aren't shared across them.
limiter = Limiter(app=app, key_func=get_remote_address, default_limits=[])

UPLOAD_FOLDER = '/u01/data/site/uploaded'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

SITE_GROUP_NAME = 'site-group'

# Data categories offered in the "View validation data" wizard on the Overview page.
# NOTE: these names are also used as the per-company subfolder names on disk
# (see COMPANY_DATA_ROOT below), so the two lists must always stay in sync.
VALIDATION_DATA_TYPES = ['Claim - Paid', 'Claim - OCR', 'Premium', 'Balance Data Temp']

# Quarter/all-year selectable periods for the validation wizard.
VALIDATION_PERIODS = ['ALL', 'Q1', 'Q2', 'Q3', 'Q4']

# --- Per-company folder tree -------------------------------------------------
# Every company gets its own folder here, pre-populated with one subfolder per
# validation data type, e.g. /u01/data/site/templates/company/Al_Ahly/Premium/
COMPANY_DATA_ROOT = '/u01/data/site/templates/company'
COMPANY_SUBFOLDERS = ['Claim - Paid', 'Claim - OCR', 'Premium', 'Balance Data Temp']


def create_company_folder_tree(slug):
    """Creates <COMPANY_DATA_ROOT>/<slug>/<subfolder> for every
    VALIDATION_DATA_TYPES entry (Custom Validation), plus
    <COMPANY_DATA_ROOT>/<slug>/IFRS17/<sheet type> for every IFRS17 sheet
    type -- for BOTH new companies (called at creation time) and, via the
    one-off migration snippet below, existing ones."""
    company_dir = os.path.join(COMPANY_DATA_ROOT, slug)
    for sub in COMPANY_SUBFOLDERS:
        os.makedirs(os.path.join(company_dir, sub), exist_ok=True)
    for sheet in IFRS17_DATA_TYPES:
        os.makedirs(os.path.join(company_dir, 'IFRS17', sheet), exist_ok=True)
    return company_dir

def backfill_ifrs17_folders():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT slug FROM companies")
            slugs = [r['slug'] for r in cursor.fetchall()]
    finally:
        conn.close()
    for slug in slugs:
        create_company_folder_tree(slug)
    print(f"Backfilled IFRS17 folders for {len(slugs)} companies.")

### ---- Define a Background Thread Task Helper ---- ###
def _escape_load_data_field(value):
    """Escapes one field for a LOAD DATA LOCAL INFILE staging line
    (FIELDS TERMINATED BY '\\t' ESCAPED BY '\\\\' LINES TERMINATED BY '\\n').
    Same escaping bigdata_worker.py already uses for its own staging files --
    kept identical here so both import paths behave the same way."""
    if value is None:
        return ''
    s = str(value)
    return s.replace('\\', '\\\\').replace('\t', '\\t').replace('\n', '\\n').replace('\r', '\\r')


def _insert_company_data_in_batches(conn, company_id, component_name, data_year, payload, user_id, is_ifrs17):
    """The original row-by-row-safe import method (multi-row INSERT in
    chunks of 5,000) -- kept as the fallback for servers where `local_infile`
    isn't enabled, since LOAD DATA LOCAL INFILE is a server-side setting this
    app can't turn on for itself (see add_bigdata_pipeline.py's deployment
    notes). Slower than the bulk-load path below, but works everywhere."""
    with conn.cursor() as cursor:
        INSERT_CHUNK_SIZE = 5000
        for start in range(0, len(payload), INSERT_CHUNK_SIZE):
            chunk = payload[start:start + INSERT_CHUNK_SIZE]
            if is_ifrs17:
                placeholders = ", ".join(["(%s, %s, %s, %s, %s, NOW())"] * len(chunk))
                sql = f"INSERT INTO company_data (company_id, component_name, data_year, row_data, uploaded_by, created_at) VALUES {placeholders}"
            else:
                placeholders = ", ".join(["(%s, %s, %s, %s, %s)"] * len(chunk))
                sql = f"INSERT INTO company_data (company_id, component_name, data_year, row_data, uploaded_by) VALUES {placeholders}"
            flat_params = []
            for record in chunk:
                flat_params.extend([company_id, component_name, data_year, json.dumps(record, default=str), user_id])
            cursor.execute(sql, flat_params)
    conn.commit()


def _bulk_load_company_data(company_id, component_name, data_year, payload, user_id):
    """
    Writes payload to a tab-delimited staging file and loads it with ONE
    `LOAD DATA LOCAL INFILE` statement instead of many `INSERT` round-trips.
    This is the same technique bigdata_worker.py already uses (proven design,
    just reused here for the regular Data Validation -> Import flow instead
    of the separate bulk-import job queue) -- typically 10-50x faster than
    batched INSERTs since MySQL reads the whole file server-side in one pass
    rather than parsing a SQL statement per batch over the network.

    Requires the server to have `local_infile=1` set (see
    add_bigdata_pipeline.py's deployment notes) -- raises on failure so the
    caller can fall back to the INSERT-batching method instead.
    """
    staging_path = f"/tmp/import_stage_{company_id}_{os.getpid()}_{int(time.time() * 1000)}.tsv"
    with open(staging_path, 'w', encoding='utf-8') as f:
        for record in payload:
            row_data_json = json.dumps(record, default=str)
            fields = [company_id, component_name, data_year, row_data_json, user_id]
            f.write('\t'.join(_escape_load_data_field(x) for x in fields) + '\n')

    conn = get_db_connection(local_infile=True)
    try:
        safe_path = staging_path.replace('\\', '\\\\').replace("'", "\\'")
        with conn.cursor() as cursor:
            sql = f"""
                LOAD DATA LOCAL INFILE '{safe_path}'
                INTO TABLE company_data
                FIELDS TERMINATED BY '\\t' ESCAPED BY '\\\\'
                LINES TERMINATED BY '\\n'
                (company_id, component_name, data_year, row_data, uploaded_by)
                SET created_at = NOW()
            """
            cursor.execute(sql)
        conn.commit()
    finally:
        conn.close()
        try:
            os.remove(staging_path)
        except OSError:
            pass


def run_import_in_background(company_id, component_name, data_year, payload, user_id, is_ifrs17=False):
    """
    Executes the database import safely inside a background thread
    without blocking the main Flask web server. Tries the fast bulk-load
    path first (LOAD DATA LOCAL INFILE); if that fails for any reason --
    most likely `local_infile` not being enabled on this MySQL server yet --
    falls back to the slower but universally-compatible batched-INSERT
    method rather than losing the import.
    """
    try:
        _bulk_load_company_data(company_id, component_name, data_year, payload, user_id)
    except Exception as bulk_err:
        print(f"LOAD DATA LOCAL INFILE import failed ({bulk_err}); falling back to batched INSERT. "
              f"See add_company_data_index.py / add_bigdata_pipeline.py notes on enabling local_infile "
              f"for the fast path.")
        conn = get_db_connection()
        try:
            _insert_company_data_in_batches(conn, company_id, component_name, data_year, payload, user_id, is_ifrs17)
        except Exception as e:
            conn.rollback()
            print(f"CRITICAL BACKGROUND IMPORT ERROR: {str(e)}")
            return
        finally:
            conn.close()

    action_type = 'IFRS17_IMPORT' if is_ifrs17 else 'IMPORT'
    log_action(
        user_id,
        action_type,
        f"Background import completed successfully for {len(payload)} row(s) in {component_name} ({data_year}).",
        company_id,
        component_name
    )

# --- Client-facing upload area ("overview-client.html") ---------------------
# Files the 'client' role user uploads themselves (not run through the
# analyst validation/import pipeline) land in a dedicated "Client uploaded"
# folder, e.g. /u01/data/site/templates/company/GIG/Client uploaded/Total
# Amount Sheet/. The folder tree here is created lazily on first upload, not
# at company creation time, since not every company necessarily has a client
# user.
CLIENT_UPLOAD_ROOT_NAME = 'Client uploaded'
CLIENT_UPLOAD_CATEGORIES = {
    'total_amount': 'Total Amount Sheet',
    'detailed_data': 'Detailed Data',
    'validation_errors': 'Validation Errors'
}
# Categories the client role itself may upload into. 'validation_errors' is
# staff-only -- it's how an admin sends a flagged/corrected sheet back to the
# client, not something the client populates themselves.
CLIENT_UPLOADABLE_CATEGORIES = {'total_amount', 'detailed_data'}
ALLOWED_CLIENT_UPLOAD_EXTENSIONS = {'.csv', '.xlsx', '.xls'}
VALID_USER_ROLES = {'user', 'admin', 'client'}


def format_file_size(size_bytes):
    """Human-readable size -- KB under 1 MB, MB above, matching how the rest
    of the app already displays sizes (see database_overview's data_mb)."""
    if size_bytes >= 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    return f"{size_bytes / 1024:.1f} KB"


def get_client_upload_dir(company_slug, category):
    """Resolves (and creates, if missing) the folder a given upload category
    for this company lives in. Returns None for an unrecognised category."""
    subfolder = CLIENT_UPLOAD_CATEGORIES.get(category)
    if not subfolder:
        return None
    path = os.path.join(COMPANY_DATA_ROOT, company_slug, CLIENT_UPLOAD_ROOT_NAME, subfolder)
    os.makedirs(path, exist_ok=True)
    return path


def list_client_uploads(company_slug):
    """Lists every file the client (and, for validation_errors, staff) has
    uploaded for this company, across all categories, newest first. Includes
    both a raw size_kb (kept for backward compatibility) and a human-
    readable size_display (KB under 1 MB, MB above)."""
    results = []
    for category, subfolder in CLIENT_UPLOAD_CATEGORIES.items():
        folder = os.path.join(COMPANY_DATA_ROOT, company_slug, CLIENT_UPLOAD_ROOT_NAME, subfolder)
        if not os.path.isdir(folder):
            continue
        for fname in os.listdir(folder):
            fpath = os.path.join(folder, fname)
            if not os.path.isfile(fpath):
                continue
            stat = os.stat(fpath)
            results.append({
                "category": category,
                "category_label": subfolder,
                "name": fname,
                "size_kb": round(stat.st_size / 1024, 1),
                "size_display": format_file_size(stat.st_size),
                "uploaded_at": datetime.fromtimestamp(stat.st_mtime).strftime('%d/%m/%Y %H:%M'),
                "uploaded_at_sort": stat.st_mtime
            })
    results.sort(key=lambda r: r["uploaded_at_sort"], reverse=True)
    for r in results:
        del r["uploaded_at_sort"]
    return results


# --- Notifications: alerts site admins when a client uploads a new file -----
# Requires the `notifications` table -- see migrations/add_notifications_table.py.
def create_upload_notification(company_id, company_name, category, filename):
    """Writes one unread notification row so site admins see a bell badge
    the next time they open Site Administration. Fails soft, same reasoning
    as log_action: a notification failing to write should never block the
    client's upload from succeeding."""
    category_label = CLIENT_UPLOAD_CATEGORIES.get(category, category)
    message = f"New file uploaded for {company_name}: {filename} ({category_label})"
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO notifications (company_id, category, filename, message, is_read)
                VALUES (%s, %s, %s, %s, 0)
            """, (company_id, category, filename, message))
        conn.commit()
    except Exception as e:
        print(f"Notification write error: {e}")
    finally:
        conn.close()


def get_notifications(unread_only=False, limit=50):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = """
                SELECT n.id, n.company_id, c.name AS company_name, n.category,
                       n.filename, n.message, n.is_read, n.created_at
                FROM notifications n
                LEFT JOIN companies c ON c.id = n.company_id
            """
            if unread_only:
                sql += " WHERE n.is_read = 0"
            sql += " ORDER BY n.created_at DESC LIMIT %s"
            cursor.execute(sql, (limit,))
            return cursor.fetchall()
    finally:
        conn.close()


def get_unread_notification_count(company_id=None):
    """Fails soft (returns 0) if the notifications table doesn't exist yet --
    e.g. migrations/add_notifications_table.py hasn't been run on this
    environment -- so a missing migration degrades the bell to 'no badge'
    instead of breaking the whole Site Administration page load.

    Pass company_id to get the count scoped to one company (used by the
    per-company sidebar badge, so each company's "Client Portal" link shows
    only its own unread count instead of the site-wide total)."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            if company_id is not None:
                cursor.execute(
                    "SELECT COUNT(*) AS c FROM notifications WHERE is_read = 0 AND company_id = %s",
                    (company_id,)
                )
            else:
                cursor.execute("SELECT COUNT(*) AS c FROM notifications WHERE is_read = 0")
            return cursor.fetchone()['c']
    except Exception:
        return 0
    finally:
        conn.close()


def mark_company_notifications_read(company_id):
    """Marks this company's unread notifications as read -- called once
    staff actually download an uploaded file, so the per-company badge
    clears once the file has been reviewed rather than staying stuck at
    the count from whenever the client uploaded it. Fails soft: a failed
    mark-read should never break the download itself."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "UPDATE notifications SET is_read = 1 WHERE is_read = 0 AND company_id = %s",
                (company_id,)
            )
        conn.commit()
    except Exception as e:
        print(f"Notification mark-read error: {e}")
    finally:
        conn.close()


# --- Client <-> staff chat on the client-overview page -----------------------
# Requires the `client_chat_messages` table -- see
# migrations/add_client_chat_table.py. One shared thread per company: the
# client role sees it as "chat with your account manager", staff (admin/user
# with access to that company) see it as "chat with this client".
def get_chat_messages(company_id, since_id=0):
    """Full history (since_id=0) or only messages newer than since_id, for
    polling. Fails soft with an empty list if the table doesn't exist yet."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT id, sender_role, sender_username, message, created_at
                FROM client_chat_messages
                WHERE company_id = %s AND id > %s
                ORDER BY id ASC
            """, (company_id, since_id))
            rows = cursor.fetchall()
    except Exception:
        return []
    finally:
        conn.close()

    for r in rows:
        r['created_at'] = r['created_at'].strftime('%d/%m/%Y %H:%M') if r['created_at'] else None
    return rows


def add_chat_message(company_id, sender_role, sender_username, message):
    """Returns the new row's id, or None if the insert failed (e.g. the
    client_chat_messages table doesn't exist yet -- see
    migrations/add_client_chat_table.py). Deliberately fails soft rather
    than raising: an uncaught exception here previously bubbled up as an
    unhandled 500 HTML error page, which broke JSON parsing on the frontend
    and surfaced as a generic, misleading 'Network error' alert instead of
    a real error message."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO client_chat_messages (company_id, sender_role, sender_username, message)
                VALUES (%s, %s, %s, %s)
            """, (company_id, sender_role, sender_username, message))
            conn.commit()
            return cursor.lastrowid
    except Exception as e:
        print(f"Chat message insert error: {e}")
        return None
    finally:
        conn.close()


# --- Site branding (logo) config --------------------------------------------
SITE_CONFIG_PATH = '/u01/data/site/site_config.json'
LOGO_UPLOAD_DIR = os.path.join(app.static_folder or 'static', 'branding')
os.makedirs(LOGO_UPLOAD_DIR, exist_ok=True)
ALLOWED_LOGO_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.svg', '.webp', '.gif'}


def load_site_config():
    """Reads site_config.json (currently just {'logo_filename': ...}).
    Missing file or corrupt JSON both quietly fall back to an empty dict
    rather than raising -- site branding is cosmetic, never worth a 500."""
    try:
        with open(SITE_CONFIG_PATH, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_site_config(cfg):
    """Overwrites site_config.json wholesale with the given dict."""
    os.makedirs(os.path.dirname(SITE_CONFIG_PATH), exist_ok=True)
    with open(SITE_CONFIG_PATH, 'w') as f:
        json.dump(cfg, f)


def get_site_logo_url():
    """Resolves the current logo to a static URL, or None if no logo is set
    or the configured file has gone missing from disk."""
    cfg = load_site_config()
    logo_filename = cfg.get('logo_filename')
    if logo_filename and os.path.exists(os.path.join(LOGO_UPLOAD_DIR, logo_filename)):
        return url_for('static', filename=f'branding/{logo_filename}')
    return None


@app.context_processor
def inject_site_branding():
    """Makes site_logo_url available to every template without passing it manually."""
    return {'site_logo_url': get_site_logo_url()}

# The canonical column schema for uploaded/stored insurance rows. Shared by the
# upload validator, the Dashboard table, and every export route so they never drift.
EXPECTED_HEADERS = [
    "Policy Number", "Issue Date", "Written Date", "Period From", "Period to",
    "Premium/Commission Due Date", "LOB Detailed", "Gross_RI", "RI Treaty Type",
    "GROSS Premium Amount (EGP)", "GROSS Commission Amount (EGP)",
    "RI Premium Amount (EGP)", "RI Commission Amount (EGP)",
    "Financial Year Quarter", "source_file", "source_page"
]
LOB_VALID_WORDS = ["MARINE_CARGO", "MOTOR_COMPREHENSIVE", "FIRE", "ENGINEERING",
                    "GENERAL_ACCIDENT", "CREDIT", "MARINE_INLAND", "MEDICAL",
                    "MOTOR_TPL", "AVIATION", "MARINE_HULL", "OIL", "TRAVEL_POOL", "TPL_POOL"]
GROSS_RI_WORDS = ["GROSS", "RI"]

# The real control-totals workbook has a "DATA" sheet shaped like:
# Data Type | year | All the year | Q1 | Q2 | Q3 | Q4 -- one row per
# (Data Type, year) pair. "Fulfil Data" looks up the single row/column that
# matches whatever Data Type / Year / Period is currently selected for this
# validation session.
CONTROL_TOTALS_HEADERS = ["Data Type", "year", "All the year", "Q1", "Q2", "Q3", "Q4"]
CONTROL_TOTALS_HEADERS_NORMALIZED = [h.strip().lower() for h in CONTROL_TOTALS_HEADERS]
CONTROL_TOTALS_PERIOD_COLUMNS = {
    'ALL': 'all the year',
    'Q1': 'q1', 'Q2': 'q2', 'Q3': 'q3', 'Q4': 'q4',
}

@app.context_processor
def inject_notifications():
    """Makes unread notification count available to every template.

    Shown to any staff viewer (role != 'client') -- this badge lives on the
    "Client Portal" link inside the per-company sidebar (company_sider.html),
    not just the global Site Administration page, so it must not be gated
    behind site-group membership (is_site_admin). A company-level 'admin' or
    'user' who isn't in the site-group otherwise always got 0 here, which is
    why the badge never appeared for them.

    Scoped to the company currently being viewed (via the company_slug URL
    argument), so each company's sidebar shows only its own unread count
    instead of the site-wide total across every company."""
    if session.get('user_id') and session.get('role') != 'client':
        company_slug = request.view_args.get('company_slug') if request.view_args else None
        try:
            if company_slug:
                comp = get_company_context(company_slug)
                count = get_unread_notification_count(comp['id']) if comp else 0
            else:
                # Not on a company-scoped page (e.g. welcome/site-management) --
                # no single company to scope to, so no badge to show here.
                count = 0
        except Exception:
            count = 0
        return {'unread_notifications': count}

    # Clients (and logged-out requests) get a default of 0
    return {'unread_notifications': 0}

def generate_slug(name):
    """
    Company slug = company name with every run of non-alphanumeric characters
    (spaces, punctuation, etc.) collapsed into a single underscore. Case is kept
    as typed so slug and name read as 'the same name'.
    e.g. "Al Ahly Insurance" -> "Al_Ahly_Insurance"
    """
    slug = re.sub(r'[^A-Za-z0-9]+', '_', name.strip())
    return slug.strip('_')


def compute_period_dates(year, period):
    """
    Server-side source of truth for the period range tied to a given year + period code.
    Mirrors the JS calculation on the Overview page so a tampered/absent query string
    can't produce a mismatched period.
    """
    period = (period or 'ALL').upper()
    try:
        y = int(year)
    except (TypeError, ValueError):
        return None, None

    ranges = {
        'ALL': (f"{y}-01-01", f"{y}-12-31"),
        'Q1':  (f"{y}-01-01", f"{y}-03-31"),
        'Q2':  (f"{y}-04-01", f"{y}-06-30"),
        'Q3':  (f"{y}-07-01", f"{y}-09-30"),
        'Q4':  (f"{y}-10-01", f"{y}-12-31"),
    }
    return ranges.get(period, ranges['ALL'])


def parse_ddmmyyyy_or_iso(value):
    """Parses a date typed/picked as either dd/mm/yyyy (how every other date
    in this app is displayed) or the browser <input type=date> ISO format
    (yyyy-mm-dd) -- the IFRS17 Fulfil Data calendar picker sends the latter.
    Returns a datetime.date, or None if unparseable."""
    value = (value or '').strip()
    if not value:
        return None
    for fmt in ('%Y-%m-%d', '%d/%m/%Y'):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    return None



# --- Database Core Connection Engine ---
def get_db_connection(local_infile=False):
    """
    Opens a new MySQL connection for a single request/route to use and close.
    No connection pooling -- each call to this function is a fresh TCP
    connection, closed via conn.close() in a `finally` block by the caller.
    Returns rows as dicts (DictCursor) rather than tuples, so route code can
    do row['column_name'] instead of tracking positional indexes.

    local_infile=True is only needed by the bulk-import path (LOAD DATA
    LOCAL INFILE) -- every other caller uses the default False, unchanged
    from before this parameter existed.
    """
    return pymysql.connect(
        host=app.config['DB_HOST'],
        user=app.config['DB_USER'],
        password=app.config['DB_PASSWORD'],
        database=app.config['DB_NAME'],
        cursorclass=pymysql.cursors.DictCursor,
        local_infile=local_infile,
    )


def ensure_upr_calculations_table(conn):
    with conn.cursor() as cursor:
        cursor.execute(
            """SELECT TABLE_NAME
               FROM information_schema.TABLES
               WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME IN ('upr_calculations', 'pwd_calculations')"""
        )
        existing_tables = {row['TABLE_NAME'] for row in cursor.fetchall()}

        if 'upr_calculations' in existing_tables:
            return

        if 'pwd_calculations' in existing_tables:
            cursor.execute("RENAME TABLE pwd_calculations TO upr_calculations")
            conn.commit()
            return

        cursor.execute(
            """CREATE TABLE IF NOT EXISTS `upr_calculations` (
                `row_id` INT NOT NULL,
                `company_id` INT NOT NULL,
                `component_name` VARCHAR(255) NOT NULL,
                `data_year` VARCHAR(10) NOT NULL,
                `quarter` VARCHAR(10) NOT NULL,
                `quarter_end_date` DATE NOT NULL,
                `exposure_days` INT NULL,
                `unearned_exposure_days` INT NULL,
                `earned_premium` DECIMAL(18,3) NULL,
                `unearned_premium` DECIMAL(18,3) NULL,
                `calculated_by` INT NULL,
                `calculated_at` DATETIME NOT NULL,
                PRIMARY KEY (`row_id`),
                CONSTRAINT `fk_upr_calc_company_data`
                    FOREIGN KEY (`row_id`) REFERENCES `company_data` (`id`)
                    ON DELETE CASCADE,
                INDEX `idx_upr_calc_lookup`
                    (`company_id`, `component_name`, `data_year`, `quarter`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
        )
    conn.commit()


# --- Global Activity Logging Audit Helper ---
def log_action(user_id, action_type, description, company_id=None, component_name=None):
    """
    Writes one row to history_log -- the audit trail shown on each company's
    History Log page and included in the Database Overview tab. Called
    throughout the app after logins, imports, exports, and admin actions
    (user/group/company create-edit-delete).

    Deliberately fails soft: if the INSERT itself errors for any reason
    (e.g. a transient DB hiccup), this prints to the server log and returns
    normally rather than raising -- a failed audit-log write should never be
    the reason a real user-facing action (like a successful import) appears
    to fail.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = """INSERT INTO history_log (user_id, action_type, description, company_id, component_name)
                     VALUES (%s, %s, %s, %s, %s)"""
            cursor.execute(sql, (user_id, action_type, description, company_id, component_name))
        conn.commit()
    except Exception as e:
        print(f"Logging error encountered: {e}")
    finally:
        conn.close()


# =====================================================================
# --- Stored Data Access Helpers (Dashboard + Overview stats + Export) ---
# =====================================================================

def parse_row_data(raw):
    """row_data comes back from MySQL as either a JSON string or an already-decoded dict."""
    if isinstance(raw, dict):
        return raw
    try:
        return json.loads(raw)
    except (TypeError, ValueError):
        return {}


_CLEAN_DATE_RE = re.compile(r'^\d{2}/\d{2}/\d{4}$')
_CLEAN_AMOUNT_RE = re.compile(r'^-?\d+\.\d{3}$')


def derive_quarter(written_date_value):
    """Q1-Q4 derived from the row's Written Date month. Returns 'Unknown' if unparseable."""
    if not written_date_value:
        return 'Unknown'
    try:
        # Fast path: value is already a clean dd/mm/yyyy string (true for
        # everything normalised by normalize_display_fields already, which
        # runs before this is called) -- skip pandas' much slower general
        # date parser entirely.
        s = str(written_date_value)
        if _CLEAN_DATE_RE.match(s):
            month = int(s[3:5])
        else:
            month = pd.to_datetime(written_date_value, dayfirst=True).month

        if month <= 3:
            return 'Q1'
        if month <= 6:
            return 'Q2'
        if month <= 9:
            return 'Q3'
        return 'Q4'
    except Exception:
        return 'Unknown'


def to_float(value):
    """Best-effort numeric coercion for premium/commission amounts read back
    from row_data -- empty string, None, or anything unparseable becomes
    0.0 rather than raising, since these feed straight into SUM()-style
    aggregation in compute_company_stats where a crash would be worse than
    treating a bad value as zero."""
    try:
        if value in (None, ''):
            return 0.0
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _parse_ddmmyyyy(value):
    """Parses a dd/mm/yyyy string (the display format normalize_display_fields
    always produces for Period From / Period to) into a date. Returns None
    for anything empty or unparseable rather than raising -- UPR Calculation
    skips computing metrics for rows it can't parse instead of crashing the
    whole Search."""
    if not value:
        return None
    try:
        return datetime.strptime(str(value), '%d/%m/%Y').date()
    except (TypeError, ValueError):
        return None


def compute_upr_metrics(period_from_raw, period_to_raw, gross_premium_raw, quarter_end_date):
    """
    UPR Calculation tab -- computes the four derived columns for a single
    company_data row, evaluated against a fixed quarter-end date (the last
    date of whichever Data Type/Year/Quarter was searched):

      Exposure            = Period to - Period From, in days
      unEarned Exposure    = min(Exposure, max(0, Period to - quarter_end_date))
      unEarned Premium     = 0 if Exposure == 0, else
                             (unEarned Exposure / Exposure) * GROSS Premium Amount
      Earned Premium       = GROSS Premium Amount - unEarned Premium

    Rows whose Period From/Period to can't be parsed return all-None metrics
    so they still show up in the table (with blank calculated columns)
    instead of silently disappearing from the result set.
    """
    period_from = _parse_ddmmyyyy(period_from_raw)
    period_to = _parse_ddmmyyyy(period_to_raw)
    if period_from is None or period_to is None:
        return {
            'exposure_days': None,
            'unearned_exposure_days': None,
            'earned_premium': None,
            'unearned_premium': None,
        }

    exposure_days = (period_to - period_from).days
    remaining_days = (period_to - quarter_end_date).days
    unearned_exposure_days = min(exposure_days, max(0, remaining_days))

    gross_premium = to_float(gross_premium_raw)

    if exposure_days == 0:
        unearned_premium = 0.0
    else:
        unearned_premium = (unearned_exposure_days / exposure_days) * gross_premium

    earned_premium = gross_premium - unearned_premium

    return {
        'exposure_days': exposure_days,
        'unearned_exposure_days': unearned_exposure_days,
        'earned_premium': round(earned_premium, 3),
        'unearned_premium': round(unearned_premium, 3),
    }


# Columns that should always display as dd/mm/yyyy (no time-of-day component)
# and columns that should always display rounded to 3 decimal places.
# Applied at *read* time in fetch_company_records so this fixes both new
# imports and any older rows that were saved before that formatting existed.
DATE_DISPLAY_FIELDS = list(dict.fromkeys([
    "Issue Date", "Written Date", "Period From", "Period to",
    "Premium/Commission Due Date",
] + [
    field_map[field]
    for field_map in IFRS17_UPR_FIELD_MAP.values()
    for field in ("period_from", "period_to", "quarter_date")
]))
AMOUNT_DISPLAY_FIELDS = list(dict.fromkeys([
    "GROSS Premium Amount (EGP)", "GROSS Commission Amount (EGP)",
    "RI Premium Amount (EGP)", "RI Commission Amount (EGP)",
] + [field_map["amount"] for field_map in IFRS17_UPR_FIELD_MAP.values()]))


def normalize_display_fields(fields):
    """
    Normalises a row_data dict for display: dates become dd/mm/yyyy strings
    (any hh:mm:ss component is dropped) and monetary amounts become plain
    strings rounded to exactly 3 decimal places. Values that can't be parsed
    are left untouched rather than raising, so odd/legacy data doesn't crash
    the page -- it just won't get reformatted.

    Fast paths skip the (comparatively expensive) pandas/float parsing for
    values that are already in the target format -- true for the vast
    majority of rows once data has gone through the fixed import pipeline,
    which matters a lot when this runs once per field per row across
    thousands of saved records on every Dashboard load.
    """
    cleaned = dict(fields)

    for col in DATE_DISPLAY_FIELDS:
        val = cleaned.get(col)
        if val in (None, ''):
            continue
        if _CLEAN_DATE_RE.match(str(val)):
            continue  # already dd/mm/yyyy, nothing to do
        try:
            cleaned[col] = pd.to_datetime(val, dayfirst=True).strftime('%d/%m/%Y')
        except Exception:
            pass

    for col in AMOUNT_DISPLAY_FIELDS:
        val = cleaned.get(col)
        if val in (None, ''):
            continue
        if _CLEAN_AMOUNT_RE.match(str(val)):
            continue  # already rounded to 3 decimals, nothing to do
        try:
            cleaned[col] = f"{round(float(val), 3):.3f}"
        except (TypeError, ValueError):
            pass

    return cleaned


def count_company_records(company_id, component_name, year=None):
    """
    Lightweight COUNT(*) for one component_name (and optionally one year) --
    used to warn before an import rather than pulling/parsing every row via
    fetch_company_records() just to get a number.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = "SELECT COUNT(*) AS cnt FROM company_data WHERE company_id = %s AND component_name = %s"
            params = [company_id, component_name]
            if year:
                sql += " AND data_year = %s"
                params.append(year)
            cursor.execute(sql, tuple(params))
            row = cursor.fetchone()
            return row['cnt'] if row else 0
    finally:
        conn.close()


def fetch_company_records(company_id, data_type=None, year=None, component_names=None):
    """
    Flattens company_data rows (JSON row_data blob) into a list of plain dicts,
    each carrying the original EXPECTED_HEADERS fields plus db metadata and a
    derived 'quarter'. Used by the Dashboard table, exports, and Overview stats.

    component_names: optional list to scope results to one "framework" (e.g.
    only VALIDATION_DATA_TYPES for Custom, or only IFRS17_DATA_TYPES for
    IFRS 17) via a component_name IN (...) clause -- so the Custom and IFRS 17
    dashboards never pull each other's rows, even when no specific data_type
    filter is selected. Independent of the single data_type filter below,
    which still narrows further to one exact type when set.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            sql = """SELECT id, component_name, data_year, row_data, uploaded_by, created_at
                      FROM company_data WHERE company_id = %s"""
            params = [company_id]
            if component_names:
                placeholders = ", ".join(["%s"] * len(component_names))
                sql += f" AND component_name IN ({placeholders})"
                params.extend(component_names)
            if data_type:
                sql += " AND component_name = %s"
                params.append(data_type)
            if year:
                sql += " AND data_year = %s"
                params.append(year)
            sql += " ORDER BY id DESC"
            cursor.execute(sql, tuple(params))
            db_rows = cursor.fetchall()
    finally:
        conn.close()

    records = []
    for db_row in db_rows:
        fields = parse_row_data(db_row.get('row_data'))
        fields = normalize_display_fields(fields)
        record = {
            'db_id': db_row.get('id'),
            'component_name': db_row.get('component_name'),
            'data_year': db_row.get('data_year'),
            'uploaded_by': db_row.get('uploaded_by'),
            'created_at': db_row.get('created_at'),
            'quarter': derive_quarter(fields.get('Written Date')),
        }
        record.update(fields)
        records.append(record)
    return records


def _quarter_sql_expr_for_column(date_column_name):
    """SQL expression evaluating to 'Q1'-'Q4' or 'Unknown', derived from
    row_data JSON's `date_column_name` field the same way derive_quarter()
    does in Python (dd/mm/yyyy fast path -- characters 4-5 are the month).
    Generalized version of what used to be hardcoded to "Written Date" --
    IFRS17's UPR calculation derives its quarter from a different column per
    sheet type (see IFRS17_UPR_FIELD_MAP's quarter_date), so this takes the
    column name as a parameter instead."""
    date_expr = f'JSON_UNQUOTE(JSON_EXTRACT(row_data, \'$."{date_column_name}"\'))'
    return f"""
        CASE WHEN {date_expr} REGEXP '^[0-9]{{2}}/[0-9]{{2}}/[0-9]{{4}}$'
             THEN ELT(CEIL(CAST(SUBSTRING({date_expr}, 4, 2) AS UNSIGNED) / 3), 'Q1', 'Q2', 'Q3', 'Q4')
             ELSE 'Unknown'
        END
    """


def _written_date_quarter_sql_expr():
    """Written-Date-specific convenience wrapper -- compute_overview_dashboard()
    and fetch_company_records_page() both derive quarter from "Written Date"
    specifically, unlike UPR's per-sheet-type quarter_date column."""
    return _quarter_sql_expr_for_column('Written Date')


def _year_sql_expr_for_column(date_column_name):
    """Companion to _quarter_sql_expr_for_column() -- the real content year
    (not the stored data_year import-time label) for a single named date
    column. See _ifrs17_row_year_sql_expr()'s docstring for why content
    year and the stored label can disagree."""
    date_expr = f'JSON_UNQUOTE(JSON_EXTRACT(row_data, \'$."{date_column_name}"\'))'
    return f"""
        CASE WHEN {date_expr} REGEXP '^[0-9]{{2}}/[0-9]{{2}}/[0-9]{{4}}$'
             THEN SUBSTRING({date_expr}, 7, 4)
             ELSE NULL
        END
    """


def fetch_company_records_by_quarter(company_id, data_type, year, quarter_column, quarter):
    """
    Like fetch_company_records(), but ALSO pushes the quarter filter into
    SQL (via quarter_column, since IFRS17 UPR derives quarter from a
    different date field per sheet type -- see IFRS17_UPR_FIELD_MAP) instead
    of fetching every row for the whole data_type+year and filtering by
    quarter in Python afterward. Used by build_ifrs17_upr_results(), which
    otherwise pulled and JSON-parsed every row for the entire year just to
    keep the ~1/4 (at most) that fall in the requested quarter.

    Also filters "year" by the row's real content year (same quarter_column,
    via _year_sql_expr_for_column()) rather than the stored data_year
    column -- data_year is only an import-time label (see
    _ifrs17_row_year_sql_expr()'s docstring) and can disagree with what a
    row's own date field actually says, which was silently excluding
    legitimate rows from UPR results.
    """
    quarter_expr = _quarter_sql_expr_for_column(quarter_column)
    year_expr = _year_sql_expr_for_column(quarter_column)
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                f"""SELECT id, component_name, data_year, row_data, uploaded_by, created_at
                    FROM company_data
                    WHERE company_id = %s AND component_name = %s
                      AND ({year_expr}) = %s
                      AND ({quarter_expr}) = %s
                    ORDER BY id DESC""",
                (company_id, data_type, str(year), quarter)
            )
            db_rows = cursor.fetchall()
    finally:
        conn.close()

    records = []
    for db_row in db_rows:
        fields = parse_row_data(db_row.get('row_data'))
        fields = normalize_display_fields(fields)
        record = {
            'db_id': db_row.get('id'),
            'component_name': db_row.get('component_name'),
            'data_year': db_row.get('data_year'),
            'uploaded_by': db_row.get('uploaded_by'),
            'created_at': db_row.get('created_at'),
            'quarter': derive_quarter(fields.get('Written Date')),
        }
        record.update(fields)
        records.append(record)
    return records


def _ifrs17_row_date_case_sql():
    """Shared CASE fragment: picks the right date column for a row's own
    sheet type (component_name), per IFRS17_UPR_FIELD_MAP's quarter_date --
    used by both the quarter expression below and the year expression that
    follows, so they always agree on which date each row's period is based
    on."""
    case_parts = []
    for sheet_type, field_map in IFRS17_UPR_FIELD_MAP.items():
        date_col = field_map['quarter_date']
        escaped_sheet_type = sheet_type.replace("'", "''")
        date_expr = f'JSON_UNQUOTE(JSON_EXTRACT(row_data, \'$."{date_col}"\'))'
        case_parts.append(f"WHEN component_name = '{escaped_sheet_type}' THEN {date_expr}")
    return "CASE " + " ".join(case_parts) + " ELSE NULL END"


def _ifrs17_row_quarter_sql_expr():
    """
    SQL expression deriving quarter for an IFRS17 row using the CORRECT date
    column for THAT row's own sheet type (component_name) -- e.g. Issue Date
    for Gross Premium Data, Policy Issue Date for Gross Claims Data, RI
    Treaty Issue Date for the RI sheets -- via IFRS17_UPR_FIELD_MAP's
    quarter_date, instead of a single hardcoded column.

    Necessary because, unlike Custom Validation's one flat schema, each
    IFRS17 sheet type defines its own quarter-determining date field, and
    Dashboard IFRS17 can show several sheet types in the same table (when no
    Data Type filter is applied) -- using "Written Date" for all of them
    (what this used to do, copied from the Custom-only original) silently
    dropped rows from a quarter filter whenever that row's Written Date
    didn't happen to agree with its real (Issue-Date-based, etc.) quarter,
    even though the row genuinely belonged in the requested quarter.
    """
    date_case_sql = _ifrs17_row_date_case_sql()
    return f"""
        CASE WHEN ({date_case_sql}) REGEXP '^[0-9]{{2}}/[0-9]{{2}}/[0-9]{{4}}$'
             THEN ELT(CEIL(CAST(SUBSTRING(({date_case_sql}), 4, 2) AS UNSIGNED) / 3), 'Q1', 'Q2', 'Q3', 'Q4')
             ELSE 'Unknown'
        END
    """


def _ifrs17_row_year_sql_expr():
    """
    SQL expression deriving the REAL content year for an IFRS17 row -- from
    the same per-sheet-type date column as the quarter expression above
    (Issue Date, Policy Issue Date, RI Treaty Issue Date, etc.) -- rather
    than the stored `data_year` column.

    This matters because `data_year` is a LABEL applied at import time
    (derived from Step 4's From date -- see save_validation_file_ifrs17()),
    not necessarily the calendar year the row's own data actually falls in.
    A file validated with a From/To period that includes, say, a few rows
    whose real Issue Date lands in a different calendar year than the From
    date still gets every one of those rows tagged with the SAME data_year
    label. Filtering Dashboard/UPR by the stored label then silently drops
    rows whose real content year doesn't match that label, even though they
    plainly belong when you look at their actual Issue Date -- which is
    exactly the discrepancy between the raw database view and Dashboard/UPR
    reported. Deriving "year" from content here instead keeps what's shown
    consistent with what's actually IN the row, not how it happened to be
    labeled at import time.
    """
    date_case_sql = _ifrs17_row_date_case_sql()
    return f"""
        CASE WHEN ({date_case_sql}) REGEXP '^[0-9]{{2}}/[0-9]{{2}}/[0-9]{{4}}$'
             THEN SUBSTRING(({date_case_sql}), 7, 4)
             ELSE NULL
        END
    """


def fetch_company_records_page(company_id, component_names=None, data_type=None, year=None,
                                quarter=None, search=None, page=1, page_size=200,
                                quarter_sql_expr=None, quarter_display_field=None, year_sql_expr=None):
    """
    Paginated counterpart to fetch_company_records(), built for the Dashboard
    table. The old company_dashboard()/company_dashboard_ifrs17() pulled
    EVERY matching row (already filtered by data_type/year in SQL, but not
    by quarter/search) into Python, JSON-parsed every one of them, THEN
    filtered by quarter/search and sliced out one page -- for a company with
    millions of matching rows, that's still millions of JSON blobs fetched
    and parsed just to show `page_size` of them. This function instead
    pushes quarter (via the same JSON_EXTRACT-based expression used in
    compute_overview_dashboard) and Policy Number search (via a JSON_EXTRACT
    + LIKE) down into the SQL WHERE clause too, and does the row count and
    the LIMIT/OFFSET slicing in SQL -- so only `page_size` rows are ever
    fetched into Python and JSON-parsed, regardless of the company's total
    row count.

    quarter_sql_expr/quarter_display_field let a caller override what
    "quarter" means -- Custom Validation (the default) always uses "Written
    Date"; company_dashboard_ifrs17() passes IFRS17-aware versions instead
    (see _ifrs17_row_quarter_sql_expr()), since each IFRS17 sheet type
    derives its quarter from a different date column. year_sql_expr is the
    same idea for "year" -- when provided, filters by the row's real content
    year (derived the same way) instead of the stored data_year column,
    which is only an import-time label (see _ifrs17_row_year_sql_expr()'s
    docstring for why those two can disagree).

    Returns (page_records, total_count, page, total_pages) -- page is
    clamped into [1, total_pages] the same way the old in-Python version was.
    """
    quarter_expr = quarter_sql_expr() if quarter_sql_expr else _written_date_quarter_sql_expr()
    quarter_display_field = quarter_display_field or 'Written Date'
    policy_expr = 'JSON_UNQUOTE(JSON_EXTRACT(row_data, \'$."Policy Number"\'))'

    where_clauses = ["company_id = %s"]
    params = [company_id]
    if component_names:
        placeholders = ", ".join(["%s"] * len(component_names))
        where_clauses.append(f"component_name IN ({placeholders})")
        params.extend(component_names)
    if data_type:
        where_clauses.append("component_name = %s")
        params.append(data_type)
    if year:
        if year_sql_expr:
            where_clauses.append(f"({year_sql_expr()}) = %s")
        else:
            where_clauses.append("data_year = %s")
        params.append(year)
    if quarter and quarter != 'ALL':
        where_clauses.append(f"({quarter_expr}) = %s")
        params.append(quarter)
    if search:
        where_clauses.append(f"{policy_expr} LIKE %s")
        params.append(f"%{search}%")
    where_sql = " AND ".join(where_clauses)

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(f"SELECT COUNT(*) AS cnt FROM company_data WHERE {where_sql}", tuple(params))
            total_count = cursor.fetchone()['cnt']

            page = max(1, page)
            total_pages = max(1, (total_count + page_size - 1) // page_size)
            page = min(page, total_pages)
            offset = (page - 1) * page_size

            cursor.execute(
                f"""SELECT id, component_name, data_year, row_data, uploaded_by, created_at
                    FROM company_data WHERE {where_sql}
                    ORDER BY id DESC LIMIT %s OFFSET %s""",
                tuple(params) + (page_size, offset)
            )
            db_rows = cursor.fetchall()
    finally:
        conn.close()

    records = []
    for db_row in db_rows:
        fields = parse_row_data(db_row.get('row_data'))
        fields = normalize_display_fields(fields)
        # The right display column varies per row (component_name) for
        # IFRS17 -- resolved here per-row via IFRS17_UPR_FIELD_MAP whenever
        # this row's component_name is a known IFRS17 sheet type, falling
        # back to quarter_display_field (Custom's fixed "Written Date")
        # otherwise. Purely cosmetic (the WHERE clause above already
        # determined which rows matched), but keeps the visible Quarter
        # column consistent with why each row was actually included.
        display_field = IFRS17_UPR_FIELD_MAP.get(db_row.get('component_name'), {}).get(
            'quarter_date', quarter_display_field
        )
        record = {
            'db_id': db_row.get('id'),
            'component_name': db_row.get('component_name'),
            'data_year': db_row.get('data_year'),
            'uploaded_by': db_row.get('uploaded_by'),
            'created_at': db_row.get('created_at'),
            'quarter': derive_quarter(fields.get(display_field)),
        }
        record.update(fields)
        records.append(record)

    return records, total_count, page, total_pages


def compute_company_stats(company_id):
    """Aggregates saved company_data into per-year and overall summary numbers for Overview."""
    records = fetch_company_records(company_id)

    by_year = {}
    overall_quarters = {'Q1': 0, 'Q2': 0, 'Q3': 0, 'Q4': 0, 'Unknown': 0}
    overall_gross = 0.0
    overall_ri = 0.0
    overall_policies = set()

    for r in records:
        year_key = r.get('data_year') or 'Unknown'
        bucket = by_year.setdefault(year_key, {
            'records': 0,
            'policies': set(),
            'quarters': {'Q1': 0, 'Q2': 0, 'Q3': 0, 'Q4': 0, 'Unknown': 0},
            'gross_total': 0.0,
            'ri_total': 0.0,
        })

        bucket['records'] += 1
        policy_no = r.get('Policy Number')
        if policy_no:
            bucket['policies'].add(policy_no)
            overall_policies.add(policy_no)

        q = r.get('quarter', 'Unknown')
        bucket['quarters'][q] = bucket['quarters'].get(q, 0) + 1
        overall_quarters[q] = overall_quarters.get(q, 0) + 1

        gross_val = to_float(r.get('GROSS Premium Amount (EGP)'))
        ri_val = to_float(r.get('RI Premium Amount (EGP)'))
        bucket['gross_total'] += gross_val
        bucket['ri_total'] += ri_val
        overall_gross += gross_val
        overall_ri += ri_val

    by_year_list = []
    for year_key, bucket in sorted(by_year.items(), key=lambda kv: str(kv[0]), reverse=True):
        by_year_list.append({
            'year': year_key,
            'records': bucket['records'],
            'policies': len(bucket['policies']),
            'quarters': bucket['quarters'],
            'gross_total': round(bucket['gross_total'], 2),
            'ri_total': round(bucket['ri_total'], 2),
        })

    return {
        'by_year': by_year_list,
        'total_records': len(records),
        'total_policies': len(overall_policies),
        'quarter_counts': overall_quarters,
        'total_gross': round(overall_gross, 2),
        'total_ri': round(overall_ri, 2),
    }


def format_compact_amount(value):
    """Jinja filter: abbreviates a raw EGP amount for KPI cards, e.g.
    2_350_000_000 -> '2.35 B', 974_950_000 -> '974.95 M', 82_200 -> '82.20 K'.
    Falls back to a plain 2-decimal string below 1,000."""
    try:
        value = float(value or 0)
    except (TypeError, ValueError):
        return '0.00'
    sign = '-' if value < 0 else ''
    value = abs(value)
    if value >= 1_000_000_000:
        return f"{sign}{value / 1_000_000_000:.2f} B"
    if value >= 1_000_000:
        return f"{sign}{value / 1_000_000:.2f} M"
    if value >= 1_000:
        return f"{sign}{value / 1_000:.2f} K"
    return f"{sign}{value:.2f}"


app.jinja_env.filters['compact_amount'] = format_compact_amount


# Data types that feed the Overview dashboard's Revenue/Claims KPIs. Claim -
# OCR and Balance Data Temp are informational-only categories in this
# schema and deliberately don't participate in Net Revenue/Net Claims --
# only Premium and Claim - Paid represent actual booked money movements.
OVERVIEW_REVENUE_TYPE = 'Premium'
OVERVIEW_CLAIMS_TYPE = 'Claim - Paid'
OVERVIEW_QUARTER_ORDER = {'Q1': 1, 'Q2': 2, 'Q3': 3, 'Q4': 4}


def _json_amount_sql_expr(column_name):
    """SQL fragment: the row_data JSON's `column_name` field, cast to a
    number if it looks like one, else 0 -- mirrors to_float()'s forgiving
    behavior (anything unparseable becomes 0 rather than erroring or
    producing a MySQL truncation warning). Shared by compute_overview_dashboard()
    and company_overview_ifrs17() so both aggregate amounts the same way."""
    path = f'$."{column_name}"'
    extracted = f"JSON_UNQUOTE(JSON_EXTRACT(row_data, '{path}'))"
    return (
        f"CASE WHEN {extracted} REGEXP '^-?[0-9]+(\\\\.[0-9]+)?$' "
        f"THEN CAST({extracted} AS DECIMAL(20,4)) ELSE 0 END"
    )


def compute_overview_dashboard(company_id, year_filter=None, quarter_filter=None, data_type_filter=None):
    """
    Powers the redesigned Company Overview (and the light KPI strip on
    Company Welcome): KPI cards, the two ratio gauges, and the trailing
    quarter-trend chart.

    KPI definitions:
      Net Revenue  = sum of GROSS Premium Amount (EGP) across Premium rows
      Net Claims   = sum of GROSS Premium Amount (EGP) across Claim - Paid rows
      Net Expenses = sum of GROSS Commission Amount (EGP) across Premium rows
                     (acquisition commission is the only expense figure this
                     schema captures -- there's no separate opex column)
      UW Result    = Net Revenue - Net Claims - Net Expenses
      Net Loss Ratio    = Net Claims / Net Revenue (0 if Net Revenue is 0)
      Net Expense Ratio = Net Expenses / Net Revenue (0 if Net Revenue is 0)

    year_filter/quarter_filter/data_type_filter narrow every KPI above.
    Picking a single Data Type will, by design, zero out whichever KPI that
    type doesn't feed (e.g. filtering to "Claim - Paid" alone shows Net
    Claims but a zero Net Revenue) -- the same all-or-nothing narrowing
    every other filter in this app already does, rather than silently
    ignoring the filter for some KPIs and not others.

    The trend chart is deliberately independent of year_filter/
    quarter_filter -- a single-quarter selection would leave nothing to
    trend against. It always shows up to the last 8 (year, quarter) periods
    that exist in the data, still honoring data_type_filter so it stays
    consistent with the KPI cards above it.

    PERFORMANCE NOTE: this used to call fetch_company_records() (a full
    `SELECT ... WHERE company_id=%s` + fetchall() + per-row JSON-parse in
    Python) TWICE -- once for the KPI totals, once again completely
    unfiltered for the trend -- on every single load of this page. For a
    company with millions of rows that's millions of JSON blobs pulled over
    the network and parsed in Python, twice, just to add up a handful of
    numbers -- this was the main reason opening a company with a lot of
    data could hang. Rewritten to do the SUM()/GROUP BY in SQL instead
    (via JSON_EXTRACT directly on row_data, no schema change needed): MySQL
    scans its own storage instead of shipping every row to Python, and what
    comes back is one row per (year, quarter) -- at most a few dozen rows
    regardless of how many million rows are behind them. All the filtering
    below then happens over that tiny grouped result set, not the raw table.
    """
    revenue_amount_col = 'GROSS Premium Amount (EGP)'
    expense_amount_col = 'GROSS Commission Amount (EGP)'
    _amount_expr = _json_amount_sql_expr

    # Mirrors derive_quarter()'s fast path exactly: Written Date is always
    # dd/mm/yyyy once normalized, so characters 4-5 are the month. Shared
    # with fetch_company_records_page() via _written_date_quarter_sql_expr()
    # so the two can't drift apart on what counts as which quarter.
    quarter_expr = _written_date_quarter_sql_expr()

    sql = f"""
        SELECT
            data_year,
            {quarter_expr} AS quarter,
            SUM(CASE WHEN component_name = %s THEN {_amount_expr(revenue_amount_col)} ELSE 0 END) AS revenue,
            SUM(CASE WHEN component_name = %s THEN {_amount_expr(revenue_amount_col)} ELSE 0 END) AS claims,
            SUM(CASE WHEN component_name = %s THEN {_amount_expr(expense_amount_col)} ELSE 0 END) AS expenses
        FROM company_data
        WHERE company_id = %s
    """
    params = [OVERVIEW_REVENUE_TYPE, OVERVIEW_CLAIMS_TYPE, OVERVIEW_REVENUE_TYPE, company_id]
    if data_type_filter:
        sql += " AND component_name = %s"
        params.append(data_type_filter)
    sql += " GROUP BY data_year, quarter"

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql, tuple(params))
            grouped = cursor.fetchall()
    finally:
        conn.close()

    net_revenue = 0.0
    net_claims = 0.0
    net_expenses = 0.0
    periods = {}
    for row in grouped:
        year_key = str(row['data_year']) if row['data_year'] is not None else 'Unknown'
        quarter_key = row['quarter']
        revenue = float(row['revenue'] or 0)
        claims = float(row['claims'] or 0)
        expenses = float(row['expenses'] or 0)

        # Trend always includes every period (independent of year/quarter
        # filter), but already respects data_type_filter via the WHERE
        # clause above.
        if quarter_key in OVERVIEW_QUARTER_ORDER:
            bucket = periods.setdefault((year_key, quarter_key), {'revenue': 0.0, 'claims': 0.0})
            bucket['revenue'] += revenue
            bucket['claims'] += claims

        # KPI totals additionally respect year_filter/quarter_filter.
        if year_filter and year_key != str(year_filter):
            continue
        if quarter_filter and quarter_filter in OVERVIEW_QUARTER_ORDER and quarter_key != quarter_filter:
            continue
        net_revenue += revenue
        net_claims += claims
        net_expenses += expenses

    uw_result = net_revenue - net_claims - net_expenses
    loss_ratio = (net_claims / net_revenue * 100) if net_revenue else 0.0
    expense_ratio = (net_expenses / net_revenue * 100) if net_revenue else 0.0

    sorted_keys = sorted(periods.keys(), key=lambda k: (int(k[0]) if str(k[0]).isdigit() else 0, OVERVIEW_QUARTER_ORDER[k[1]]))
    last_keys = sorted_keys[-8:]

    trend = []
    for year_key, quarter_key in reversed(last_keys):  # most recent period first, matching the dashboard layout
        bucket = periods[(year_key, quarter_key)]
        revenue = bucket['revenue']
        claims = bucket['claims']
        ratio = (claims / revenue * 100) if revenue else 0.0
        trend.append({
            'label': f"{year_key}-{quarter_key}",
            'revenue': round(revenue, 2),
            'claims': round(claims, 2),
            'loss_ratio': round(ratio, 1),
        })

    return {
        'net_revenue': round(net_revenue, 2),
        'net_claims': round(net_claims, 2),
        'net_expenses': round(net_expenses, 2),
        'uw_result': round(uw_result, 2),
        'loss_ratio': round(loss_ratio, 2),
        'expense_ratio': round(expense_ratio, 2),
        'trend': trend,
    }


# --- Multi-Tenant Context Resolver ---
def get_company_context(slug):
    """Looks up a company row by its URL slug (e.g. 'acme' in /acme/dashboard).
    Returns None if no company matches -- callers are expected to check for
    that and redirect/404 rather than assume a match."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM companies WHERE slug = %s", (slug,))
            return cursor.fetchone()
    finally:
        conn.close()


# =====================================================================
# --- Group / Permission Helpers ---
# =====================================================================

def get_user_group_names(user_id):
    """Returns a set of group names this user belongs to."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT g.name FROM `groups` g
                JOIN user_groups ug ON ug.group_id = g.id
                WHERE ug.user_id = %s
            """, (user_id,))
            return {row['name'] for row in cursor.fetchall()}
    finally:
        conn.close()


def is_site_admin(user_id):
    """site-group membership = full, unconditional access to everything."""
    return SITE_GROUP_NAME in get_user_group_names(user_id)


def get_accessible_companies(user_id):
    """
    Returns the list of company rows this user can see.
    site-group members get every company; everyone else gets the union
    of companies granted to any group they belong to.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            if is_site_admin(user_id):
                cursor.execute("SELECT * FROM companies ORDER BY name")
                return cursor.fetchall()

            cursor.execute("""
                SELECT DISTINCT c.* FROM companies c
                JOIN group_company_access gca ON gca.company_id = c.id
                JOIN user_groups ug ON ug.group_id = gca.group_id
                WHERE ug.user_id = %s
                ORDER BY c.name
            """, (user_id,))
            return cursor.fetchall()
    finally:
        conn.close()


def has_company_access(user_id, company_slug):
    """True if this user can access the given company: either they're a
    site-group admin (unconditional access), or one of their groups has an
    explicit grant to that company via group_company_access."""
    if is_site_admin(user_id):
        return True

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 1 FROM companies c
                JOIN group_company_access gca ON gca.company_id = c.id
                JOIN user_groups ug ON ug.group_id = gca.group_id
                WHERE ug.user_id = %s AND c.slug = %s
                LIMIT 1
            """, (user_id, company_slug))
            return cursor.fetchone() is not None
    finally:
        conn.close()


def require_company_access(view_func):
    """Decorator for any route that takes company_slug as its first URL arg."""
    @wraps(view_func)
    def wrapped(company_slug, *args, **kwargs):
        if not has_company_access(session['user_id'], company_slug):
            flash('You do not have access to this company workspace.', 'error')
            return redirect(url_for('welcome_site'))
        return view_func(company_slug, *args, **kwargs)
    return wrapped


def require_site_admin(view_func):
    """Decorator for Site Administration routes: site-group only."""
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not is_site_admin(session['user_id']):
            flash('Unauthorized: Site Administration is restricted to site-group members.', 'error')
            return redirect(url_for('welcome_site'))
        return view_func(*args, **kwargs)
    return wrapped


# Endpoints a 'client' role user is allowed to hit -- everything else in the
# app (Dashboard, Data Validation, Site Administration, etc.) is off-limits.
# See check_authentication() below for enforcement.
CLIENT_ROLE_ALLOWED_ENDPOINTS = {
    'client_overview', 'client_overview_upload', 'client_overview_files',
    'client_overview_download', 'client_overview_chat', 'client_overview_chat_send',
    'change_password', 'logout'
}


# --- Middleware Authentication Guard ---
@app.before_request
def check_authentication():
    """
    Runs before every single request. Anything not in allowed_routes
    requires session['user_id'] to already be set, or it's bounced to
    /login -- this is the ONE place session-based auth is enforced globally,
    so every route implicitly requires login unless explicitly exempted here.
    Per-company and per-site-admin authorization happen separately via the
    require_company_access / require_site_admin decorators on top of this.

    Also enforces the forced-password-change flow: if must_change_password
    was set at login time (new account, or an admin-triggered "require
    change on next login"), every route except change_password/logout/
    static gets bounced to the change-password form until it's done. The
    flag is read once at login and stored in the session rather than
    re-queried on every request, so an admin toggling it while a user is
    already logged in takes effect from their *next* login, not mid-session
    -- deliberate, not an oversight.

    Additionally, the 'client' role is fenced in to only the client-overview
    routes (see CLIENT_ROLE_ALLOWED_ENDPOINTS) -- a client account's only job
    is to drop files into their company's "Client uploaded" folder and see
    what they've already sent, never the Dashboard, Data Validation, or
    Site Administration.
    """
    allowed_routes = ['login', 'static']
    if request.endpoint and request.endpoint not in allowed_routes:
        if 'user_id' not in session:
            return redirect(url_for('login'))

        if session.get('must_change_password') and request.endpoint not in ('change_password', 'logout'):
            return redirect(url_for('change_password'))

        if session.get('role') == 'client' and request.endpoint not in CLIENT_ROLE_ALLOWED_ENDPOINTS:
            companies = get_accessible_companies(session['user_id'])
            if companies:
                return redirect(url_for('client_overview', company_slug=companies[0]['slug']))
            flash('Your account has no company access configured yet. Contact a site administrator.', 'error')
            return redirect(url_for('logout'))


# =====================================================================
# --- Core Global Authentication Routes ---
# =====================================================================

@app.route('/', methods=['GET', 'POST'])
@limiter.limit("5 per minute", methods=["POST"])
def login():
    """
    The only route reachable without a session (see check_authentication
    above). GET renders the login form; POST checks the submitted
    credentials against the hashed password in `users` and, on success,
    populates the session (user_id/username/role/must_change_password) that
    every other route relies on. Failed attempts just re-render the form
    with a flashed error -- no lockout/throttling currently, which is worth
    adding (see the security recommendations discussed separately).
    """
    if 'user_id' in session:
        return redirect(url_for('welcome_site'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
                user = cursor.fetchone()

            if user and check_password_hash(user['password_hash'], password):
                session['user_id'] = user['id']
                session['username'] = user['username']
                session['role'] = user['role']
                session['must_change_password'] = bool(user.get('must_change_password'))

                log_action(user['id'], 'LOGIN', f"User {username} successfully logged in.")
                return redirect(url_for('welcome_site'))
            else:
                flash('Invalid username or password.', 'error')
        finally:
            conn.close()

    return render_template('login.html')


@app.route('/welcome')
def welcome_site():
    """Global landing page after login: a grid of every company workspace
    this user can access, plus a Site Administration link if they're a
    site-group admin."""
    companies = get_accessible_companies(session['user_id'])
    return render_template(
        'Welcome-site.html',
        companies=companies,
        is_site_admin=is_site_admin(session['user_id'])
    )


@app.route('/logout')
def logout():
    """Logs the audit trail entry (while the session still has user_id/
    username to log against), then clears the whole session."""
    if 'user_id' in session:
        log_action(session['user_id'], 'LOGOUT', f"User {session['username']} logged out.")
    session.clear()
    return redirect(url_for('login'))


@app.route('/change-password', methods=['GET', 'POST'])
def change_password():
    """
    Serves double duty: this is where check_authentication forces a user
    with must_change_password set, and it's also reachable voluntarily by
    anyone logged in (linked from the Welcome page) to change their own
    password at any time.

    Always requires the CURRENT password to be entered and verified, even
    in the forced flow right after a fresh login -- a hijacked session
    shouldn't be able to lock the real owner out just by knowing it's
    logged in, and re-confirming identity here costs nothing since the user
    just typed a password successfully moments ago anyway.
    """
    forced = bool(session.get('must_change_password'))

    if request.method == 'POST':
        current_password = request.form.get('current_password') or ''
        new_password = request.form.get('new_password') or ''
        confirm_password = request.form.get('confirm_password') or ''

        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM users WHERE id = %s", (session['user_id'],))
                user = cursor.fetchone()

            if not user or not check_password_hash(user['password_hash'], current_password):
                flash('Current password is incorrect.', 'error')
            elif len(new_password) < 8:
                flash('New password must be at least 8 characters long.', 'error')
            elif new_password != confirm_password:
                flash("New password and confirmation don't match.", 'error')
            elif check_password_hash(user['password_hash'], new_password):
                flash('New password must be different from your current password.', 'error')
            else:
                new_hash = generate_password_hash(new_password)
                with conn.cursor() as cursor:
                    cursor.execute(
                        "UPDATE users SET password_hash = %s, must_change_password = 0 WHERE id = %s",
                        (new_hash, session['user_id'])
                    )
                conn.commit()
                session['must_change_password'] = False
                log_action(session['user_id'], 'PASSWORD_CHANGE', f"User {session['username']} changed their own password.")
                flash('Password updated.', 'success')
                return redirect(url_for('welcome_site'))
        finally:
            conn.close()

    return render_template('change-password.html', forced=forced)


# =====================================================================
# --- Multi-Tenant Segregated Path Routes (company-access protected) ---
# =====================================================================

def clear_validation_session(company_slug):
    """
    Clears every *run-specific* validation session key (Custom + IFRS17) plus
    the on-disk report/payload files they point to, so re-entering a company
    always starts the Data Validation / IFRS17 Validation tabs fresh instead
    of showing whatever the last run happened to leave behind.

    Deliberately leaves alone anything that's a persistent setting rather
    than a run result: the IFRS17 Header Mapping (session['ifrs17_header_mapping']),
    the IFRS17 LOB Detailed Mapping (session['ifrs17_lob_mapping']), the
    Custom Validation control totals (session['control_totals']), and the
    IFRS17 Fulfil Data control totals (session['ifrs17_control_totals']) are
    meant to survive across runs and across visits, so they're untouched here.
    """
    # --- Custom validation: staged file + last report + cached import payload ---
    staged_path = session.get('pending_validation_path')
    if staged_path and session.get('pending_company_slug') == company_slug:
        try:
            if os.path.exists(staged_path):
                os.remove(staged_path)
        except OSError:
            pass
    for key in ('pending_validation_path', 'pending_company_slug', 'pending_component',
                'pending_year', 'pending_period', 'pending_period_from', 'pending_period_to',
                'pending_original_filename', 'pending_saved_filename'):
        session.pop(key, None)

    report_path = session.get('report_file_path')
    if report_path:
        try:
            if os.path.exists(report_path):
                os.remove(report_path)
        except OSError:
            pass
    session.pop('report_file_path', None)

    cached_payload_path = session.get('cached_payload_path')
    if cached_payload_path and str(session.get('cached_company_id')):
        try:
            if os.path.exists(cached_payload_path):
                os.remove(cached_payload_path)
        except OSError:
            pass
    for key in ('cached_payload_path', 'cached_company_id', 'cached_component', 'cached_year',
                'cached_period', 'cached_period_from', 'cached_period_to', 'cached_valid_data'):
        session.pop(key, None)

    # --- IFRS17 validation: staged file + last report/payload + its disk files ---
    ifrs17_staged_path = session.get('ifrs17_pending_path')
    if ifrs17_staged_path and session.get('ifrs17_pending_company_slug') == company_slug:
        try:
            if os.path.exists(ifrs17_staged_path):
                os.remove(ifrs17_staged_path)
        except OSError:
            pass
    for key in ('ifrs17_pending_path', 'ifrs17_pending_company_slug', 'ifrs17_pending_sheet_type',
                'ifrs17_pending_data_year', 'ifrs17_pending_date_from', 'ifrs17_pending_date_to',
                'ifrs17_fulfilled_selection'):
        session.pop(key, None)

    last_report = session.get('ifrs17_last_report')
    if last_report and last_report.get('company_slug') == company_slug:
        user_id = session.get('user_id')
        details_path = _ifrs17_report_details_path(company_slug, user_id)
        for stale_path in (
            details_path,
            f"/tmp/ifrs17_report_ready_{company_slug}_{user_id}.json",
        ):
            try:
                if os.path.exists(stale_path):
                    os.remove(stale_path)
            except OSError:
                pass
    session.pop('ifrs17_last_report', None)

    last_payload = session.get('ifrs17_last_payload')
    if last_payload and last_payload.get('company_slug') == company_slug:
        for path_key in ('payload_path_valid', 'payload_path_all'):
            try:
                stale_path = last_payload.get(path_key)
                if stale_path and os.path.exists(stale_path):
                    os.remove(stale_path)
            except OSError:
                pass
    session.pop('ifrs17_last_payload', None)


@app.route('/<company_slug>/welcome')
@require_company_access
def company_welcome(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        flash("Company workspace not found.", "error")
        return redirect(url_for('welcome_site'))
    # Landing here means the user is entering (or re-entering) this company's
    # workspace -- clear out any validation run left over from a previous
    # visit so Data Validation / IFRS17 Validation always start clean.
    clear_validation_session(company_slug)
    return render_template(
        'company/welcome.html',
        company=comp,
        active_page='welcome',
        kpis=compute_overview_dashboard(comp['id'])
    )

@app.route('/<company_slug>/set-mode/<mode>')
@require_company_access
def set_company_mode(company_slug, mode):
    """Sets which validation workspace (Custom vs IFRS 17) this session sees
    for this company -- stored per-company in the session so switching
    companies from the global Welcome grid doesn't carry a stale mode over,
    and the sidebar (company_sider.html) only shows nav items once one of
    the two Welcome buttons has actually been clicked."""
    if mode not in ('custom', 'ifrs17'):
        flash('Unknown validation mode.', 'error')
        return redirect(url_for('company_welcome', company_slug=company_slug))

    comp = get_company_context(company_slug)
    if not comp:
        flash('Company workspace not found.', 'error')
        return redirect(url_for('welcome_site'))

    session[f'mode_{company_slug}'] = mode
    if mode == 'custom':
        return redirect(url_for('company_overview', company_slug=company_slug))
    return redirect(url_for('company_overview_ifrs17', company_slug=company_slug))


@app.route('/<company_slug>/overview')
@require_company_access
def company_overview(company_slug):
    """
    Company Overview page: the full KPI dashboard (Net Revenue/Claims/
    Expenses/UW Result, Loss/Expense ratio gauges, trailing quarter-trend
    chart via compute_overview_dashboard), filterable by Year/Quarter/Data
    Type, plus the "what would you like to do next" actions (View
    Historical Data -> Dashboard, Start New Validation -> the wizard that
    feeds Data Validation its Data Type/Year/Period selection).
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    year_filter = request.args.get('year') or ''
    quarter_filter = (request.args.get('quarter') or '').upper()
    data_type_filter = request.args.get('data_type') or ''

    available_types, available_years = get_company_filter_options(comp['id'])

    return render_template(
        'company/overview.html',
        company=comp,
        active_page='overview',
        validation_data_types=VALIDATION_DATA_TYPES,
        available_types=available_types,
        available_years=available_years,
        filters={'year': year_filter, 'quarter': quarter_filter, 'data_type': data_type_filter},
        dash=compute_overview_dashboard(
            comp['id'], year_filter=year_filter or None,
            quarter_filter=quarter_filter or None, data_type_filter=data_type_filter or None
        )
    )


def get_company_filter_options(company_id, component_names=None, year_sql_expr=None):
    """
    Lightweight DISTINCT queries for the Dashboard's filter dropdowns.
    Deliberately avoids fetch_company_records() here -- pulling and
    JSON-parsing every saved row just to list which data types/years exist
    is exactly the kind of full-table scan that made the Dashboard slow on
    large datasets.

    component_names: optional list to scope both DISTINCT queries to one
    framework (Custom vs IFRS 17), same purpose as in fetch_company_records.

    year_sql_expr: optional callable (see _ifrs17_row_year_sql_expr()) --
    when provided, the Year dropdown lists real content years derived from
    each row's own date field instead of the stored data_year column (an
    import-time label that can disagree with a row's actual content -- see
    that function's docstring). Without it (Custom Validation's case),
    behavior is unchanged.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            type_sql = "SELECT DISTINCT component_name FROM company_data WHERE company_id = %s AND component_name IS NOT NULL"
            type_params = [company_id]
            year_column_sql = year_sql_expr() if year_sql_expr else "data_year"
            year_sql = f"SELECT DISTINCT ({year_column_sql}) AS yr FROM company_data WHERE company_id = %s"
            year_params = [company_id]
            if component_names:
                placeholders = ", ".join(["%s"] * len(component_names))
                type_sql += f" AND component_name IN ({placeholders})"
                type_params.extend(component_names)
                year_sql += f" AND component_name IN ({placeholders})"
                year_params.extend(component_names)

            cursor.execute(type_sql, tuple(type_params))
            types = sorted({row['component_name'] for row in cursor.fetchall() if row['component_name']})

            cursor.execute(year_sql, tuple(year_params))
            years = sorted({row['yr'] for row in cursor.fetchall() if row['yr']}, reverse=True)
    finally:
        conn.close()
    return types, years


# --- Client-facing overview page ("overview-client.html") ---
# Simple, sandboxed page for the 'client' role: two file drops (Total
# Amount Sheet, then Detailed Data) into that company's "Client uploaded"
# folder, and a read-only list of what's already been sent. No validation
# pipeline, no dashboard access -- see CLIENT_ROLE_ALLOWED_ENDPOINTS above.

@app.route('/<company_slug>/client-overview')
@require_company_access
def client_overview(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        flash("Company workspace not found.", "error")
        return redirect(url_for('welcome_site'))

    is_staff_view = session.get('role') != 'client'
    uploads = list_client_uploads(company_slug)
    has_total_amount = any(u['category'] == 'total_amount' for u in uploads)
    chat_messages = get_chat_messages(comp['id'])

    return render_template(
        'company/overview-client.html',
        company=comp,
        active_page='client-overview',
        uploads=uploads,
        has_total_amount=has_total_amount,
        categories=CLIENT_UPLOAD_CATEGORIES,
        expected_headers=EXPECTED_HEADERS,
        control_totals_headers=CONTROL_TOTALS_HEADERS,
        is_staff_view=is_staff_view,
        chat_messages=chat_messages,
        current_username=session.get('username')
    )



@app.route('/<company_slug>/client-overview/upload', methods=['POST'])
@require_company_access
def client_overview_upload(company_slug):
    """Saves one uploaded file into
    <COMPANY_DATA_ROOT>/<slug>/Client uploaded/<category folder>/, creating
    that folder tree on first use. Timestamp-prefixes the stored filename so
    repeat uploads of the same source file never silently overwrite an
    earlier one.

    'total_amount' and 'detailed_data' can be uploaded by either the client
    or staff; 'validation_errors' (a flagged/corrected sheet sent back to the
    client) is staff-only. A notification is only raised for the admin bell
    when the *client* uploads something -- staff uploading their own
    validation-error sheet doesn't need to notify itself."""
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404

    category = request.form.get('category')
    if category not in CLIENT_UPLOAD_CATEGORIES:
        return jsonify({"success": False, "error": "Invalid upload category."}), 400

    is_client = session.get('role') == 'client'
    if category == 'validation_errors' and is_client:
        return jsonify({"success": False, "error": "Only staff can upload validation-error sheets."}), 403

    file = request.files.get('file')
    if not file or not file.filename:
        return jsonify({"success": False, "error": "No file selected."}), 400

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_CLIENT_UPLOAD_EXTENSIONS:
        return jsonify({"success": False, "error": "Only .csv, .xlsx, and .xls files are accepted."}), 400

    dest_dir = get_client_upload_dir(company_slug, category)
    safe_name = secure_filename(file.filename)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    saved_name = f"{timestamp}_{safe_name}"
    file.save(os.path.join(dest_dir, saved_name))

    if is_client:
        create_upload_notification(comp['id'], comp['name'], category, saved_name)
    log_action(
        session['user_id'], 'CLIENT_UPLOAD',
        f"{'Client' if is_client else 'Staff'} uploaded '{saved_name}' ({CLIENT_UPLOAD_CATEGORIES[category]})",
        comp['id']
    )

    return jsonify({"success": True, "filename": saved_name})


@app.route('/<company_slug>/client-overview/files')
@require_company_access
def client_overview_files(company_slug):
    """JSON refresh of the uploaded-files list, used after each successful
    upload so the page doesn't need a full reload."""
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404
    return jsonify({"success": True, "uploads": list_client_uploads(company_slug)})


@app.route('/<company_slug>/client-overview/download/<category>/<path:filename>')
@require_company_access
def client_overview_download(company_slug, category, filename):
    """Serves a single previously-uploaded file back for viewing/download.
    Strictly scoped to that company's Client uploaded/<category> folder --
    the filename is re-sanitised and the resolved path is checked to still
    sit inside that folder before anything is served, so this can't be used
    to read anything else on disk.

    When staff (not the client) download a file, this also clears that
    company's unread notification badge -- the upload has now actually been
    reviewed, so the badge shouldn't keep showing a stale count."""
    comp = get_company_context(company_slug)
    if not comp or category not in CLIENT_UPLOAD_CATEGORIES:
        abort(404)

    folder = os.path.join(COMPANY_DATA_ROOT, company_slug, CLIENT_UPLOAD_ROOT_NAME, CLIENT_UPLOAD_CATEGORIES[category])
    folder_real = os.path.realpath(folder)
    safe_name = secure_filename(os.path.basename(filename))
    file_path = os.path.realpath(os.path.join(folder_real, safe_name))

    if not file_path.startswith(folder_real + os.sep) or not os.path.isfile(file_path):
        abort(404)

    if session.get('role') != 'client':
        mark_company_notifications_read(comp['id'])

    return send_from_directory(folder_real, os.path.basename(file_path), as_attachment=True)


@app.route('/<company_slug>/client-overview/delete/<category>/<path:filename>', methods=['POST'])
@require_company_access
def client_overview_delete(company_slug, category, filename):
    """Removes an uploaded file. Staff-only (admin/user roles) -- the client
    role can view and download its own submissions but never delete them,
    so there's always a record of exactly what was sent unless a staff
    member deliberately clears it."""
    if session.get('role') == 'client':
        return jsonify({"success": False, "error": "Clients cannot delete uploaded files."}), 403

    comp = get_company_context(company_slug)
    if not comp or category not in CLIENT_UPLOAD_CATEGORIES:
        return jsonify({"success": False, "error": "Not found."}), 404

    folder = os.path.join(COMPANY_DATA_ROOT, company_slug, CLIENT_UPLOAD_ROOT_NAME, CLIENT_UPLOAD_CATEGORIES[category])
    folder_real = os.path.realpath(folder)
    safe_name = secure_filename(os.path.basename(filename))
    file_path = os.path.realpath(os.path.join(folder_real, safe_name))

    if not file_path.startswith(folder_real + os.sep) or not os.path.isfile(file_path):
        return jsonify({"success": False, "error": "File not found."}), 404

    os.remove(file_path)
    log_action(session['user_id'], 'CLIENT_UPLOAD_DELETE', f"Deleted '{safe_name}' ({CLIENT_UPLOAD_CATEGORIES[category]})", comp['id'])
    return jsonify({"success": True})


@app.route('/<company_slug>/client-overview/chat')
@require_company_access
def client_overview_chat(company_slug):
    """Polling endpoint: returns messages newer than ?since_id=, or the full
    thread if since_id is omitted/0."""
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404
    since_id = request.args.get('since_id', 0, type=int)
    return jsonify({"success": True, "messages": get_chat_messages(comp['id'], since_id)})


@app.route('/<company_slug>/client-overview/chat/send', methods=['POST'])
@require_company_access
def client_overview_chat_send(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404

    message = (request.form.get('message') or '').strip()
    if not message:
        return jsonify({"success": False, "error": "Message can't be empty."}), 400
    if len(message) > 2000:
        return jsonify({"success": False, "error": "Message is too long (max 2000 characters)."}), 400

    sender_role = 'client' if session.get('role') == 'client' else 'staff'
    msg_id = add_chat_message(comp['id'], sender_role, session.get('username'), message)
    if msg_id is None:
        return jsonify({
            "success": False,
            "error": "Could not save your message. If this keeps happening, the chat table may need to be set up on the server (migrations/add_client_chat_table.py)."
        }), 500
    return jsonify({"success": True, "id": msg_id})


DASHBOARD_PAGE_SIZE = 200
IFRS17_UPR_DASHBOARD_COLUMNS = [
    ('upr_exposure_days', 'Exposure'),
    ('upr_unearned_exposure_days', 'unEarned Exposure'),
    ('upr_earned_amount', 'Earned Amount'),
    ('upr_unearned_amount', 'unEarned Amount'),
]


def attach_saved_upr_calculations(records, company_id):
    for record in records:
        for key, _ in IFRS17_UPR_DASHBOARD_COLUMNS:
            record[key] = None

    row_ids = [record.get('db_id') for record in records if record.get('db_id') is not None]
    if not row_ids:
        return records

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """SELECT COUNT(*) AS cnt
                   FROM information_schema.TABLES
                   WHERE TABLE_SCHEMA = DATABASE()
                     AND TABLE_NAME = 'upr_calculations'"""
            )
            if not cursor.fetchone()['cnt']:
                return records

            calculations = {}
            chunk_size = 1000
            for start in range(0, len(row_ids), chunk_size):
                chunk = row_ids[start:start + chunk_size]
                placeholders = ", ".join(["%s"] * len(chunk))
                cursor.execute(
                    f"""SELECT row_id, exposure_days, unearned_exposure_days,
                               earned_premium, unearned_premium
                        FROM upr_calculations
                        WHERE company_id = %s AND row_id IN ({placeholders})""",
                    (company_id, *chunk),
                )
                for row in cursor.fetchall():
                    calculations[row['row_id']] = row
    finally:
        conn.close()

    for record in records:
        calculation = calculations.get(record.get('db_id'))
        if not calculation:
            continue
        record['upr_exposure_days'] = calculation.get('exposure_days')
        record['upr_unearned_exposure_days'] = calculation.get('unearned_exposure_days')
        record['upr_earned_amount'] = calculation.get('earned_premium')
        record['upr_unearned_amount'] = calculation.get('unearned_premium')

    return records


@app.route('/<company_slug>/dashboard')
@require_company_access
def company_dashboard(company_slug):
    """
    Paginated, filterable table of every saved CUSTOM VALIDATION record for
    this company (see company_dashboard_ifrs17 for the IFRS 17 counterpart --
    the two are separate routes/pages so neither ever pulls the other
    framework's rows, even when no data_type filter is selected).

    All filters (data_type, year, quarter, Policy Number search) AND
    pagination now run in SQL via fetch_company_records_page() -- quarter
    and search used to run in Python after pulling every matching row into
    memory, which was the main reason this page was slow/unresponsive for
    companies with a lot of data. Only the current page's rows are ever
    fetched and JSON-parsed now.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    data_type_filter = request.args.get('data_type') or ''
    year_filter = request.args.get('year') or ''
    quarter_filter = (request.args.get('quarter') or '').upper()
    search = (request.args.get('search') or '').strip().lower()
    try:
        page = max(1, int(request.args.get('page', 1)))
    except (TypeError, ValueError):
        page = 1

    # component_name/data_year/quarter/search are all pushed down to SQL now
    # (see fetch_company_records_page()) -- only page_records ever gets
    # JSON-parsed in Python, regardless of how many rows match overall.
    # component_names=VALIDATION_DATA_TYPES keeps this scoped to Custom rows
    # only, even when data_type_filter is blank (show-everything view).
    page_records, total_count, page, total_pages = fetch_company_records_page(
        comp['id'], component_names=VALIDATION_DATA_TYPES,
        data_type=data_type_filter or None, year=year_filter or None,
        quarter=quarter_filter or None, search=search or None,
        page=page, page_size=DASHBOARD_PAGE_SIZE,
    )

    available_types, available_years = get_company_filter_options(comp['id'], component_names=VALIDATION_DATA_TYPES)

    return render_template(
        'company/dashboard.html',
        company=comp,
        active_page='dashboard',
        records=page_records,
        columns=EXPECTED_HEADERS,
        total_count=total_count,
        page=page,
        total_pages=total_pages,
        page_size=DASHBOARD_PAGE_SIZE,
        available_types=available_types,
        available_years=available_years,
        filters={'data_type': data_type_filter, 'year': year_filter, 'quarter': quarter_filter, 'search': search}
    )


@app.route('/<company_slug>/dashboard/ifrs17')
@require_company_access
def company_dashboard_ifrs17(company_slug):
    """
    IFRS 17 counterpart of company_dashboard() -- same pagination/filtering
    shape, but scoped to IFRS17_DATA_TYPES only (component_names=...) so
    Custom Validation rows never show up here, and columns are the selected
    sheet type's own schema rather than the fixed 14-column EXPECTED_HEADERS.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    data_type_filter = request.args.get('data_type') or ''
    year_filter = request.args.get('year') or ''
    quarter_filter = (request.args.get('quarter') or '').upper()
    search = (request.args.get('search') or '').strip().lower()
    available_types, available_years = get_company_filter_options(
        comp['id'], component_names=IFRS17_DATA_TYPES, year_sql_expr=_ifrs17_row_year_sql_expr
    )

    if not request.args:
        data_type_filter = next(
            (sheet_type for sheet_type in IFRS17_DATA_TYPES if sheet_type in available_types),
            available_types[0] if available_types else '',
        )
        year_filter = available_years[0] if available_years else ''

    try:
        page = max(1, int(request.args.get('page', 1)))
    except (TypeError, ValueError):
        page = 1

    # All filters + pagination pushed into SQL now -- see
    # fetch_company_records_page()'s docstring for why (same fix as
    # company_dashboard()). quarter_sql_expr/year_sql_expr both use each
    # row's OWN sheet type's date column (Issue Date, Policy Issue Date,
    # etc. per IFRS17_UPR_FIELD_MAP) instead of a single hardcoded column /
    # the stored data_year label -- fixes rows being wrongly excluded when
    # their Written Date or import-time data_year label didn't happen to
    # agree with their real content. Only page_records gets JSON-parsed.
    page_records, total_count, page, total_pages = fetch_company_records_page(
        comp['id'], component_names=IFRS17_DATA_TYPES,
        data_type=data_type_filter or None, year=year_filter or None,
        quarter=quarter_filter or None, search=search or None,
        page=page, page_size=DASHBOARD_PAGE_SIZE,
        quarter_sql_expr=_ifrs17_row_quarter_sql_expr,
        year_sql_expr=_ifrs17_row_year_sql_expr,
    )
    attach_saved_upr_calculations(page_records, comp['id'])

    # Table columns depend on which IFRS17 sheet type is selected -- each of
    # the 6 has a different schema. Until one is picked, no per-sheet columns
    # render (Data Type / Year / Quarter alone still show from dashboard-ifrs17.html).
    columns = IFRS17_SHEET_SCHEMAS.get(data_type_filter, [])

    return render_template(
        'company/dashboard-ifrs17.html',
        company=comp,
        active_page='dashboard-ifrs17',
        records=page_records,
        columns=columns,
        total_count=total_count,
        page=page,
        total_pages=total_pages,
        page_size=DASHBOARD_PAGE_SIZE,
        available_types=available_types,
        available_years=available_years,
        upr_columns=IFRS17_UPR_DASHBOARD_COLUMNS,
        filters={'data_type': data_type_filter, 'year': year_filter, 'quarter': quarter_filter, 'search': search}
    )


@app.route('/<company_slug>/dashboard/export')
@require_company_access
def export_dashboard_data(company_slug):
    """
    Exports CUSTOM VALIDATION Dashboard data to .xlsx -- either everything
    for the company (?export_all=1) or the same filtered subset currently
    shown on screen (data_type/year/quarter/search query params, mirroring
    company_dashboard's own filtering logic so the export always matches
    what's on screen). Scoped to VALIDATION_DATA_TYPES so "export all" can
    no longer pull IFRS 17 rows in alongside Custom ones.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    export_all = request.args.get('export_all') == '1'

    if export_all:
        records = fetch_company_records(comp['id'], component_names=VALIDATION_DATA_TYPES)
        filename = f"{company_slug}_all_data.xlsx"
        export_label = "all"
    else:
        data_type_filter = request.args.get('data_type') or ''
        year_filter = request.args.get('year') or ''
        quarter_filter = (request.args.get('quarter') or '').upper()
        search = (request.args.get('search') or '').strip().lower()

        records = fetch_company_records(
            comp['id'], data_type=data_type_filter or None, year=year_filter or None,
            component_names=VALIDATION_DATA_TYPES,
        )
        if quarter_filter and quarter_filter != 'ALL':
            records = [r for r in records if r.get('quarter') == quarter_filter]
        if search:
            records = [r for r in records if search in str(r.get('Policy Number', '')).lower()]
        filename = f"{company_slug}_filtered_data.xlsx"
        export_label = "filtered"

    export_columns = ['component_name', 'data_year', 'quarter'] + EXPECTED_HEADERS
    df = pd.DataFrame(records)
    if df.empty:
        df = pd.DataFrame(columns=export_columns)
    else:
        for col in export_columns:
            if col not in df.columns:
                df[col] = ''
        df = df[export_columns]
        df = df.astype(str)

    output_path = f"/tmp/dashboard_export_{company_slug}_{session['user_id']}.xlsx"
    df.to_excel(output_path, index=False)

    log_action(session['user_id'], 'EXPORT', f"Exported {export_label} dashboard data ({len(records)} rows)", comp['id'])
    return send_file(output_path, as_attachment=True, download_name=filename)


@app.route('/<company_slug>/dashboard/ifrs17/export')
@require_company_access
def export_dashboard_data_ifrs17(company_slug):
    """
    IFRS 17 counterpart of export_dashboard_data(). Scoped to
    IFRS17_DATA_TYPES. Since the 6 IFRS17 sheet types each have a different
    column schema, a single-sheet-type export (data_type set) uses that
    sheet's own columns; an all-types export (no data_type, or ?export_all=1)
    uses the UNION of all 6 schemas (in first-seen order) so every sheet
    type's columns are represented, blank where not applicable to a given row.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    export_all = request.args.get('export_all') == '1'

    if export_all:
        records = fetch_company_records(comp['id'], component_names=IFRS17_DATA_TYPES)
        filename = f"{company_slug}_ifrs17_all_data.xlsx"
        export_label = "all IFRS 17"
        schema_columns = []
        seen = set()
        for cols in IFRS17_SHEET_SCHEMAS.values():
            for col in cols:
                if col not in seen:
                    seen.add(col)
                    schema_columns.append(col)
    else:
        data_type_filter = request.args.get('data_type') or ''
        year_filter = request.args.get('year') or ''
        quarter_filter = (request.args.get('quarter') or '').upper()
        search = (request.args.get('search') or '').strip().lower()

        records = fetch_company_records(
            comp['id'], data_type=data_type_filter or None, year=year_filter or None,
            component_names=IFRS17_DATA_TYPES,
        )
        if quarter_filter and quarter_filter != 'ALL':
            records = [r for r in records if r.get('quarter') == quarter_filter]
        if search:
            records = [r for r in records if search in str(r.get('Policy Number', '')).lower()]
        filename = f"{company_slug}_ifrs17_filtered_data.xlsx"
        export_label = "filtered IFRS 17"
        schema_columns = IFRS17_SHEET_SCHEMAS.get(data_type_filter, [])
        if not schema_columns:
            seen = set()
            for cols in IFRS17_SHEET_SCHEMAS.values():
                for col in cols:
                    if col not in seen:
                        seen.add(col)
                        schema_columns.append(col)

    attach_saved_upr_calculations(records, comp['id'])
    upr_export_columns = []
    for key, label in IFRS17_UPR_DASHBOARD_COLUMNS:
        upr_export_columns.append(label)
        for record in records:
            value = record.get(key)
            record[label] = value if value is not None else ''

    export_columns = ['component_name', 'data_year', 'quarter'] + schema_columns + upr_export_columns
    df = pd.DataFrame(records)
    if df.empty:
        df = pd.DataFrame(columns=export_columns)
    else:
        for col in export_columns:
            if col not in df.columns:
                df[col] = ''
        df = df[export_columns]
        df = df.astype(str)

    output_path = f"/tmp/dashboard_export_ifrs17_{company_slug}_{session['user_id']}.xlsx"
    df.to_excel(output_path, index=False)

    log_action(session['user_id'], 'EXPORT', f"Exported {export_label} dashboard data ({len(records)} rows)", comp['id'])
    return send_file(output_path, as_attachment=True, download_name=filename)


@app.route('/<company_slug>/data-validation', methods=['GET'])
@require_company_access
def company_validation(company_slug):
    """
    GET-only landing for the Data Validation page. Renders one of two
    states depending on session content: the upload form (Step 1) if
    nothing is staged yet, or a "ready to validate" view (Step 2) if a file
    was already saved to disk via save_validation_file but not yet run
    through validate_stream. Also clears any leftover cached-results session
    keys from a *previous* validation run on page load, so stale results
    never leak into a fresh page view.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    session.pop('cached_valid_data', None)
    session.pop('cached_company_id', None)
    session.pop('cached_component', None)
    session.pop('cached_year', None)

    # Criteria arriving from the Overview page's "View validation data" wizard.
    preselected_component = request.args.get('component') or ''
    preselected_year = request.args.get('year') or ''
    preselected_period = (request.args.get('period') or 'ALL').upper()

    period_from, period_to = (None, None)
    if preselected_component and preselected_year:
        period_from, period_to = compute_period_dates(preselected_year, preselected_period)

    # If new criteria arrived from Overview (a different data type than whatever
    # is currently staged), drop any previously staged-but-not-yet-validated file.
    if preselected_component and session.get('pending_component') != preselected_component:
        session.pop('pending_validation_path', None)
        session.pop('pending_company_slug', None)
        session.pop('pending_saved_filename', None)

    file_staged = bool(
        session.get('pending_validation_path')
        and session.get('pending_company_slug') == company_slug
        and os.path.exists(session.get('pending_validation_path', ''))
    )
    staged_filename = session.get('pending_saved_filename') if file_staged else None

    return render_template(
        'company/data-validation.html',
        company=comp,
        components=VALIDATION_DATA_TYPES,
        columns=EXPECTED_HEADERS,
        preselected_component=preselected_component,
        preselected_year=preselected_year,
        preselected_period=preselected_period,
        period_from=period_from,
        period_to=period_to,
        file_staged=file_staged,
        staged_filename=staged_filename
    )


@app.route('/<company_slug>/cancel-validation-file', methods=['POST'])
@require_company_access
def cancel_validation_file(company_slug):
    """Discards a staged-but-not-yet-validated file so the user can pick a different one."""
    saved_path = session.get('pending_validation_path')
    if saved_path and session.get('pending_company_slug') == company_slug and os.path.exists(saved_path):
        try:
            os.remove(saved_path)
        except OSError:
            pass
    for key in ('pending_validation_path', 'pending_company_slug', 'pending_component',
                'pending_year', 'pending_period', 'pending_period_from', 'pending_period_to',
                'pending_original_filename', 'pending_saved_filename'):
        session.pop(key, None)
    flash('Staged file discarded.', 'success')
    return redirect(url_for('company_validation', company_slug=company_slug))


def read_upload_dataframe(source, filename_lower):
    """
    Reads a user-uploaded data-validation sheet (CSV or Excel) with no
    header parsing (header=None) -- validate_dataframe() itself checks
    row 0 against EXPECTED_HEADERS, rather than trusting pandas to find the
    header row automatically. Blank cells become '' (not NaN/None), so every
    downstream check can treat "empty" uniformly as an empty string.
    source can be a Werkzeug FileStorage, an open file, or a path string.
    """
    if filename_lower.endswith('.csv'):
        df = pd.read_csv(source, header=None)
    else:
        df = pd.read_excel(source, header=None)
    return df.fillna('')


def read_control_totals_dataframe(file_storage, ext):
    """
    Reads the control-totals workbook. For .xlsx/.xls, pulls the sheet named
    "DATA" specifically (falling back to the first sheet if none is named
    that) rather than assuming it's first, since real workbooks like this one
    ship extra tabs (MAPPING, RECONCILIATION, How To Use) alongside it.

    Real-world copies of this sheet also aren't guaranteed to have the header
    in row 1 -- the actual template has two blank rows above it (left over
    from Excel Table styling) -- so this scans the first several rows for
    whichever one actually contains the expected column names, instead of
    assuming iloc[0] is the header.
    """
    if ext == '.csv':
        raw = pd.read_csv(file_storage, header=None)
    else:
        # .xlsb (Excel Binary Workbook) needs the 'pyxlsb' engine explicitly --
        # pip install pyxlsb. Regular .xlsx/.xls let pandas pick automatically.
        engine = 'pyxlsb' if ext == '.xlsb' else None
        xls = pd.ExcelFile(file_storage, engine=engine)
        sheet_name = next((s for s in xls.sheet_names if s.strip().lower() == 'data'), xls.sheet_names[0])
        raw = pd.read_excel(xls, sheet_name=sheet_name, header=None)
    raw = raw.fillna('')

    expected = set(CONTROL_TOTALS_HEADERS_NORMALIZED)
    header_row_idx = None
    scan_limit = min(15, len(raw))
    for idx in range(scan_limit):
        cells = {str(v).strip().lower() for v in raw.iloc[idx].tolist() if str(v).strip() != ''}
        if expected.issubset(cells):
            header_row_idx = idx
            break

    if header_row_idx is None:
        raise ValueError(
            f"Could not find a header row containing {CONTROL_TOTALS_HEADERS} "
            f"in the first {scan_limit} rows of the sheet."
        )

    return raw.iloc[header_row_idx:].reset_index(drop=True)


def _clean_cell_for_storage(value):
    """Belt-and-braces: any pandas Timestamp that slipped through un-formatted
    gets normalised to dd/mm/yyyy (no time-of-day component) before it's stored."""
    if isinstance(value, pd.Timestamp):
        return value.strftime('%d/%m/%Y')
    return value


def validate_dataframe(df):
    """
    The full header + row validation engine for uploaded insurance sheets.
    Returns (header_valid, overall_valid, live_report, report_rows, payload_accum).

    payload_accum is built from the *corrected* cell values (dates normalised to
    dd/mm/yyyy, amounts rounded to 3 decimal places) -- the same values shown in
    the Telemetry Log -- so what gets saved to the database always matches what
    was displayed and verified on screen.

    NOTE: this is a vectorized rewrite of the original row-by-row/.iloc loop.
    Same rules, same error text, same output shape -- just applied column-wise
    with pandas/NumPy instead of once per cell in a Python for-loop. That's the
    difference between ~22 minutes and ~45 seconds on a 1,000,000-row sheet.
    """
    # --- Header Validation (unchanged -- this part was never the bottleneck) ---
    first_row_cells = [str(val).strip() for val in df.iloc[0].tolist()]
    header_structure_ok = (first_row_cells == EXPECTED_HEADERS)
    has_no_duplicates   = (len(first_row_cells) == len(set(first_row_cells)))
    header_valid        = header_structure_ok and has_no_duplicates

    live_report    = []
    report_rows    = []
    payload_accum  = []
    overall_valid  = True

    if not header_valid:
        overall_valid = False
        missing = [col for col in EXPECTED_HEADERS if col not in first_row_cells]
        extra   = [col for col in first_row_cells  if col not in EXPECTED_HEADERS]

        err_msg = "Header Mismatch Error -> "
        if missing:
            err_msg += f"Missing expected column(s): {missing}. "
        if extra:
            err_msg += f"Found unexpected column(s): {extra}. "
        if not missing and not extra and not header_structure_ok:
            err_msg += "Columns are named correctly but sequence order is out of bounds."
        if not has_no_duplicates:
            err_msg += "Duplicate headings detected inside the row."

        live_report.append({"row": 1, "status": "NOT VALID", "details": err_msg})
        report_rows.append(["INVALID HEADER STRUCTURE"] + df.iloc[0].tolist())
        return header_valid, overall_valid, live_report, report_rows, payload_accum

    report_rows.append(["VALID HEADER"] + df.iloc[0].tolist())

    # --- Vectorized row validation --------------------------------------------
    body = df.iloc[1:].copy()
    body.columns = EXPECTED_HEADERS
    body.reset_index(drop=True, inplace=True)
    n = len(body)

    if n == 0:
        return header_valid, overall_valid, live_report, report_rows, payload_accum

    # Trimmed-string view of every column, built once and reused by every check.
    str_cols = {h: body[h].astype(str).str.strip() for h in EXPECTED_HEADERS}
    col_width_ok = (df.shape[1] == len(EXPECTED_HEADERS))

    # One error list per row, filled in by whichever checks below fail for it.
    row_error_lists = [[] for _ in range(n)]

    def add_error(mask, message):
        """mask: boolean Series aligned to body's RangeIndex.
        message: a fixed string, or a callable(i) -> str for per-row detail."""
        idxs = body.index[mask]
        if len(idxs) == 0:
            return
        if isinstance(message, str):
            for i in idxs:
                row_error_lists[i].append(message)
        else:
            for i in idxs:
                row_error_lists[i].append(message(i))

    if not col_width_ok:
        msg = f"Width mismatch: cell count is {df.shape[1]} instead of {len(EXPECTED_HEADERS)}"
        for i in range(n):
            row_error_lists[i].append(msg)

    # --- Column A -- Policy Number ---
    add_error(str_cols["Policy Number"] == "", "Cell Policy Number is empty")

    def parse_dates(col):
        raw = str_cols[col]
        # format="mixed" infers the date format PER ELEMENT (not once for the
        # whole column), so a genuinely mixed-format sheet still parses every
        # individually-valid cell correctly -- unlike a plain vectorized
        # pd.to_datetime(dayfirst=True) call, which guesses ONE format for
        # the entire Series and silently NaTs out anything that doesn't match
        # it. This matches the original per-cell parsing exactly, and is
        # still fully vectorized/fast (no Python-level loop).
        parsed = pd.to_datetime(raw, format="mixed", dayfirst=True, errors="coerce")
        parsed = parsed.dt.tz_localize(None).dt.normalize()
        return raw, parsed

    issue_raw, issue_parsed = parse_dates("Issue Date")
    written_raw, written_parsed = parse_dates("Written Date")
    pfrom_raw, pfrom_parsed = parse_dates("Period From")
    pto_raw, pto_parsed = parse_dates("Period to")
    due_raw, due_parsed = parse_dates("Premium/Commission Due Date")

    # --- Column B -- Issue Date ---
    add_error(issue_raw == "", "Cell Issue Date is empty")
    add_error((issue_raw != "") & issue_parsed.isna(), "Invalid date format in Issue Date")
    valid_issue = (issue_raw != "") & issue_parsed.notna()
    body.loc[valid_issue, "Issue Date"] = issue_parsed[valid_issue].dt.strftime('%d/%m/%Y')

    # --- Columns C, D, E -- Written Date / Period From / Period to ---
    for label, raw, parsed in [
        ("Written Date", written_raw, written_parsed),
        ("Period From", pfrom_raw, pfrom_parsed),
        ("Period to", pto_raw, pto_parsed),
    ]:
        add_error(raw == "", f"Cell {label} is empty")
        add_error((raw != "") & parsed.isna(), f"Invalid date format in {label}")
        valid_mask = (raw != "") & parsed.notna()
        body.loc[valid_mask, label] = parsed[valid_mask].dt.strftime('%d/%m/%Y')

    # --- Column F -- Premium/Commission Due Date: optional ---
    add_error((due_raw != "") & due_parsed.isna(), "Invalid date format in Premium/Commission Due Date")
    valid_due = (due_raw != "") & due_parsed.notna()
    body.loc[valid_due, "Premium/Commission Due Date"] = due_parsed[valid_due].dt.strftime('%d/%m/%Y')

    # --- Column G -- LOB Detailed ---
    lob_col = str_cols["LOB Detailed"]
    add_error(~lob_col.isin(LOB_VALID_WORDS),
              lambda i: f"LOB Detailed '{lob_col[i]}' is not an authorised value")

    # --- Column H -- Gross_RI ---
    gross_ri_raw = str_cols["Gross_RI"]
    add_error(~gross_ri_raw.isin(GROSS_RI_WORDS),
              lambda i: f"Gross_RI '{gross_ri_raw[i]}' is not an authorised value")
    is_gross = gross_ri_raw == "GROSS"
    is_ri    = gross_ri_raw == "RI"

    def numeric_amount(col, required_mask, forbidden_mask, required_msg, forbidden_msg, invalid_msg):
        raw = str_cols[col]
        empty = raw == ""
        add_error(required_mask & empty, required_msg)
        add_error(forbidden_mask & ~empty, forbidden_msg)
        candidates = required_mask & ~empty
        numeric = pd.to_numeric(raw, errors="coerce")
        add_error(candidates & numeric.isna(), invalid_msg)
        good = candidates & numeric.notna()
        body.loc[good, col] = numeric[good].round(3).map(lambda v: f"{v:.3f}")
        return empty

    # --- Column J -- GROSS Premium Amount ---
    gross_prem_empty = numeric_amount(
        "GROSS Premium Amount (EGP)", is_gross, is_ri,
        "GROSS Premium Amount is mandatory when Gross_RI is 'GROSS'",
        "GROSS Premium Amount must be empty when Gross_RI is 'RI'",
        "GROSS Premium Amount must be a valid number",
    )

    # --- Column K -- GROSS Commission Amount: optional, needs Premium present ---
    gcomm_raw = str_cols["GROSS Commission Amount (EGP)"]
    gcomm_present = gcomm_raw != ""
    add_error(gcomm_present & gross_prem_empty,
              "GROSS Commission Amount provided but GROSS Premium Amount is missing")
    gcomm_numeric = pd.to_numeric(gcomm_raw, errors="coerce")
    add_error(gcomm_present & ~gross_prem_empty & gcomm_numeric.isna(),
              "GROSS Commission Amount must be a valid numeric amount")
    good = gcomm_present & ~gross_prem_empty & gcomm_numeric.notna()
    body.loc[good, "GROSS Commission Amount (EGP)"] = gcomm_numeric[good].round(3).map(lambda v: f"{v:.3f}")

    # --- Column L -- RI Premium Amount ---
    ri_prem_empty = numeric_amount(
        "RI Premium Amount (EGP)", is_ri, is_gross,
        "RI Premium Amount is mandatory when Gross_RI is 'RI'",
        "RI Premium Amount must be empty when Gross_RI is 'GROSS'",
        "RI Premium Amount must be a valid number",
    )

    # --- Column M -- RI Commission Amount: optional, needs RI Premium present ---
    ricomm_raw = str_cols["RI Commission Amount (EGP)"]
    ricomm_present = ricomm_raw != ""
    add_error(ricomm_present & ri_prem_empty,
              "RI Commission Amount provided but RI Premium Amount is missing")
    ricomm_numeric = pd.to_numeric(ricomm_raw, errors="coerce")
    add_error(ricomm_present & ~ri_prem_empty & ricomm_numeric.isna(),
              "RI Commission Amount must be a valid numeric amount")
    good = ricomm_present & ~ri_prem_empty & ricomm_numeric.notna()
    body.loc[good, "RI Commission Amount (EGP)"] = ricomm_numeric[good].round(3).map(lambda v: f"{v:.3f}")

    # --- Column N -- Financial Year Quarter ---
    fyq_raw = str_cols["Financial Year Quarter"]
    add_error(fyq_raw == "", "Cell Financial Year Quarter is empty")
    has_written = written_parsed.notna()
    fyq_numeric = pd.to_numeric(fyq_raw, errors="coerce")
    checkable = (fyq_raw != "") & has_written
    written_year = written_parsed.dt.year
    bad_year = checkable & fyq_numeric.notna() & (fyq_numeric != written_year)
    add_error(bad_year,
              lambda i: (f"Year mismatch: Financial Year Quarter ({fyq_raw[i]}) "
                         f"does not match Written Date year ({int(written_year[i])})"))
    add_error(checkable & fyq_numeric.isna(), "Financial Year Quarter must be a numeric year")
    add_error((fyq_raw != "") & ~has_written, "Cannot validate Financial Year Quarter: Written Date is missing")

    # --- Cross-field date range checks ---
    both_wf = written_parsed.notna() & pfrom_parsed.notna()
    add_error(both_wf & (pfrom_parsed < written_parsed), "Period From must be on or after Written Date")
    both_ft = pfrom_parsed.notna() & pto_parsed.notna()
    add_error(both_ft & (pto_parsed < pfrom_parsed), "Period to must be after Period From")
    both_issue_due = issue_parsed.notna() & due_parsed.notna()
    add_error(
        both_issue_due & (due_parsed < issue_parsed),
        "Premium/Commission Due Date must be on or after Issue Date",
    )

    # --- Assemble live_report / report_rows / payload_accum ---
    # body.values.tolist() converts the whole corrected table in one shot
    # instead of one .iloc[i] call per row -- this is the other big chunk of
    # the original's per-row overhead.
    all_rows = body.values.tolist()
    for i, current_row_cells in enumerate(all_rows):
        row_no = i + 2  # +1 for 1-indexing, +1 because row 1 is the header
        row_errors = row_error_lists[i]

        if row_errors:
            overall_valid = False
            status_text  = "NOT VALID"
            details_text = f"Invalid data located -> {', '.join(row_errors)}"
            report_rows.append([f"INVALID: {details_text}"] + current_row_cells)
        else:
            status_text  = "VALID"
            details_text = "Row verified 100%."
            report_rows.append(["VALID"] + current_row_cells)

        live_report.append({"row": row_no, "status": status_text, "details": details_text})

        row_dict = {h: _clean_cell_for_storage(v) for h, v in zip(EXPECTED_HEADERS, current_row_cells)}
        payload_accum.append(row_dict)

    return header_valid, overall_valid, live_report, report_rows, payload_accum


@app.route('/<company_slug>/upload-control-totals', methods=['POST'])
@require_company_access
def upload_control_totals(company_slug):
    """
    Reads the company's control-totals workbook (the "DATA" sheet: Data Type,
    year, All the year, Q1-Q4 columns) and "fulfils" it -- pulls out the one
    figure that matches whatever Data Type / Year / Period is currently
    selected for this validation session, rather than dumping the whole
    sheet. That single figure is stashed in the session, keyed by data type,
    so validate_stream() can diff it against the validated total once the
    actual data sheet has been run.

    Called via fetch() from the "Fulfil Data" button on the Data Validation
    page; returns JSON rather than a redirect/template.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404

    file = request.files.get('control_file')
    if not file or file.filename == '':
        return jsonify({"success": False, "error": "No file selected."}), 400

    data_type = (request.form.get('data_type') or '').strip()
    year_raw  = (request.form.get('year') or '').strip()
    period    = (request.form.get('period') or '').strip().upper()

    if not data_type or not year_raw or not period:
        return jsonify({
            "success": False,
            "error": "Data type, year and period must be selected (from Overview) before fulfilling data."
        }), 400

    try:
        year = int(float(year_raw))
    except ValueError:
        return jsonify({"success": False, "error": f"'{year_raw}' is not a valid year."}), 400

    period_col_key = CONTROL_TOTALS_PERIOD_COLUMNS.get(period)
    if not period_col_key:
        return jsonify({"success": False, "error": f"Unrecognised period '{period}'."}), 400

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ('.xlsx', '.xls', '.csv'):
        return jsonify({"success": False, "error": "Unsupported file type. Please upload .xlsx, .xls or .csv."}), 400

    try:
        df = read_control_totals_dataframe(file, ext)
    except Exception as e:
        return jsonify({"success": False, "error": f"Could not read the file: {str(e)}"}), 400

    if len(df) < 2:
        return jsonify({
            "success": False,
            "error": "The DATA sheet must have a header row plus at least one row of totals."
        }), 400

    header_cells = [str(v).strip().lower() for v in df.iloc[0].tolist()]
    try:
        col_idx = {h: header_cells.index(h) for h in CONTROL_TOTALS_HEADERS_NORMALIZED}
    except ValueError:
        return jsonify({
            "success": False,
            "error": (f"The DATA sheet must have columns {CONTROL_TOTALS_HEADERS}, "
                      f"found {[str(v).strip() for v in df.iloc[0].tolist()]}.")
        }), 400

    match_row = None
    for idx in range(1, len(df)):
        row = df.iloc[idx].tolist()
        row_type = str(row[col_idx['data type']]).strip()
        row_year_raw = str(row[col_idx['year']]).strip()
        try:
            row_year = int(float(row_year_raw))
        except ValueError:
            continue
        if row_type == data_type and row_year == year:
            match_row = row
            break

    if match_row is None:
        return jsonify({
            "success": False,
            "error": f"No control total found for '{data_type}' in {year}."
        }), 400

    amount_cell = match_row[col_idx[period_col_key]]
    amount_str = str(amount_cell).strip()
    if amount_str == '' or amount_str.lower() in ('none', 'nan'):
        amount = 0.0
    else:
        try:
            amount = round(float(amount_str), 3)
        except ValueError:
            return jsonify({
                "success": False,
                "error": f"The value for {period} ('{amount_str}') is not a valid number."
            }), 400

    session.setdefault('control_totals', {})
    session['control_totals'][data_type] = amount
    session.modified = True

    log_action(
        session['user_id'], 'UPLOAD_CONTROL_TOTALS',
        f"Fulfilled control total for {data_type} / {year} / {period}: {amount}",
        comp['id']
    )

    period_display = 'All the Year' if period == 'ALL' else period
    return jsonify({
        "success": True,
        "data_type": data_type,
        "year": year,
        "period": period_display,
        "amount": amount
    })


@app.route('/<company_slug>/upload-control-totals-ifrs17', methods=['POST'])
@require_company_access
def upload_control_totals_ifrs17(company_slug):
    """
    IFRS 17 counterpart of upload_control_totals(). Same "DATA" sheet format
    (Data Type / year / All the year / Q1-Q4) and same read_control_totals_dataframe()
    reader -- only the request fields (sheet_type only, no date range here)
    and the session key differ, so this stays a separate framework-scoped
    store (session['ifrs17_control_totals']) rather than sharing
    session['control_totals'] with Custom Validation.

    Called via fetch() from the "Fulfil Data" button on the IFRS 17 Data
    Validation page (Step 1); returns JSON. This gets ONLY the total amount
    for the chosen sheet_type -- it sums the "All the year" cell across
    every row in the workbook whose Data Type matches sheet_type (typically
    one row per year), regardless of period. That single number is what
    Step 4's "Uploaded total amount" reconciles against, independent of
    whatever From/To period is chosen there for row filtering -- the period
    selector on Step 4 is a *separate* control, used only to decide which
    rows of the file being validated get checked (see requirement #4),
    not to change what this total is.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404

    file = request.files.get('control_file')
    if not file or file.filename == '':
        return jsonify({"success": False, "error": "No file selected."}), 400

    sheet_type = (request.form.get('sheet_type') or '').strip()
    if sheet_type not in IFRS17_SHEET_SCHEMAS:
        return jsonify({"success": False, "error": "Please select a valid IFRS 17 sheet type."}), 400

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ('.xlsx', '.xls', '.xlsb', '.csv'):
        return jsonify({"success": False, "error": "Unsupported file type. Please upload .xlsx, .xls, .xlsb or .csv."}), 400

    try:
        df = read_control_totals_dataframe(file, ext)
    except Exception as e:
        return jsonify({"success": False, "error": f"Could not read the file: {str(e)}"}), 400

    if len(df) < 2:
        return jsonify({
            "success": False,
            "error": "The DATA sheet must have a header row plus at least one row of totals."
        }), 400

    header_cells = [str(v).strip().lower() for v in df.iloc[0].tolist()]
    try:
        col_idx = {h: header_cells.index(h) for h in CONTROL_TOTALS_HEADERS_NORMALIZED}
    except ValueError:
        return jsonify({
            "success": False,
            "error": (f"The DATA sheet must have columns {CONTROL_TOTALS_HEADERS}, "
                      f"found {[str(v).strip() for v in df.iloc[0].tolist()]}.")
        }), 400

    # Sum the "All the year" cell across every row matching this sheet_type
    # -- Q1-Q4 are just that same year's breakdown into quarters, not
    # additional amounts, so they aren't added on top (that would double-
    # count). preview_rows keeps the quarter figures too, purely for the
    # on-screen "small table" -- they don't feed into the total.
    all_year_col = CONTROL_TOTALS_PERIOD_COLUMNS['ALL']  # 'all the year' -- documents which source column feeds the total below
    preview_rows = []
    total = 0.0
    matched_any = False
    for idx in range(1, len(df)):
        row = df.iloc[idx].tolist()
        row_type = str(row[col_idx['data type']]).strip()
        if row_type != sheet_type:
            continue
        try:
            row_year = int(float(str(row[col_idx['year']]).strip()))
        except ValueError:
            continue

        def _cell_amount(period_col_key):
            raw_cell = str(row[col_idx[period_col_key]]).strip()
            if raw_cell == '' or raw_cell.lower() in ('none', 'nan'):
                return 0.0
            return round(float(raw_cell), 3)

        try:
            year_amounts = {code: _cell_amount(key) for code, key in CONTROL_TOTALS_PERIOD_COLUMNS.items()}
        except ValueError:
            return jsonify({
                "success": False,
                "error": f"One of the amount cells for {sheet_type} / {row_year} is not a valid number."
            }), 400

        matched_any = True
        total += year_amounts['ALL']
        preview_rows.append({'year': row_year, **year_amounts})

    if not matched_any:
        return jsonify({
            "success": False,
            "error": f"No rows found for Data Type '{sheet_type}' in this workbook."
        }), 400

    total = round(total, 3)
    preview_rows.sort(key=lambda r: r['year'])

    session.setdefault('ifrs17_control_totals', {})
    session['ifrs17_control_totals'][sheet_type] = total
    # Drives the "Fulfilled selection" display / unlock on Step 2. Kept separate
    # from ifrs17_last_report so that running a validation (below) can clear
    # just this, forcing Step 1 to be redone before the next run, without
    # touching the control totals themselves or the last report's results.
    session['ifrs17_fulfilled_selection'] = {'sheet_type': sheet_type, 'preview_rows': preview_rows, 'amount': total}
    session.modified = True

    log_action(
        session['user_id'], 'UPLOAD_CONTROL_TOTALS_IFRS17',
        f"Fulfilled IFRS17 control total for {sheet_type}: {total}",
        comp['id']
    )

    return jsonify({
        "success": True,
        "sheet_type": sheet_type,
        "preview_rows": preview_rows,
        "amount": total,
    })


@app.route('/<company_slug>/save-header-mapping-ifrs17', methods=['POST'])
@require_company_access
def save_header_mapping_ifrs17(company_slug):
    """
    IFRS 17 Step 2 -- "Header Mapping". The user tells us, for the chosen
    sheet type, which header name their own source file actually uses for
    each of our canonical schema columns (e.g. their export calls it
    "Policy No." rather than "Policy Number"). Saved per sheet_type in
    session['ifrs17_header_mapping'] and reused by validate_ifrs17() to
    remap uploaded files before running the existing validation rules, so
    Step 3 stays unchanged. Persists across runs (unlike the Step 1
    "Fulfilled selection", which is meant to be re-done every run) since a
    mapping is a stable fact about the user's export format, not a
    per-run selection.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404

    data = request.get_json(silent=True) or {}
    sheet_type = (data.get('sheet_type') or '').strip()
    mapping = data.get('mapping') or {}

    if sheet_type not in IFRS17_SHEET_SCHEMAS:
        return jsonify({"success": False, "error": "Please select a valid IFRS 17 sheet type."}), 400
    if not isinstance(mapping, dict):
        return jsonify({"success": False, "error": "Invalid mapping payload."}), 400

    expected_headers = IFRS17_SHEET_SCHEMAS[sheet_type]
    cleaned = {}
    missing = []
    for header in expected_headers:
        value = str(mapping.get(header) or '').strip()
        if not value:
            missing.append(header)
        cleaned[header] = value

    if missing:
        return jsonify({
            "success": False,
            "error": f"Please provide a mapped header for: {', '.join(missing)}."
        }), 400

    session.setdefault('ifrs17_header_mapping', {})
    session['ifrs17_header_mapping'][sheet_type] = cleaned
    session.modified = True

    log_action(
        session['user_id'], 'SAVE_HEADER_MAPPING_IFRS17',
        f"Saved IFRS17 header mapping for '{sheet_type}'",
        comp['id']
    )

    return jsonify({"success": True, "sheet_type": sheet_type})


@app.route('/<company_slug>/save-lob-mapping-ifrs17', methods=['POST'])
@require_company_access
def save_lob_mapping_ifrs17(company_slug):
    """
    IFRS 17 Step 3 -- "LOB Detailed Mapping". Unlike Header Mapping (which is
    per sheet_type, since each sheet has different columns), LOB Detailed and
    its allowed values (VALID_LOBS) are shared across every IFRS17 sheet, so
    this mapping is saved once in session['ifrs17_lob_mapping'] and reused for
    all sheet types. The user tells us, for each canonical LOB, what text
    their own file actually uses for it (e.g. "Motor Comp" instead of
    "MOTOR_COMPREHENSIVE"); remap_lob_values() applies it to the uploaded
    file's LOB Detailed column before the existing validity/cross-check rules
    run, so those rules keep working against the canonical values unchanged.
    Persists across runs, same as Header Mapping.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404

    data = request.get_json(silent=True) or {}
    mapping = data.get('mapping') or {}
    if not isinstance(mapping, dict):
        return jsonify({"success": False, "error": "Invalid mapping payload."}), 400

    cleaned = {}
    missing = []
    for lob in sorted(VALID_LOBS):
        value = str(mapping.get(lob) or '').strip()
        if not value:
            missing.append(lob)
        cleaned[lob] = value

    if missing:
        return jsonify({
            "success": False,
            "error": f"Please provide the file's actual value for: {', '.join(missing)}."
        }), 400

    session['ifrs17_lob_mapping'] = cleaned
    session.modified = True

    log_action(
        session['user_id'], 'SAVE_LOB_MAPPING_IFRS17',
        "Saved IFRS17 LOB Detailed mapping",
        comp['id']
    )

    return jsonify({"success": True})


@app.route('/<company_slug>/save-validation-file', methods=['POST'])
@require_company_access
def save_validation_file(company_slug):
    """
    Step 1 of the validation flow: saves the uploaded sheet to disk under the
    company's data folder, renamed to <company>_<type>_<year>_<period>_<timestamp>.
    Nothing is validated yet -- that happens in the live-streamed step 2
    (see validate_stream) once the user clicks "Run Live Validation".
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    component = request.form.get('component')
    year = request.form.get('year')
    period = (request.form.get('period') or 'ALL').upper()

    if not component:
        flash("No validation data type selected. Please start again from Overview.", "error")
        return redirect(url_for('company_overview', company_slug=company_slug))

    try:
        target_year = int(year)
    except (ValueError, TypeError):
        flash("Invalid year selected.", "error")
        return redirect(url_for('company_validation', company_slug=company_slug))

    # Server computes the period range itself rather than trusting the hidden
    # period_from/period_to fields, so a tampered form can't shift the window.
    period_from, period_to = compute_period_dates(target_year, period)

    file = request.files.get('excel_file')
    if not file or file.filename == '':
        flash('No file selected.', 'error')
        return redirect(url_for('company_validation', company_slug=company_slug))

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ('.xlsx', '.xls', '.csv'):
        flash('Unsupported file type. Please upload .xlsx, .xls or .csv.', 'error')
        return redirect(url_for('company_validation', company_slug=company_slug))

    # component names (VALIDATION_DATA_TYPES) match the per-company subfolder names 1:1
    dest_dir = os.path.join(COMPANY_DATA_ROOT, company_slug, component)
    try:
        os.makedirs(dest_dir, exist_ok=True)
    except OSError as e:
        flash(f"Could not prepare the destination folder: {str(e)}", "error")
        return redirect(url_for('company_validation', company_slug=company_slug))

    component_tag = re.sub(r'[^A-Za-z0-9]+', '_', component).strip('_')
    timestamp_tag = datetime.now().strftime('%Y%m%d_%H%M%S')
    saved_filename = f"{company_slug}_{component_tag}_{target_year}_{period}_{timestamp_tag}{ext}"
    saved_path = os.path.join(dest_dir, saved_filename)

    try:
        file.save(saved_path)
    except Exception as e:
        flash(f"Could not save the uploaded file to disk: {str(e)}", "error")
        return redirect(url_for('company_validation', company_slug=company_slug))

    session['pending_validation_path']   = saved_path
    session['pending_company_slug']      = company_slug
    session['pending_component']         = component
    session['pending_year']              = target_year
    session['pending_period']            = period
    session['pending_period_from']       = period_from
    session['pending_period_to']         = period_to
    session['pending_original_filename'] = file.filename
    session['pending_saved_filename']    = saved_filename

    log_action(
        session['user_id'], 'UPLOAD_STAGED',
        f"Staged file for {component} ({target_year}, {period}) saved as {saved_filename}",
        comp['id'], component
    )
    flash(f"File saved as {saved_filename}. Click \"Run Live Validation\" to continue.", "success")

    return render_template(
        'company/data-validation.html',
        company=comp,
        components=VALIDATION_DATA_TYPES,
        columns=EXPECTED_HEADERS,
        file_staged=True,
        staged_filename=saved_filename,
        selected_component=component,
        selected_year=target_year,
        selected_period=period,
        period_from=period_from,
        period_to=period_to
    )


@app.route('/<company_slug>/validate-stream')
@require_company_access
def validate_stream(company_slug):
    """
    Step 2 of the validation flow: runs the full validation against the file
    staged by save_validation_file, then streams the results to the browser
    one row at a time (Server-Sent Events) so the Telemetry Log, the row
    counter and the progress percentage all update live as each row lands.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return "Company not found.", 404

    saved_path = session.get('pending_validation_path')
    if (not saved_path or session.get('pending_company_slug') != company_slug
            or not os.path.exists(saved_path)):
        return "No staged file found. Please upload a file first.", 400

    component      = session.get('pending_component')
    target_year    = session.get('pending_year')
    period         = session.get('pending_period')
    period_from    = session.get('pending_period_from')
    period_to      = session.get('pending_period_to')
    filename_lower = saved_path.lower()

    try:
        df = read_upload_dataframe(saved_path, filename_lower)
    except Exception as e:
        error_message = str(e)

        def error_stream():
            yield f"event: fatal\ndata: {json.dumps({'error': error_message})}\n\n"
        return Response(error_stream(), mimetype='text/event-stream')

    if len(df) == 0:
        def empty_stream():
            yield f"event: fatal\ndata: {json.dumps({'error': 'The uploaded sheet is completely empty.'})}\n\n"
        return Response(empty_stream(), mimetype='text/event-stream')

    # Validation itself runs synchronously (it's fast) so that session state
    # (needed by export-validation-errors / import-to-database) is saved
    # normally by Flask before the streaming response begins.
    header_valid, overall_valid, live_report, report_rows, payload_accum = validate_dataframe(df)

    # --- Control-totals reconciliation ---------------------------------------
    # Sums GROSS + RI Premium Amount across only the rows that individually
    # passed validation (so a partially-bad sheet still gives a meaningful
    # running total, not just an all-or-nothing number). Compared against
    # whatever this session's "Fulfil Data" upload declared for this specific
    # component -- if nothing was uploaded this session, there's nothing to
    # diff against, so control_total/differential stay None.
    def compute_validated_total(payload_accum, live_report):
        total = 0.0
        for row_dict, entry in zip(payload_accum, live_report):
            if entry.get("status") != "VALID":
                continue
            for col in ("GROSS Premium Amount (EGP)", "RI Premium Amount (EGP)"):
                cell = str(row_dict.get(col, "")).strip()
                if cell:
                    try:
                        total += float(cell)
                    except ValueError:
                        pass
        return round(total, 3)

    validated_total = compute_validated_total(payload_accum, live_report)
    control_totals  = session.get('control_totals') or {}
    control_total   = control_totals.get(component)
    differential    = round(validated_total - control_total, 3) if control_total is not None else None

    report_path = f"/tmp/report_{company_slug}_{session['user_id']}.json"
    with open(report_path, 'w') as f:
        json.dump(report_rows, f, default=str)
    session['report_file_path'] = report_path

    valid_payload = payload_accum if (overall_valid and header_valid) else None
    if valid_payload is not None:
        payload_path = f"/tmp/payload_{company_slug}_{session['user_id']}.json"
        with open(payload_path, 'w') as f:
            json.dump(valid_payload, f, default=str)

        session['cached_payload_path'] = payload_path
        session['cached_company_id']   = comp['id']
        session['cached_component']    = component
        session['cached_year']         = target_year
        session['cached_period']       = period
        session['cached_period_from']  = period_from
        session['cached_period_to']    = period_to

        log_action(
            session['user_id'], 'UPLOAD',
            f"Successful validation for {component} ({target_year}, {period}: {period_from} to {period_to})",
            comp['id'], component
        )

    # The staged file has now been validated -- clear the "pending" markers so a
    # page refresh doesn't re-offer the same file as still-awaiting-validation.
    session.pop('pending_validation_path', None)
    session.pop('pending_company_slug', None)
    session.pop('pending_saved_filename', None)

    total_rows_count = len(live_report)

    # Sending one SSE message per row is fine for a few hundred rows, but for
    # a file with tens of thousands of rows it floods the browser with just as
    # many events (and DOM updates). Batch multiple rows into each message --
    # the UI still updates progressively, just in chunks instead of one by one.
    BATCH_SIZE = max(1, min(200, total_rows_count // 200 or 1))

    def generate():
        start = time.time()
        # A small pacing delay makes small files feel pleasantly "live"
        # without making large files wait around for no reason.
        per_batch_delay = 0.05 if total_rows_count <= 300 else 0

        batch = []
        processed = 0
        for entry in live_report:
            processed += 1
            batch.append({"row": entry["row"], "status": entry["status"], "details": entry["details"]})

            if len(batch) >= BATCH_SIZE or processed == total_rows_count:
                event_payload = {
                    "batch": batch,
                    "processed": processed,
                    "total": total_rows_count,
                    "percent": round((processed / total_rows_count) * 100, 1) if total_rows_count else 100
                }
                yield f"data: {json.dumps(event_payload)}\n\n"
                batch = []
                if per_batch_delay:
                    time.sleep(per_batch_delay)

        elapsed_seconds = round(time.time() - start, 1)
        # Only ship a sample of the valid rows for the on-screen preview table --
        # a full 80,000-row payload rendered as an HTML table would freeze the
        # browser. The complete data still goes to the database untouched via
        # import_to_database, which reads the full payload file, not this preview.
        PREVIEW_LIMIT = 500
        preview_sample = (valid_payload or [])[:PREVIEW_LIMIT]
        done_payload = {
            "done": True,
            "overall_valid": overall_valid,
            "header_valid": header_valid,
            "total": total_rows_count,
            "elapsed_seconds": elapsed_seconds,
            "preview_rows": preview_sample,
            "preview_total": len(valid_payload) if valid_payload else 0,
            "preview_truncated": bool(valid_payload) and len(valid_payload) > PREVIEW_LIMIT,
            "validated_total": validated_total,
            "control_total": control_total,
            "differential": differential
        }
        yield f"event: done\ndata: {json.dumps(done_payload, default=str)}\n\n"

    resp = Response(stream_with_context(generate()), mimetype='text/event-stream')
    resp.headers['Cache-Control'] = 'no-cache'
    resp.headers['X-Accel-Buffering'] = 'no'
    return resp

@app.route('/<company_slug>/export-validation-errors')
@require_company_access
def export_validation_errors(company_slug):
    """
    Excel export of only the rows that FAILED validation (status starting
    with "INVALID") from the last validate_stream run -- deliberately
    excludes every "VALID" row so a 1M-row file with 12 bad rows exports 12
    rows, not the whole sheet. Reads from report_file_path, a JSON report
    written to /tmp by validate_stream after each run.
    """
    report_path = session.get('report_file_path')
    if not report_path or not os.path.exists(report_path):
        return "No validation logs found. Please run the validation again.", 400

    try:
        with open(report_path, 'r') as f:
            rows = json.load(f)
    except Exception as e:
        return f"Error reading report file: {str(e)}", 500

    # Only the rows that actually failed a check -- exporting every "VALID"
    # row alongside them would mean shipping the whole sheet back out again,
    # which for a 100K/1M-row file defeats the point of an "error analysis"
    # export. Header-structure failures ("INVALID HEADER STRUCTURE") and
    # per-row failures ("INVALID: <details>") both start with "INVALID"; a
    # clean "VALID"/"VALID HEADER" row is deliberately left out.
    issue_rows = [r for r in rows if isinstance(r, list) and r and str(r[0]).startswith("INVALID")]

    if not issue_rows:
        return "No validation issues were found for this run -- there's nothing to export.", 400

    schema = [
        "Validation Status", "Policy Number", "Issue Date", "Written Date", "Period From", "Period to",
        "Premium/Commission Due Date", "LOB Detailed", "Gross_RI", "RI Treaty Type",
        "GROSS Premium Amount (EGP)", "GROSS Commission Amount (EGP)", "RI Premium Amount (EGP)",
        "RI Commission Amount (EGP)", "Financial Year Quarter", "source_file", "source_page"
    ]

    df_report = pd.DataFrame(issue_rows, columns=schema)

    for col in df_report.columns:
        if pd.api.types.is_datetime64_any_dtype(df_report[col]):
            df_report[col] = df_report[col].dt.tz_localize(None).dt.normalize()
        else:
            df_report[col] = df_report[col].astype(str)

    output_path = f"/tmp/validation_report_{company_slug}_{session['user_id']}.xlsx"
    df_report.to_excel(output_path, index=False, header=True)

    comp = get_company_context(company_slug)
    log_action(session['user_id'], 'EXPORT', f"Exported {len(issue_rows)} validation issue row(s) for review.", comp['id'])
    return send_file(output_path, as_attachment=True, download_name="validation_issues_report.xlsx")


@app.route('/<company_slug>/import-to-database', methods=['POST'])
@require_company_access
def import_to_database(company_slug):
    """
    Final step of the validation pipeline: commits the already-validated,
    already-displayed payload (cached on disk as JSON by validate_stream,
    referenced via session['cached_payload_path']) into company_data as
    real, permanent rows. Deliberately append-only -- re-running the same
    import twice creates duplicate rows on purpose, since there's no
    reliable way to know a "duplicate" wasn't actually a legitimate
    resubmission of corrected data. Chunks the INSERT via executemany()
    since a naive one-row-at-a-time loop was the original bottleneck on
    large sheets.
    """
    comp = get_company_context(company_slug)
    payload_path = session.get('cached_payload_path')
    company_id = session.get('cached_company_id')
    component = session.get('cached_component')
    year = session.get('cached_year')

    if not payload_path or not os.path.exists(payload_path) or not company_id or str(company_id) != str(comp['id']):
        flash("No valid verification state found to process standard import. Please re-run validation.", "error")
        return redirect(url_for('company_validation', company_slug=company_slug))

    try:
        with open(payload_path, 'r') as f:
            payload = json.load(f)
    except Exception as e:
        flash(f"Could not read staged validation data: {str(e)}", "error")
        return redirect(url_for('company_validation', company_slug=company_slug))

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # Plain INSERT, every time — imports are append-only. Re-importing the
            # same sheet twice is allowed and will create duplicate rows on purpose;
            # nothing here overwrites or dedupes existing company_data records.
            sql = """INSERT INTO company_data (company_id, component_name, data_year, row_data, uploaded_by)
                     VALUES (%s, %s, %s, %s, %s)"""

            # executemany batches many rows into far fewer round-trips than one
            # execute() per row -- for large sheets (tens of thousands of rows)
            # this is the difference between minutes and seconds.
            INSERT_CHUNK_SIZE = 20000
            for start in range(0, len(payload), INSERT_CHUNK_SIZE):
                chunk = payload[start:start + INSERT_CHUNK_SIZE]
                params = [
                    (company_id, component, year, json.dumps(record), session['user_id'])
                    for record in chunk
                ]
                cursor.executemany(sql, params)
        conn.commit()
        log_action(session['user_id'], 'IMPORT', f"Committed verified records to the engine dataset for: {component}", comp['id'], component)
        flash(f"Data imported successfully — {len(payload)} row(s) appended to the database.", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Database transaction failure: {str(e)}", "error")
    finally:
        conn.close()

    try:
        os.remove(payload_path)
    except OSError:
        pass

    session.pop('cached_payload_path', None)
    session.pop('cached_company_id', None)
    session.pop('cached_component', None)
    session.pop('cached_year', None)
    session.pop('cached_period', None)
    session.pop('cached_period_from', None)
    session.pop('cached_period_to', None)
    return redirect(url_for('company_validation', company_slug=company_slug))


@app.route('/<company_slug>/history-log')
@require_company_access
def company_history(company_slug):
    """Renders the full audit trail for this company, newest first. Uses a
    LEFT JOIN (not INNER) so entries logged by a since-deleted user account
    still display, falling back to '(deleted user)' for the username --
    see delete_user's comments for why that matters."""
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT h.*, COALESCE(u.username, '(deleted user)') AS username FROM history_log h
                LEFT JOIN users u ON h.user_id = u.id
                WHERE h.company_id = %s ORDER BY h.timestamp DESC
            """, (comp['id'],))
            logs = cursor.fetchall()
    finally:
        conn.close()
    return render_template('company/history-log.html', company=comp, active_page='history-log', logs=logs)


@app.route('/<company_slug>/export-history')
@require_company_access
def export_history(company_slug):
    """Excel export of the same query used by company_history above -- kept
    as a separate, identical query rather than sharing code with the page
    route so the two can diverge in columns/formatting independently."""
    comp = get_company_context(company_slug)
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT h.timestamp, COALESCE(u.username, '(deleted user)') AS username, h.action_type, h.component_name, h.description
                FROM history_log h
                LEFT JOIN users u ON h.user_id = u.id
                WHERE h.company_id = %s ORDER BY h.timestamp DESC
            """, (comp['id'],))
            logs = cursor.fetchall()

        df = pd.DataFrame(logs)
        output_path = f"/tmp/history_log_{company_slug}.xlsx"
        df.to_excel(output_path, index=False)
        return send_file(output_path, as_attachment=True, download_name="history_log.xlsx")
    finally:
        conn.close()


# =====================================================================
# --- UPR Calculation (post-import Exposure / Earned Premium tab) ---
# =====================================================================

UPR_QUARTER_CHOICES = ['Q1', 'Q2', 'Q3', 'Q4']


@app.route('/<company_slug>/upr-calculation')
@require_company_access
def company_upr_calculation(company_slug):
    """
    UPR Calculation tab: once data has been imported to the database, pick a
    Data Type / Year / Quarter and Search to compute Exposure, unEarned
    Exposure, unEarned Premium, and Earned Premium for every matching row,
    evaluated against that quarter's fixed end date.

    All three filters are required before anything is computed -- there's no
    meaningful "last date of quarter" for an unselected quarter, so Search
    is a no-op (empty result, no error) until Data Type, Year, and Quarter
    are all chosen. The quarter-end date itself is derived server-side from
    compute_period_dates (the same source of truth used by the Overview
    wizard and the import pipeline) rather than trusting anything from the
    query string, and is not editable by the user.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    data_type_filter = request.args.get('data_type') or ''
    year_filter = request.args.get('year') or ''
    quarter_filter = (request.args.get('quarter') or '').upper()

    available_types, available_years = get_company_filter_options(comp['id'])

    results = []
    quarter_end_display = None
    searched = bool(data_type_filter and year_filter and quarter_filter in UPR_QUARTER_CHOICES)

    if searched:
        _, quarter_end_str = compute_period_dates(year_filter, quarter_filter)
        quarter_end_date = datetime.strptime(quarter_end_str, '%Y-%m-%d').date()
        quarter_end_display = quarter_end_date.strftime('%d/%m/%Y')

        records = fetch_company_records(comp['id'], data_type=data_type_filter, year=year_filter)
        records = [r for r in records if r.get('quarter') == quarter_filter]

        for r in records:
            metrics = compute_upr_metrics(
                r.get('Period From'), r.get('Period to'),
                r.get('GROSS Premium Amount (EGP)'), quarter_end_date
            )
            row = dict(r)
            row.update(metrics)
            results.append(row)

    return render_template(
        'company/upr-calculation.html',
        company=comp,
        active_page='upr-calculation',
        columns=EXPECTED_HEADERS,
        available_types=available_types,
        available_years=available_years,
        quarter_choices=UPR_QUARTER_CHOICES,
        filters={'data_type': data_type_filter, 'year': year_filter, 'quarter': quarter_filter},
        results=results,
        searched=searched,
        quarter_end_display=quarter_end_display,
    )


@app.route('/<company_slug>/upr-calculation/save', methods=['POST'])
@require_company_access
def save_upr_calculation(company_slug):
    """
    Persists the UPR calculation into upr_calculations, one row per
    company_data row (row_id is that row's id, UNIQUE/PK on
    upr_calculations so re-Search-and-Save for the same Data Type/Year/
    Quarter updates the existing calculation in place via
    INSERT ... ON DUPLICATE KEY UPDATE instead of piling up duplicates).

    Recomputes everything server-side from the posted Data Type/Year/Quarter
    rather than trusting any calculated values the form might have carried,
    for the same reason save_validation_file recomputes period_from/
    period_to server-side instead of trusting the form's hidden fields.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    data_type_filter = request.form.get('data_type') or ''
    year_filter = request.form.get('year') or ''
    quarter_filter = (request.form.get('quarter') or '').upper()

    if not (data_type_filter and year_filter and quarter_filter in UPR_QUARTER_CHOICES):
        flash("Select Data Type, Year, and Quarter, then Search before saving.", "error")
        return redirect(url_for('company_upr_calculation', company_slug=company_slug))

    _, quarter_end_str = compute_period_dates(year_filter, quarter_filter)
    quarter_end_date = datetime.strptime(quarter_end_str, '%Y-%m-%d').date()

    records = fetch_company_records(comp['id'], data_type=data_type_filter, year=year_filter)
    records = [r for r in records if r.get('quarter') == quarter_filter]

    conn = get_db_connection()
    try:
        ensure_upr_calculations_table(conn)
        with conn.cursor() as cursor:
            sql = """INSERT INTO upr_calculations
                     (row_id, company_id, component_name, data_year, quarter, quarter_end_date,
                      exposure_days, unearned_exposure_days, earned_premium, unearned_premium,
                      calculated_by, calculated_at)
                     VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
                     ON DUPLICATE KEY UPDATE
                        quarter_end_date = VALUES(quarter_end_date),
                        exposure_days = VALUES(exposure_days),
                        unearned_exposure_days = VALUES(unearned_exposure_days),
                        earned_premium = VALUES(earned_premium),
                        unearned_premium = VALUES(unearned_premium),
                        calculated_by = VALUES(calculated_by),
                        calculated_at = NOW()"""

            saved = 0
            for r in records:
                metrics = compute_upr_metrics(
                    r.get('Period From'), r.get('Period to'),
                    r.get('GROSS Premium Amount (EGP)'), quarter_end_date
                )
                cursor.execute(sql, (
                    r['db_id'], comp['id'], data_type_filter, year_filter, quarter_filter,
                    quarter_end_date, metrics['exposure_days'], metrics['unearned_exposure_days'],
                    metrics['earned_premium'], metrics['unearned_premium'], session['user_id']
                ))
                saved += 1
        conn.commit()
        log_action(
            session['user_id'],
            'UPR_CALCULATION',
            f"Saved UPR calculation for {data_type_filter} ({year_filter}, {quarter_filter}: {saved} row(s))",
            comp['id'], data_type_filter
        )
        flash(f"UPR calculation saved for {saved} row(s).", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Database transaction failure: {str(e)}", "error")
    finally:
        conn.close()

    return redirect(url_for(
        'company_upr_calculation', company_slug=company_slug,
        data_type=data_type_filter, year=year_filter, quarter=quarter_filter
    ))


@app.route('/<company_slug>/upr-calculation/export')
@require_company_access
def export_upr_calculation(company_slug):
    """
    Excel export of the UPR calculation for the given Data Type/Year/Quarter,
    recomputed fresh from company_data rather than read back from
    upr_calculations -- mirrors export_dashboard_data's own pattern of
    recomputing so the export always matches what Search currently shows,
    whether or not Save has been clicked yet.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    data_type_filter = request.args.get('data_type') or ''
    year_filter = request.args.get('year') or ''
    quarter_filter = (request.args.get('quarter') or '').upper()

    if not (data_type_filter and year_filter and quarter_filter in UPR_QUARTER_CHOICES):
        flash("Select Data Type, Year, and Quarter, then Search before exporting.", "error")
        return redirect(url_for('company_upr_calculation', company_slug=company_slug))

    _, quarter_end_str = compute_period_dates(year_filter, quarter_filter)
    quarter_end_date = datetime.strptime(quarter_end_str, '%Y-%m-%d').date()

    records = fetch_company_records(comp['id'], data_type=data_type_filter, year=year_filter)
    records = [r for r in records if r.get('quarter') == quarter_filter]

    rows = []
    for r in records:
        metrics = compute_upr_metrics(
            r.get('Period From'), r.get('Period to'),
            r.get('GROSS Premium Amount (EGP)'), quarter_end_date
        )
        row = dict(r)
        row.update(metrics)
        rows.append(row)

    export_columns = ['component_name', 'data_year', 'quarter'] + EXPECTED_HEADERS + [
        'exposure_days', 'unearned_exposure_days', 'earned_premium', 'unearned_premium'
    ]
    df = pd.DataFrame(rows)
    if df.empty:
        df = pd.DataFrame(columns=export_columns)
    else:
        for col in export_columns:
            if col not in df.columns:
                df[col] = ''
        df = df[export_columns]
        df = df.astype(str)

    output_path = f"/tmp/upr_calculation_export_{company_slug}_{session['user_id']}.xlsx"
    df.to_excel(output_path, index=False)

    log_action(
        session['user_id'], 'EXPORT',
        f"Exported UPR calculation for {data_type_filter} ({year_filter}, {quarter_filter})",
        comp['id'], data_type_filter
    )
    return send_file(output_path, as_attachment=True, download_name=f"{company_slug}_upr_calculation.xlsx")


def build_ifrs17_upr_results(company_id, data_type, year, quarter, quarter_end_date):
    """
    PERFORMANCE NOTE: used to call fetch_company_records(data_type=..., year=...)
    -- every row for the WHOLE year, regardless of quarter -- then filter
    down to the one requested quarter in Python. For a sheet_type+year with
    a lot of rows, that's up to 4x more rows fetched/parsed than necessary.
    Now pushes the quarter filter into SQL too, via fetch_company_records_by_quarter()
    (using this sheet type's own quarter_date column -- see IFRS17_UPR_FIELD_MAP),
    so only rows actually in the requested quarter are ever fetched.

    This still can't avoid computing UPR metrics per row in Python -- that's
    a genuine per-row calculation (day-count proration), not something a SQL
    aggregate can replace -- so a single quarter that's itself huge can still
    be slow to render/export. Flag it if you hit that; it'd need its own
    pagination pass.
    """
    field_map = IFRS17_UPR_FIELD_MAP[data_type]
    records = fetch_company_records_by_quarter(company_id, data_type, year, field_map['quarter_date'], quarter)
    results = []

    for record in records:
        metrics = compute_upr_metrics(
            record.get(field_map['period_from']),
            record.get(field_map['period_to']),
            record.get(field_map['amount']),
            quarter_end_date,
        )
        row = dict(record)
        row['quarter'] = quarter
        row.update(metrics)
        results.append(row)

    return results


@app.route('/<company_slug>/upr-calculation-ifrs17')
@require_company_access
def company_upr_calculation_ifrs17(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    data_type_filter = request.args.get('data_type') or ''
    year_filter = request.args.get('year') or ''
    quarter_filter = (request.args.get('quarter') or '').upper()

    _, available_years = get_company_filter_options(
        comp['id'], component_names=IFRS17_DATA_TYPES, year_sql_expr=_ifrs17_row_year_sql_expr
    )
    searched = bool(
        data_type_filter in IFRS17_UPR_FIELD_MAP
        and year_filter
        and quarter_filter in UPR_QUARTER_CHOICES
    )
    results = []
    quarter_end_display = None
    calculation_fields = IFRS17_UPR_FIELD_MAP.get(data_type_filter)

    if searched:
        _, quarter_end_str = compute_period_dates(year_filter, quarter_filter)
        quarter_end_date = datetime.strptime(quarter_end_str, '%Y-%m-%d').date()
        quarter_end_display = quarter_end_date.strftime('%d/%m/%Y')
        results = build_ifrs17_upr_results(
            comp['id'], data_type_filter, year_filter, quarter_filter, quarter_end_date
        )

    return render_template(
        'company/upr-calculation-ifrs17.html',
        company=comp,
        active_page='upr-calculation-ifrs17',
        columns=IFRS17_SHEET_SCHEMAS.get(data_type_filter, []),
        available_types=IFRS17_DATA_TYPES,
        available_years=available_years,
        quarter_choices=UPR_QUARTER_CHOICES,
        filters={'data_type': data_type_filter, 'year': year_filter, 'quarter': quarter_filter},
        results=results,
        searched=searched,
        quarter_end_display=quarter_end_display,
        calculation_fields=calculation_fields,
    )


@app.route('/<company_slug>/upr-calculation-ifrs17/save', methods=['POST'])
@require_company_access
def save_upr_calculation_ifrs17(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    data_type_filter = request.form.get('data_type') or ''
    year_filter = request.form.get('year') or ''
    quarter_filter = (request.form.get('quarter') or '').upper()

    if not (
        data_type_filter in IFRS17_UPR_FIELD_MAP
        and year_filter
        and quarter_filter in UPR_QUARTER_CHOICES
    ):
        flash("Select IFRS 17 Sheet Type, Year, and Quarter, then Search before saving.", "error")
        return redirect(url_for('company_upr_calculation_ifrs17', company_slug=company_slug))

    _, quarter_end_str = compute_period_dates(year_filter, quarter_filter)
    quarter_end_date = datetime.strptime(quarter_end_str, '%Y-%m-%d').date()
    results = build_ifrs17_upr_results(
        comp['id'], data_type_filter, year_filter, quarter_filter, quarter_end_date
    )

    conn = get_db_connection()
    try:
        ensure_upr_calculations_table(conn)
        with conn.cursor() as cursor:
            sql = """INSERT INTO upr_calculations
                     (row_id, company_id, component_name, data_year, quarter, quarter_end_date,
                      exposure_days, unearned_exposure_days, earned_premium, unearned_premium,
                      calculated_by, calculated_at)
                     VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
                     ON DUPLICATE KEY UPDATE
                        quarter_end_date = VALUES(quarter_end_date),
                        exposure_days = VALUES(exposure_days),
                        unearned_exposure_days = VALUES(unearned_exposure_days),
                        earned_premium = VALUES(earned_premium),
                        unearned_premium = VALUES(unearned_premium),
                        calculated_by = VALUES(calculated_by),
                        calculated_at = NOW()"""

            for row in results:
                cursor.execute(sql, (
                    row['db_id'], comp['id'], data_type_filter, year_filter, quarter_filter,
                    quarter_end_date, row['exposure_days'], row['unearned_exposure_days'],
                    row['earned_premium'], row['unearned_premium'], session['user_id'],
                ))
        conn.commit()
        log_action(
            session['user_id'],
            'IFRS17_UPR_CALCULATION',
            f"Saved IFRS 17 UPR calculation for {data_type_filter} "
            f"({year_filter}, {quarter_filter}: {len(results)} row(s))",
            comp['id'],
            data_type_filter,
        )
        flash(f"IFRS 17 UPR calculation saved for {len(results)} row(s).", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Database transaction failure: {str(e)}", "error")
    finally:
        conn.close()

    return redirect(url_for(
        'company_upr_calculation_ifrs17',
        company_slug=company_slug,
        data_type=data_type_filter,
        year=year_filter,
        quarter=quarter_filter,
    ))


@app.route('/<company_slug>/upr-calculation-ifrs17/export')
@require_company_access
def export_upr_calculation_ifrs17(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    data_type_filter = request.args.get('data_type') or ''
    year_filter = request.args.get('year') or ''
    quarter_filter = (request.args.get('quarter') or '').upper()

    if not (
        data_type_filter in IFRS17_UPR_FIELD_MAP
        and year_filter
        and quarter_filter in UPR_QUARTER_CHOICES
    ):
        flash("Select IFRS 17 Sheet Type, Year, and Quarter, then Search before exporting.", "error")
        return redirect(url_for('company_upr_calculation_ifrs17', company_slug=company_slug))

    _, quarter_end_str = compute_period_dates(year_filter, quarter_filter)
    quarter_end_date = datetime.strptime(quarter_end_str, '%Y-%m-%d').date()
    rows = build_ifrs17_upr_results(
        comp['id'], data_type_filter, year_filter, quarter_filter, quarter_end_date
    )

    export_columns = [
        'component_name', 'data_year', 'quarter',
    ] + IFRS17_SHEET_SCHEMAS[data_type_filter] + [
        'exposure_days', 'unearned_exposure_days', 'earned_premium', 'unearned_premium',
    ]
    df = pd.DataFrame(rows)
    if df.empty:
        df = pd.DataFrame(columns=export_columns)
    else:
        for col in export_columns:
            if col not in df.columns:
                df[col] = ''
        df = df[export_columns].astype(str)

    output_path = f"/tmp/upr_calculation_ifrs17_export_{company_slug}_{session['user_id']}.xlsx"
    df.to_excel(output_path, index=False)
    log_action(
        session['user_id'],
        'EXPORT',
        f"Exported IFRS 17 UPR calculation for {data_type_filter} "
        f"({year_filter}, {quarter_filter})",
        comp['id'],
        data_type_filter,
    )
    return send_file(
        output_path,
        as_attachment=True,
        download_name=f"{company_slug}_upr_calculation_ifrs17.xlsx",
    )


# --- IFRS 17 Validation ---

@app.route('/<company_slug>/overview-ifrs17')
@require_company_access
def company_overview_ifrs17(company_slug):
    """
    PERFORMANCE NOTE: this used to call fetch_company_records() -- a full
    unbounded fetch + per-row JSON-parse -- ONCE PER SHEET TYPE (6 separate
    full scans of this company's data) just to get a row count and a couple
    of amount sums per sheet. For a company with a lot of IFRS17 data, that
    made this the single slowest page in the whole IFRS17 workflow -- it's
    also what "IFRS 17 Validation" from the Welcome page redirects straight
    into (see set_company_mode()). Rewritten the same way
    compute_overview_dashboard() was: one small SQL query per sheet type
    (COUNT(*) plus SUM() via JSON_EXTRACT for each amount column), so only
    the resulting handful of numbers -- never the underlying rows -- come
    back to Python.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    sheet_summaries = []
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            for sheet_name, columns in IFRS17_SHEET_SCHEMAS.items():
                amount_cols = [c for c in columns if 'amount' in c.lower()]
                # Generic aliases (amt_0, amt_1, ...) since the real column
                # names contain spaces/parens that aren't safe as raw SQL
                # identifiers -- mapped back to the real names below.
                select_parts = ["COUNT(*) AS row_count"]
                for i, col in enumerate(amount_cols):
                    select_parts.append(f"SUM({_json_amount_sql_expr(col)}) AS amt_{i}")
                sql = f"SELECT {', '.join(select_parts)} FROM company_data WHERE company_id = %s AND component_name = %s"
                cursor.execute(sql, (comp['id'], sheet_name))
                row = cursor.fetchone() or {}

                amount_totals = {
                    col: round(float(row.get(f'amt_{i}') or 0), 2)
                    for i, col in enumerate(amount_cols)
                }
                sheet_summaries.append({
                    'name': sheet_name,
                    'row_count': row.get('row_count') or 0,
                    'amount_totals': amount_totals,
                })
    finally:
        conn.close()

    return render_template(
        'company/overview-ifrs17.html',
        company=comp,
        active_page='overview-ifrs17',
        sheet_summaries=sheet_summaries,
    )

def _ifrs17_report_details_path(company_slug, user_id):
    return f"/tmp/ifrs17_report_details_{company_slug}_{user_id}.json"


def load_ifrs17_report_details(company_slug, user_id):
    """Reads preview_rows/preview_error_cols for the last validation run.

    These live in a small per-company/user file on disk, NOT in the session
    cookie -- see the note in company_validation_ifrs17() for why (a 500-row
    preview blew past Nginx's header buffer when it was in the cookie).
    Anywhere that needs this data (the results page, the error export) reads
    it through this same helper rather than session['ifrs17_last_report'],
    which only ever holds small scalar summary fields now.

    Returns {} if the file is missing, unreadable, or belongs to a different
    company (stale/mismatched session) -- callers should treat that the same
    as "no report available" rather than erroring.
    """
    details_path = _ifrs17_report_details_path(company_slug, user_id)
    if not os.path.exists(details_path):
        return {}
    try:
        with open(details_path, 'r') as f:
            details = json.load(f)
        if details.get('company_slug') != company_slug:
            return {}
        return details
    except Exception:
        return {}


@app.route('/<company_slug>/data-validation-ifrs17', methods=['GET'])
@require_company_access
def company_validation_ifrs17(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    # --- Ready-file pickup ------------------------------------------------
    # validate_ifrs17_stream() (SSE) can't write to the session while it's
    # streaming -- Flask/Werkzeug fixes the Set-Cookie header before the
    # generator body runs, so anything written mid-stream would silently
    # never reach the browser. Instead it writes its finished report (and,
    # if the run passed, the payload path) to a small JSON file on disk.
    # This is the first ordinary (non-streaming) request after that SSE
    # call finishes -- the browser reloads this page once it sees the
    # 'done'/'fatal' event -- so it's the right place to pick that file up.
    #
    # IMPORTANT: preview_rows/preview_error_cols are NOT copied into the
    # session here. That was the actual cause of the "upstream sent too big
    # header" 502s -- up to 500 preview rows across a dozen-plus IFRS17
    # columns is easily 100KB+, and Flask sessions are client-side signed
    # cookies (no SESSION_TYPE configured), which blow well past Nginx's
    # header buffer long before they'd hit any row-count or timeout limit.
    # Only small scalar fields go in session; preview_rows/preview_error_cols
    # stay in a stable per-company/user file on disk and are read fresh
    # below, every time this page renders -- never through a cookie.
    ready_path = f"/tmp/ifrs17_report_ready_{company_slug}_{session['user_id']}.json"
    details_path = _ifrs17_report_details_path(company_slug, session['user_id'])
    if os.path.exists(ready_path):
        try:
            with open(ready_path, 'r') as f:
                ready_report = json.load(f)
            payload_path_valid = ready_report.pop('payload_path_valid', None)
            valid_row_count = ready_report.pop('valid_row_count', None)
            payload_path_all = ready_report.pop('payload_path_all', None)
            payload_row_count = ready_report.pop('payload_row_count', None)

            # Full report (including preview rows) persists on disk, not in
            # session -- overwritten by every new validation run.
            with open(details_path, 'w') as f:
                json.dump(ready_report, f, default=str)

            # Only small scalars go in the session cookie.
            summary_report = {k: v for k, v in ready_report.items()
                               if k not in ('preview_rows', 'preview_error_cols', 'error_rows', 'error_cols',
                                             'all_rows_full', 'all_cols_full')}
            session['ifrs17_last_report'] = summary_report

            if payload_path_valid or payload_path_all:
                session['ifrs17_last_payload'] = {
                    'company_slug': ready_report.get('company_slug'),
                    'sheet_type': ready_report.get('sheet_type'),
                    'data_year': ready_report.get('data_year'),
                    'payload_path_valid': payload_path_valid,
                    'valid_row_count': valid_row_count,
                    'payload_path_all': payload_path_all,
                    'payload_row_count': payload_row_count,
                }
            else:
                session.pop('ifrs17_last_payload', None)
            # Step 1 (Fulfil) no longer carries anything period-specific --
            # it's the whole workbook for this sheet_type -- so, unlike
            # before, it's left alone here rather than being force-cleared
            # every run. Only Step 4's own date_from/date_to change per run.
        except Exception:
            # A partially-written or unreadable ready-file shouldn't break
            # the page -- just skip picking it up this time; the SSE route
            # will overwrite it on the next run.
            pass
        finally:
            try:
                os.remove(ready_path)
            except OSError:
                pass

    report = session.get('ifrs17_last_report')
    report_ready = bool(report and report.get('company_slug') == company_slug)

    fulfilled_selection = session.get('ifrs17_fulfilled_selection')
    fulfilled_ready = bool(fulfilled_selection)
    pending_sheet_type = fulfilled_selection.get('sheet_type') if fulfilled_ready else ''

    all_header_mappings = session.get('ifrs17_header_mapping') or {}
    existing_mapping = all_header_mappings.get(pending_sheet_type, {}) if fulfilled_ready else {}
    mapping_schema_columns = IFRS17_SHEET_SCHEMAS.get(pending_sheet_type, []) if fulfilled_ready else []
    mapping_ready = fulfilled_ready and mapping_is_complete(pending_sheet_type, existing_mapping)

    existing_lob_mapping = session.get('ifrs17_lob_mapping') or {}
    lob_mapping_ready = fulfilled_ready and mapping_ready and lob_mapping_is_complete(existing_lob_mapping)

    # Preview rows are read fresh from disk every render -- never from
    # session (see load_ifrs17_report_details()'s docstring). A missing/
    # unreadable details file (e.g. cleared out, or an older session
    # predating this fix) just means an empty preview instead of a crash.
    preview_rows = []
    preview_error_cols = []
    if report_ready:
        details = load_ifrs17_report_details(company_slug, session['user_id'])
        preview_rows = details.get('preview_rows') or []
        preview_error_cols = details.get('preview_error_cols') or []
    if preview_error_cols is None:
        preview_error_cols = []
    # Defensive: a details file written before this feature existed (or any
    # other length mismatch) would otherwise crash zip() below with a
    # TypeError -- pad/truncate so every row always gets a (possibly empty)
    # error list.
    if preview_rows and len(preview_error_cols) != len(preview_rows):
        preview_error_cols = (preview_error_cols + [[]] * len(preview_rows))[:len(preview_rows)]
    # Zipped here (rather than in the template, which can't zip two Jinja
    # variables together) so each row and its set of error-flagged columns
    # travel as one pair for cell-level highlighting.
    preview_rows_with_errors = list(zip(preview_rows, preview_error_cols)) if preview_rows else []

    existing_import_count = None
    if report_ready and report.get('overall_valid'):
        try:
            existing_import_count = count_company_records(
                comp['id'], report.get('sheet_type'), int(float(report.get('data_year')))
            )
        except (TypeError, ValueError):
            existing_import_count = None

    return render_template(
        'company/data-validation-ifrs17.html',
        company=comp,
        active_page='data-validation-ifrs17',
        sheet_types=IFRS17_DATA_TYPES,
        valid_lobs=sorted(VALID_LOBS),
        selected_sheet_type=report.get('sheet_type') if report_ready else '',
        selected_year=report.get('data_year') if report_ready else '',
        selected_date_from=report.get('date_from') if report_ready else '',
        selected_date_to=report.get('date_to') if report_ready else '',
        report_ready=report_ready,
        fulfilled_ready=fulfilled_ready,
        pending_sheet_type=pending_sheet_type,
        pending_date_from='',
        pending_date_to='',
        fulfil_preview_rows=fulfilled_selection.get('preview_rows') if fulfilled_ready else [],
        fulfil_amount=fulfilled_selection.get('amount') if fulfilled_ready else None,
        mapping_ready=mapping_ready,
        mapping_schema_columns=mapping_schema_columns,
        existing_mapping=existing_mapping,
        lob_mapping_ready=lob_mapping_ready,
        existing_lob_mapping=existing_lob_mapping,
        overall_valid=report.get('overall_valid') if report_ready else False,
        header_error=report.get('header_error') if report_ready else None,
        raw_row_count=report.get('raw_row_count') if report_ready else 0,
        row_count=report.get('row_count') if report_ready else 0,
        invalid_count=report.get('invalid_count') if report_ready else 0,
        preview_rows_with_errors=preview_rows_with_errors,
        schema_columns=IFRS17_SHEET_SCHEMAS.get(report.get('sheet_type'), []) if report_ready else [],
        validated_total=report.get('validated_total') if report_ready else None,
        control_total=report.get('control_total') if report_ready else None,
        differential=report.get('differential') if report_ready else None,
        column_error_summary=report.get('column_error_summary') if report_ready else [],
        amount_group_label=report.get('amount_group_label') if report_ready else '',
        error_amount_total=report.get('error_amount_total') if report_ready else None,
        existing_import_count=existing_import_count,
        validation_elapsed_seconds=report.get('elapsed_seconds') if report_ready else None,
    )


IFRS17_PREVIEW_LIMIT = 500
IFRS17_STREAM_CHUNK_ROWS = 5_000  # rows validated per chunk -- keeps the SSE
# connection emitting bytes regularly during the run (see validate_ifrs17_stream),
# instead of one single blocking call for the whole file, which is what let a
# proxy/gunicorn timeout kill large runs before they could finish. Kept small
# (not 50,000) because the worst-case gap between progress messages is one
# chunk's full processing time, and an error-dense chunk takes meaningfully
# longer than a clean one of the same size (every failing rule adds per-row
# Python work) -- a smaller chunk caps that worst case low regardless of how
# invalid the file is.


@app.route('/<company_slug>/save-validation-file-ifrs17', methods=['POST'])
@require_company_access
def save_validation_file_ifrs17(company_slug):
    """
    Stage step for the IFRS17 streaming validation flow: saves the uploaded
    file to disk and remembers it in the session, WITHOUT running any
    validation. Returns fast (just a file save) no matter the file's size --
    the actual, potentially slow validation happens afterwards via
    validate_ifrs17_stream(), called by the browser as a second step
    (EventSource GET request) once this POST succeeds.

    Kept as a separate route (rather than folding staging into
    validate_ifrs17_stream itself) because file uploads need a POST body,
    while EventSource can only issue GET requests -- same reason the existing
    Custom validation flow splits into save_validation_file + validate_stream.
    """
    comp = get_company_context(company_slug)
    if not comp:
        return jsonify({"success": False, "error": "Company not found."}), 404

    sheet_type = request.form.get('sheet_type') or ''
    date_from_raw = request.form.get('date_from') or ''
    date_to_raw = request.form.get('date_to') or ''
    file = request.files.get('file')

    if sheet_type not in IFRS17_SHEET_SCHEMAS:
        return jsonify({"success": False, "error": "Please select a valid IFRS 17 sheet type."}), 400
    date_from = parse_ddmmyyyy_or_iso(date_from_raw)
    date_to = parse_ddmmyyyy_or_iso(date_to_raw)
    if not date_from or not date_to:
        return jsonify({"success": False, "error": "Please choose a From and To date for this validation run."}), 400
    if date_from > date_to:
        return jsonify({"success": False, "error": "The From date must be on or before the To date."}), 400
    if not file or not file.filename:
        return jsonify({"success": False, "error": "Please choose a file to validate."}), 400

    filename_lower = file.filename.lower()
    if not filename_lower.endswith(('.csv', '.xlsx', '.xls', '.xlsb')):
        return jsonify({"success": False, "error": "Only .csv, .xlsx, .xls, and .xlsb files are accepted."}), 400

    header_mapping = (session.get('ifrs17_header_mapping') or {}).get(sheet_type)
    if not mapping_is_complete(sheet_type, header_mapping):
        return jsonify({
            "success": False,
            "error": "Please complete Header Mapping (Step 2) for this sheet type before running validation.",
        }), 400

    lob_mapping = session.get('ifrs17_lob_mapping')
    if not lob_mapping_is_complete(lob_mapping):
        return jsonify({
            "success": False,
            "error": "Please complete LOB Detailed Mapping (Step 3) before running validation.",
        }), 400

    ext = os.path.splitext(file.filename)[1].lower()
    staged_path = f"/tmp/ifrs17_upload_{company_slug}_{session['user_id']}{ext}"
    file.save(staged_path)

    # data_year tags the imported rows for storage/dashboard partitioning
    # (company_data.data_year) -- derived from the From date's year, since
    # the DB schema partitions by a single year per import. A range that
    # straddles two calendar years is still validated correctly (the
    # date-range row filter uses the real From/To dates), it just gets
    # tagged under the From date's year for storage purposes.
    session['ifrs17_pending_path'] = staged_path
    session['ifrs17_pending_company_slug'] = company_slug
    session['ifrs17_pending_sheet_type'] = sheet_type
    session['ifrs17_pending_data_year'] = str(date_from.year)
    session['ifrs17_pending_date_from'] = date_from.isoformat()
    session['ifrs17_pending_date_to'] = date_to.isoformat()

    return jsonify({"success": True})


@app.route('/<company_slug>/validate-ifrs17-stream')
@require_company_access
def validate_ifrs17_stream(company_slug):
    """
    Runs IFRS17 validation in IFRS17_STREAM_CHUNK_ROWS-row chunks, streaming
    a small SSE progress message after each chunk -- so the connection keeps
    emitting bytes throughout a long run instead of going silent for the
    entire duration (which is what let a large file exceed a proxy/gunicorn
    timeout and come back as "Operation failed" even though the server was
    still working).

    IMPORTANT: this does not write anything to `session` while the generator
    below is running. Flask/Werkzeug decides the Set-Cookie header for a
    streaming response BEFORE the generator's body is consumed -- any
    session write that happened only once bytes were already streaming would
    silently never make it into a cookie. So results are written to two
    small files on disk instead (report + payload), and the *next* ordinary
    (non-streaming) request -- company_validation_ifrs17's GET -- picks them
    up and moves them into the session normally. See the "ready-file" hook
    at the top of company_validation_ifrs17().
    """
    comp = get_company_context(company_slug)
    if not comp:
        return "Company not found.", 404

    staged_path = session.get('ifrs17_pending_path')
    if (not staged_path or session.get('ifrs17_pending_company_slug') != company_slug
            or not os.path.exists(staged_path)):
        return "No staged file found. Please upload a file first.", 400

    sheet_type = session.get('ifrs17_pending_sheet_type') or ''
    data_year = session.get('ifrs17_pending_data_year') or ''
    date_from = parse_ddmmyyyy_or_iso(session.get('ifrs17_pending_date_from') or '')
    date_to = parse_ddmmyyyy_or_iso(session.get('ifrs17_pending_date_to') or '')
    header_mapping = (session.get('ifrs17_header_mapping') or {}).get(sheet_type)
    lob_mapping = session.get('ifrs17_lob_mapping')
    filename_lower = staged_path.lower()
    user_id = session['user_id']
    validation_started = time.perf_counter()

    try:
        df = read_ifrs17_upload_dataframe(staged_path, filename_lower, sheet_name=sheet_type)
    except Exception as e:
        error_message = str(e)

        def error_stream():
            yield f"event: fatal\ndata: {json.dumps({'error': f'Could not read the file: {error_message}'})}\n\n"
        return Response(error_stream(), mimetype='text/event-stream')

    try:
        df, mapping_error = remap_uploaded_headers(df, sheet_type, header_mapping)
        if not mapping_error:
            # LOB Detailed Mapping (Step 3) -- rewrite the file's actual LOB
            # text to canonical values once, up front, same as header
            # remapping, before any chunk is validated.
            df = remap_lob_values(df, lob_mapping)
    except Exception as e:
        df, mapping_error = None, str(e)

    if mapping_error:
        def mapping_err_stream():
            yield f"event: fatal\ndata: {json.dumps({'error': mapping_error})}\n\n"
        return Response(mapping_err_stream(), mimetype='text/event-stream')

    if len(df) < 1:
        def empty_stream():
            yield f"event: fatal\ndata: {json.dumps({'error': 'The uploaded sheet is completely empty.'})}\n\n"
        return Response(empty_stream(), mimetype='text/event-stream')

    header_row = df.iloc[[0]]
    body_all = df.iloc[1:].reset_index(drop=True)
    total_rows = len(body_all)

    def generate():
        overall_valid = True
        report_rows = []
        payload_accum = []
        error_columns = []
        processed = 0
        raw_row_count_total = 0
        filtered_row_count_total = 0

        row_range = range(0, total_rows, IFRS17_STREAM_CHUNK_ROWS) if total_rows else [0]
        for start in row_range:
            try:
                chunk_body = body_all.iloc[start:start + IFRS17_STREAM_CHUNK_ROWS]
                # Reusing validate_ifrs17_dataframe UNCHANGED per chunk -- it
                # expects row 0 to be the header, so that row is re-attached to
                # every chunk rather than rewriting any of its column rules here.
                chunk_df = pd.concat([header_row, chunk_body], ignore_index=True) if len(chunk_body) else header_row

                (chunk_header_valid, chunk_overall_valid, chunk_report_rows,
                 chunk_payload_accum, chunk_header_error, chunk_error_columns,
                 chunk_raw_count, chunk_filtered_count) = validate_ifrs17_dataframe(
                    chunk_df, sheet_type, date_from=date_from, date_to=date_to, header_mapping=header_mapping,
                )
            except Exception as e:
                yield f"event: fatal\ndata: {json.dumps({'error': f'Validation failed while processing rows {start + 2}-{start + len(chunk_body) + 1}: {str(e)}'})}\n\n"
                return

            if not chunk_header_valid:
                yield f"event: fatal\ndata: {json.dumps({'error': chunk_header_error})}\n\n"
                return

            overall_valid = overall_valid and chunk_overall_valid
            report_rows.extend(chunk_report_rows)
            payload_accum.extend(chunk_payload_accum)
            error_columns.extend(chunk_error_columns)
            raw_row_count_total += chunk_raw_count
            filtered_row_count_total += chunk_filtered_count
            processed += len(chunk_body)

            percent = round((processed / total_rows) * 100, 1) if total_rows else 100
            yield f"data: {json.dumps({'processed': processed, 'total': total_rows, 'percent': percent})}\n\n"

        # --- Finalization -----------------------------------------------
        # Everything below runs once, after every chunk has been validated.
        # It's wrapped in its own try/except because this response has
        # already started streaming -- if anything here throws uncaught, the
        # connection just dies mid-flight with no proper HTTP response,
        # which Nginx reports as a bare 502 with no indication of what
        # actually went wrong. Catching it here means the browser gets a
        # real 'fatal' event with the actual error message instead.
        try:
            invalid_count = sum(1 for row in report_rows if str(row[0]).startswith('INVALID'))

            amount_col = TOTAL_AMOUNT_COLUMNS.get(sheet_type)
            validated_total = 0.0
            if amount_col:
                for row_dict, row in zip(payload_accum, report_rows):
                    if str(row[0]) != 'VALID':
                        continue
                    cell = str(row_dict.get(amount_col, '')).strip()
                    if cell:
                        try:
                            validated_total += float(cell)
                        except ValueError:
                            pass
            validated_total = round(validated_total, 3)

            ifrs17_control_totals = session.get('ifrs17_control_totals') or {}
            control_total = ifrs17_control_totals.get(sheet_type)
            differential = round(validated_total - control_total, 3) if control_total is not None else None

            # --- Requirement #6: per-column error summary + amount rollup ---
            column_error_counts = {}
            for cols in error_columns:
                for col in cols:
                    column_error_counts[col] = column_error_counts.get(col, 0) + 1
            total_selected_rows = filtered_row_count_total or len(report_rows)

            amount_group_cols = AMOUNT_GROUP_COLUMNS.get(sheet_type, [])

            def _row_amount_group_value(row_dict):
                total = 0.0
                for col in amount_group_cols:
                    cell = str(row_dict.get(col, '')).strip()
                    if cell:
                        try:
                            total += float(cell)
                        except ValueError:
                            pass
                return total

            # Per-column amount: for every column that has at least one
            # error, sum the row's amount-group value (Paid+Outstanding /
            # Received+Outstanding-from-RI / Premium alone, depending on
            # sheet type) across every row where THAT specific column
            # errored -- a row with 3 errored columns contributes its amount
            # to all 3 column totals, not just one.
            column_error_amounts = {}
            for row_dict, cols in zip(payload_accum, error_columns):
                if not cols:
                    continue
                row_amount = _row_amount_group_value(row_dict)
                for col in cols:
                    column_error_amounts[col] = column_error_amounts.get(col, 0.0) + row_amount

            column_error_summary = [
                {
                    'column': col,
                    'error_count': column_error_counts.get(col, 0),
                    'percent_of_total': round((column_error_counts.get(col, 0) / total_selected_rows) * 100, 2)
                                        if total_selected_rows else 0,
                    'error_amount': round(column_error_amounts.get(col, 0.0), 3),
                }
                for col in IFRS17_SHEET_SCHEMAS[sheet_type]
            ]
            error_amount_total = 0.0
            for row_dict, row in zip(payload_accum, report_rows):
                if not str(row[0]).startswith('INVALID'):
                    continue
                error_amount_total += _row_amount_group_value(row_dict)
            error_amount_total = round(error_amount_total, 3)

            # Export needs EVERY invalid row across the whole file, not just
            # the first 500 -- that 500-row cap exists only so the on-screen
            # preview table doesn't try to render a huge HTML table. Build
            # that separately here, uncapped, and store it on disk alongside
            # the preview (this file was never in the session cookie, so
            # there's no header-size limit to worry about -- see
            # load_ifrs17_report_details()'s docstring). all_rows_full/
            # all_cols_full (every row, valid or not) backs the "download
            # full validated sheet" export from requirement #7.
            error_rows_full = []
            error_cols_full = []
            for row, cols in zip(report_rows, error_columns):
                if str(row[0]).startswith('INVALID'):
                    error_rows_full.append(row)
                    error_cols_full.append(cols)

            report = {
                'company_slug': company_slug, 'sheet_type': sheet_type, 'data_year': data_year,
                'date_from': date_from.strftime('%d/%m/%Y') if date_from else None,
                'date_to': date_to.strftime('%d/%m/%Y') if date_to else None,
                'overall_valid': overall_valid, 'header_error': None,
                'raw_row_count': raw_row_count_total, 'row_count': len(report_rows), 'invalid_count': invalid_count,
                'preview_rows': report_rows[:IFRS17_PREVIEW_LIMIT],
                'preview_error_cols': error_columns[:IFRS17_PREVIEW_LIMIT],
                'error_rows': error_rows_full,
                'error_cols': error_cols_full,
                'all_rows_full': report_rows,
                'all_cols_full': error_columns,
                'column_error_summary': column_error_summary,
                'amount_group_label': AMOUNT_GROUP_LABELS.get(sheet_type, ''),
                'error_amount_total': error_amount_total,
                'validated_total': validated_total, 'control_total': control_total, 'differential': differential,
                'elapsed_seconds': round(time.perf_counter() - validation_started, 2),
            }

            if report_rows:
                # Requirement: two importable sets -- "validated rows only"
                # (skips whatever failed) and "all selected rows from the
                # period" (imports the invalid ones too, verbatim). Both are
                # written whenever there's at least one selected row; which
                # one actually gets used is chosen on the results page, not
                # here.
                valid_payload = [
                    row_dict for row_dict, row in zip(payload_accum, report_rows)
                    if str(row[0]) == 'VALID'
                ]
                ifrs17_payload_path_valid = f"/tmp/ifrs17_payload_valid_{company_slug}_{user_id}.json"
                with open(ifrs17_payload_path_valid, 'w') as f:
                    json.dump(valid_payload, f, default=str)
                report['payload_path_valid'] = ifrs17_payload_path_valid
                report['valid_row_count'] = len(valid_payload)

                ifrs17_payload_path_all = f"/tmp/ifrs17_payload_all_{company_slug}_{user_id}.json"
                with open(ifrs17_payload_path_all, 'w') as f:
                    json.dump(payload_accum, f, default=str)
                report['payload_path_all'] = ifrs17_payload_path_all
                report['payload_row_count'] = len(payload_accum)

            # Small file (preview capped at 500 rows) -- this is the "ready-file"
            # company_validation_ifrs17()'s GET picks up on the very next request
            # and moves into the session normally (see the note in this route's
            # docstring for why it can't just write session here directly).
            ready_path = f"/tmp/ifrs17_report_ready_{company_slug}_{user_id}.json"
            with open(ready_path, 'w') as f:
                json.dump(report, f, default=str)

            log_action(
                user_id, 'IFRS17_VALIDATION',
                f"Validated '{os.path.basename(staged_path)}' against IFRS17 '{sheet_type}' -- "
                f"{'PASSED' if overall_valid else f'FAILED ({invalid_count} invalid rows)'}",
                comp['id']
            )

            try:
                os.remove(staged_path)
            except OSError:
                pass
        except Exception as e:
            yield f"event: fatal\ndata: {json.dumps({'error': f'Validation finished but finalizing the result failed: {str(e)}'})}\n\n"
            return

        yield f"event: done\ndata: {json.dumps({'overall_valid': overall_valid})}\n\n"

    resp = Response(stream_with_context(generate()), mimetype='text/event-stream')
    resp.headers['Cache-Control'] = 'no-cache'
    resp.headers['X-Accel-Buffering'] = 'no'
    return resp


@app.route('/<company_slug>/import-ifrs17-to-database', methods=['POST'])
@require_company_access
def import_ifrs17_to_database(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))
    import_started = time.perf_counter()

    import_mode = (request.form.get('import_mode') or 'valid_only').strip()
    if import_mode not in ('valid_only', 'all_rows'):
        import_mode = 'valid_only'

    payload = session.get('ifrs17_last_payload')
    if not payload or payload.get('company_slug') != company_slug:
        flash('No validated IFRS 17 data is staged to import.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    if import_mode == 'all_rows':
        payload_path = payload.get('payload_path_all')
        row_count = payload.get('payload_row_count')
        mode_label = 'all selected rows for the period (including any invalid rows)'
    else:
        payload_path = payload.get('payload_path_valid')
        row_count = payload.get('valid_row_count')
        mode_label = 'validated rows only'

    if not payload_path or not os.path.exists(payload_path):
        flash('Staged validation data could not be found on disk. Please re-run validation.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))
    if not row_count:
        flash(f'There are no rows to import under "{mode_label}" for this run.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    # --- Gate ---------------------------------------------------------------
    # Import used to require Differential == 0 (i.e. the whole file valid)
    # before ANY import was allowed. Per requirement, both import options are
    # now available whenever there's at least one row in that set -- the
    # reconciliation figures (validated/uploaded/differential) are shown
    # alongside the buttons on the results page so this is an informed
    # choice, not a blind one, but they're advisory here rather than a hard
    # block. What's still enforced server-side: the staged data must belong
    # to this exact company + sheet_type from the most recent run (can't
    # replay an import against a report from a different run/company).
    report = session.get('ifrs17_last_report')
    if (not report or report.get('company_slug') != company_slug
            or report.get('sheet_type') != payload.get('sheet_type')):
        flash(
            'Import is blocked because the staged data no longer matches the most '
            'recent validation run. Please re-run validation.',
            'error'
        )
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    sheet_type = payload['sheet_type']
    data_year = payload['data_year']

    try:
        with open(payload_path, 'r') as f:
            rows = json.load(f)
    except Exception as e:
        flash(f"Could not read staged validation data: {str(e)}", "error")
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    # --- THE ASYNC FIX: Spawn the Background Thread ---
    threading.Thread(
        target=run_import_in_background,
        args=(comp['id'], sheet_type, data_year, rows, session['user_id'], True),
        daemon=True
    ).start()

    # Clean up staged files and state (both payload variants, since they
    # were both derived from the run that's about to be superseded).
    for path_key in ('payload_path_valid', 'payload_path_all'):
        stale_path = payload.get(path_key)
        if stale_path:
            try:
                os.remove(stale_path)
            except OSError:
                pass

    session.pop('ifrs17_last_payload', None)
    session.pop('ifrs17_last_report', None)

    log_action(
        session['user_id'], 'IFRS17_IMPORT',
        f"Started import of {len(rows)} row(s) ({mode_label}) into IFRS17 '{sheet_type}' ({data_year})",
        comp['id']
    )

    flash(f"IFRS 17 import process started in the background -- {len(rows)} row(s) ({mode_label}) are writing to the database. You can continue using the website.", "success")
    return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))


@app.route('/<company_slug>/export-ifrs17-validation-errors')
@require_company_access
def export_ifrs17_validation_errors(company_slug):
    """Exports the last failed IFRS17 run's INVALID rows + reasons to Excel,
    same pattern as the existing export_validation_errors()."""
    report = session.get('ifrs17_last_report')
    if not report or report.get('company_slug') != company_slug or report.get('overall_valid'):
        flash('No failed IFRS 17 validation run to export.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    # preview_rows lives on disk, not in the session (see
    # load_ifrs17_report_details()) -- session only has small scalar fields.
    details = load_ifrs17_report_details(company_slug, session['user_id'])
    if not details:
        flash('The validation result for this run is no longer available -- please re-run validation.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    sheet_type = report['sheet_type']
    columns = ['Status'] + IFRS17_SHEET_SCHEMAS[sheet_type]
    # Prefer the full uncapped error list (added alongside the on-screen
    # preview); fall back to filtering preview_rows for older report files
    # written before this field existed, so a stale details file on disk
    # doesn't hard-fail the export.
    if 'error_rows' in details:
        invalid_rows = details.get('error_rows', [])
    else:
        invalid_rows = [r for r in details.get('preview_rows', []) if str(r[0]).startswith('INVALID')]

    out_df = pd.DataFrame(invalid_rows, columns=columns)
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], f"ifrs17_errors_{company_slug}_{sheet_type.replace(' ', '_')}.xlsx")
    out_df.to_excel(output_path, index=False)
    return send_file(output_path, as_attachment=True, download_name=f"{sheet_type}_validation_errors.xlsx")


@app.route('/<company_slug>/export-ifrs17-full-sheet')
@require_company_access
def export_ifrs17_full_sheet(company_slug):
    """
    Requirement #7: downloads EVERY validated row (VALID and INVALID alike,
    with the same Status/reason column the on-screen preview shows) --
    available after any run, pass or fail, unlike the errors-only export
    above. Backed by report['all_rows_full'], which is never capped at
    IFRS17_PREVIEW_LIMIT the way the on-screen preview is.
    """
    report = session.get('ifrs17_last_report')
    if not report or report.get('company_slug') != company_slug:
        flash('No IFRS 17 validation run to export.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    details = load_ifrs17_report_details(company_slug, session['user_id'])
    if not details:
        flash('The validation result for this run is no longer available -- please re-run validation.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    sheet_type = report['sheet_type']
    columns = ['Status'] + IFRS17_SHEET_SCHEMAS[sheet_type]
    all_rows = details.get('all_rows_full')
    if all_rows is None:
        # Older report file predating this field -- best-effort fallback to
        # whatever the capped preview holds rather than a hard failure.
        all_rows = details.get('preview_rows', [])

    out_df = pd.DataFrame(all_rows, columns=columns)
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], f"ifrs17_full_{company_slug}_{sheet_type.replace(' ', '_')}.xlsx")
    out_df.to_excel(output_path, index=False)
    return send_file(output_path, as_attachment=True, download_name=f"{sheet_type}_validated_sheet.xlsx")


@app.route('/<company_slug>/export-ifrs17-error-summary')
@require_company_access
def export_ifrs17_error_summary(company_slug):
    """
    Requirement #6/#7: downloads the per-column error-count/percentage
    breakdown plus the reconciliation figures (validated/uploaded/
    differential) and the amount-group total for erroring rows, as its own
    small Excel report -- separate from the full row-level exports above.
    """
    report = session.get('ifrs17_last_report')
    if not report or report.get('company_slug') != company_slug:
        flash('No IFRS 17 validation run to export.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    sheet_type = report['sheet_type']
    summary_rows = report.get('column_error_summary') or []

    columns_df = pd.DataFrame(
        [(r['column'], r['error_count'], r['percent_of_total'], r.get('error_amount', 0))
         for r in summary_rows],
        columns=['Column', 'Error Count', 'Percent of Selected Rows (%)', f"Amount in Error ({report.get('amount_group_label', '')})"],
    )
    totals_df = pd.DataFrame([
        ['Sheet Type', sheet_type],
        ['Period From', report.get('date_from')],
        ['Period To', report.get('date_to')],
        ['Total Rows in File', report.get('raw_row_count')],
        ['Rows Selected for Period', report.get('row_count')],
        ['Invalid Rows', report.get('invalid_count')],
        ['Validated Total Amount', report.get('validated_total')],
        ['Uploaded Total Amount', report.get('control_total')],
        ['Differential', report.get('differential')],
        [f"Total {report.get('amount_group_label', '')} in Error Rows", report.get('error_amount_total')],
    ], columns=['Metric', 'Value'])

    output_path = os.path.join(app.config['UPLOAD_FOLDER'], f"ifrs17_error_summary_{company_slug}_{sheet_type.replace(' ', '_')}.xlsx")
    with pd.ExcelWriter(output_path) as writer:
        totals_df.to_excel(writer, sheet_name='Summary', index=False)
        columns_df.to_excel(writer, sheet_name='Errors by Column', index=False)
    return send_file(output_path, as_attachment=True, download_name=f"{sheet_type}_error_summary.xlsx")


# =====================================================================
# --- Site Administration: overview, Groups CRUD, Users CRUD ---
# =====================================================================

@app.route('/site-management')
@require_site_admin
def site_management():
    """
    The single GET route behind the whole Site Administration page -- loads
    every group/user/company plus both many-to-many mappings (which groups
    can access which companies, which users belong to which groups) up
    front in one page load. The tab-switching itself (Groups/Users/
    Companies/Branding/VM Resources/Database) is pure client-side JS over
    this one render; VM Resources and Database additionally fetch their own
    data lazily/on-poll from separate JSON endpoints below, rather than
    being included in this initial payload.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM `groups` ORDER BY name")
            groups = cursor.fetchall()

            cursor.execute("SELECT id, username, role, must_change_password FROM users ORDER BY username")
            users = cursor.fetchall()

            cursor.execute("SELECT * FROM companies ORDER BY name")
            companies = cursor.fetchall()

            # group_id -> set of company_id it can access
            cursor.execute("SELECT group_id, company_id FROM group_company_access")
            group_company_map = {}
            for row in cursor.fetchall():
                group_company_map.setdefault(row['group_id'], set()).add(row['company_id'])

            # user_id -> set of group_id they belong to
            cursor.execute("SELECT user_id, group_id FROM user_groups")
            user_group_map = {}
            for row in cursor.fetchall():
                user_group_map.setdefault(row['user_id'], set()).add(row['group_id'])
    finally:
        conn.close()

    return render_template(
        'site-management.html',
        groups=groups,
        users=users,
        companies=companies,
        group_company_map=group_company_map,
        user_group_map=user_group_map,
        SITE_GROUP_NAME=SITE_GROUP_NAME,
        unread_notification_count=get_unread_notification_count()
    )


# --- Notifications bell: alerts site admins to new client uploads ---

@app.route('/site-management/notifications')
@require_site_admin
def site_notifications():
    """JSON for the notification bell dropdown -- the 50 most recent
    notifications (read or not) plus the current unread count for the
    badge."""
    try:
        notifications = get_notifications(unread_only=False, limit=50)
        for n in notifications:
            n['created_at'] = n['created_at'].strftime('%d/%m/%Y %H:%M') if n['created_at'] else None
        return jsonify({
            "success": True,
            "unread_count": get_unread_notification_count(),
            "notifications": notifications
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/site-management/notifications/mark-read', methods=['POST'])
@require_site_admin
def site_notifications_mark_read():
    """Marks every notification as read -- called when the bell dropdown is
    opened, so the badge clears once the admin has actually seen the list."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE notifications SET is_read = 1 WHERE is_read = 0")
        conn.commit()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        conn.close()


@app.route('/site-management/vm-stats')
@require_site_admin
def vm_stats():
    """
    Live VM resource utilization for the "VM Resources" tab, polled every few
    seconds from the browser. Returns a fresh error message instead of a 500
    if psutil isn't installed on the server (`pip install psutil`), so the
    rest of Site Administration keeps working either way.
    """
    if not PSUTIL_AVAILABLE:
        return jsonify({
            "success": False,
            "error": "psutil is not installed on the server. Run: pip install psutil"
        }), 500

    # Blocking 0.3s per-core sample gives a real (not zero) reading on every
    # single call, unlike psutil's usual "compare to last call" mode -- important
    # since this is a fresh poll every few seconds, not a long-running process.
    per_core = psutil.cpu_percent(interval=0.3, percpu=True)
    cpu_percent = round(sum(per_core) / len(per_core), 1) if per_core else 0.0

    mem = psutil.virtual_memory()
    swap = psutil.swap_memory()

    disks = []
    seen_mounts = set()
    for part in psutil.disk_partitions(all=False):
        if part.mountpoint in seen_mounts:
            continue
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except (PermissionError, OSError):
            continue
        seen_mounts.add(part.mountpoint)
        disks.append({
            "mountpoint": part.mountpoint,
            "device": part.device,
            "fstype": part.fstype,
            "total_gb": round(usage.total / (1024 ** 3), 2),
            "used_gb": round(usage.used / (1024 ** 3), 2),
            "percent": usage.percent
        })

    net = psutil.net_io_counters()

    try:
        load1, load5, load15 = os.getloadavg()
    except (AttributeError, OSError):
        load1 = load5 = load15 = None

    return jsonify({
        "success": True,
        "cpu": {
            "percent": cpu_percent,
            "per_core": [round(c, 1) for c in per_core],
            "logical_cores": psutil.cpu_count(logical=True),
            "physical_cores": psutil.cpu_count(logical=False)
        },
        "memory": {
            "total_gb": round(mem.total / (1024 ** 3), 2),
            "used_gb": round(mem.used / (1024 ** 3), 2),
            "percent": mem.percent
        },
        "swap": {
            "total_gb": round(swap.total / (1024 ** 3), 2),
            "used_gb": round(swap.used / (1024 ** 3), 2),
            "percent": swap.percent
        },
        "disks": disks,
        "network": {
            "bytes_sent": net.bytes_sent,
            "bytes_recv": net.bytes_recv
        },
        "uptime_seconds": int(time.time() - psutil.boot_time()),
        "load_avg": {"1min": load1, "5min": load5, "15min": load15},
        "process_count": len(psutil.pids())
    })


def compute_database_overview():
    """
    Aggregate database size stats (from MySQL's own information_schema stats
    -- fast, no table scan) plus a per-company breakdown computed directly
    from company_data (records, distinct data types/years, actual data size
    via SUM(LENGTH(row_data)), first/last import, and a 30-day activity
    count). Used by the "Database" tab.

    Note: individual table names/sizes are intentionally NOT exposed in the
    response -- only used internally to build the aggregate total -- since
    surfacing raw schema/table info in the UI is unnecessary exposure for
    what's meant to be a high-level usage overview.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # NOTE: every column here must be explicitly aliased. Without an
            # alias, MySQL returns information_schema.TABLES columns using
            # their original (uppercase) names -- e.g. 'DATA_LENGTH' instead
            # of 'data_length' -- which breaks DictCursor's t['data_length']
            # lookups below with a bare KeyError.
            cursor.execute("""
                SELECT table_rows AS table_rows,
                       data_length AS data_length,
                       index_length AS index_length
                FROM information_schema.TABLES
                WHERE table_schema = DATABASE()
            """)
            table_rows = cursor.fetchall()

            cursor.execute("""
                SELECT c.id, c.name, c.slug,
                       COUNT(cd.id) AS records,
                       COUNT(DISTINCT cd.component_name) AS data_types,
                       COUNT(DISTINCT cd.data_year) AS years_covered,
                       COALESCE(SUM(LENGTH(cd.row_data)), 0) AS data_bytes,
                       MIN(cd.created_at) AS first_import,
                       MAX(cd.created_at) AS last_import,
                       SUM(CASE WHEN cd.created_at >= NOW() - INTERVAL 30 DAY THEN 1 ELSE 0 END) AS records_last_30d
                FROM companies c
                LEFT JOIN company_data cd ON cd.company_id = c.id
                GROUP BY c.id, c.name, c.slug
                ORDER BY records DESC
            """)
            company_rows = cursor.fetchall()
    finally:
        conn.close()

    total_bytes = 0
    total_rows_estimate = 0
    for t in table_rows:
        data_b = t['data_length'] or 0
        idx_b = t['index_length'] or 0
        total_bytes += data_b + idx_b
        total_rows_estimate += t['table_rows'] or 0

    companies_overview = []
    for c in company_rows:
        companies_overview.append({
            "id": c['id'],
            "name": c['name'],
            "slug": c['slug'],
            "records": c['records'] or 0,
            "data_types": c['data_types'] or 0,
            "years_covered": c['years_covered'] or 0,
            "data_mb": round((c['data_bytes'] or 0) / (1024 ** 2), 2),
            "first_import": c['first_import'].strftime('%d/%m/%Y') if c['first_import'] else None,
            "last_import": c['last_import'].strftime('%d/%m/%Y %H:%M') if c['last_import'] else None,
            "records_last_30d": c['records_last_30d'] or 0
        })

    return {
        "companies": companies_overview,
        "total_size_mb": round(total_bytes / (1024 ** 2), 2),
        "total_rows_estimate": total_rows_estimate
    }


@app.route('/site-management/database-overview')
@require_site_admin
def database_overview():
    """JSON for the "Database" tab -- fetched once per tab-open plus a manual
    Refresh button, not polled continuously like VM Resources, since these
    numbers don't change second to second and SUM(LENGTH(row_data)) does scan
    company_data."""
    try:
        return jsonify({"success": True, **compute_database_overview()})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/site-management/database-overview/company/<int:company_id>')
@require_site_admin
def database_overview_company_detail(company_id):
    """Drill-down for a single company row on the Database tab: every
    submission batch (grouped by data type + year) with record/policy counts
    and premium/commission totals, so an admin can see exactly what's been
    submitted without needing to open the Dashboard."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, name, slug FROM companies WHERE id = %s", (company_id,))
            company = cursor.fetchone()
            if not company:
                return jsonify({"success": False, "error": "Company not found."}), 404

            cursor.execute("""
                SELECT component_name, data_year, row_data, created_at
                FROM company_data
                WHERE company_id = %s
            """, (company_id,))
            rows = cursor.fetchall()
    finally:
        conn.close()

    groups = {}
    for r in rows:
        key = (r.get('component_name') or '—', r.get('data_year') or '—')
        g = groups.setdefault(key, {
            "records": 0, "policy_numbers": set(),
            "gross_premium": 0.0, "gross_commission": 0.0,
            "ri_premium": 0.0, "ri_commission": 0.0,
            "first_import": None, "last_import": None
        })
        fields = parse_row_data(r.get('row_data'))
        g["records"] += 1
        policy_no = fields.get('Policy Number')
        if policy_no:
            g["policy_numbers"].add(policy_no)
        g["gross_premium"] += to_float(fields.get('GROSS Premium Amount (EGP)'))
        g["gross_commission"] += to_float(fields.get('GROSS Commission Amount (EGP)'))
        g["ri_premium"] += to_float(fields.get('RI Premium Amount (EGP)'))
        g["ri_commission"] += to_float(fields.get('RI Commission Amount (EGP)'))
        created = r.get('created_at')
        if created:
            if g["first_import"] is None or created < g["first_import"]:
                g["first_import"] = created
            if g["last_import"] is None or created > g["last_import"]:
                g["last_import"] = created

    breakdown = []
    for (data_type, year), g in groups.items():
        breakdown.append({
            "data_type": data_type,
            "year": year,
            "records": g["records"],
            "policies": len(g["policy_numbers"]),
            "gross_premium": round(g["gross_premium"], 2),
            "gross_commission": round(g["gross_commission"], 2),
            "ri_premium": round(g["ri_premium"], 2),
            "ri_commission": round(g["ri_commission"], 2),
            "first_import": g["first_import"].strftime('%d/%m/%Y') if g["first_import"] else None,
            "last_import": g["last_import"].strftime('%d/%m/%Y %H:%M') if g["last_import"] else None
        })
    breakdown.sort(key=lambda b: (b["data_type"], str(b["year"])))

    return jsonify({
        "success": True,
        "company": {"id": company['id'], "name": company['name'], "slug": company['slug']},
        "breakdown": breakdown
    })


# --- Site branding: upload / remove the sidebar logo ---

@app.route('/site-management/logo/upload', methods=['POST'])
@require_site_admin
def upload_site_logo():
    """Replaces the site-wide sidebar logo shown on every company page.
    Stored as a fixed filename ('logo' + original extension) so old
    references never go stale, with the previous file cleaned up if the
    extension changed (e.g. swapping a .png logo for a .svg one)."""
    file = request.files.get('logo_file')
    if not file or file.filename == '':
        flash('No logo file selected.', 'error')
        return redirect(url_for('site_management'))

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_LOGO_EXTENSIONS:
        flash(f"Unsupported logo format '{ext}'. Use PNG, JPG, SVG, WEBP or GIF.", 'error')
        return redirect(url_for('site_management'))

    cfg = load_site_config()
    old_filename = cfg.get('logo_filename')

    new_filename = f"logo{ext}"
    file.save(os.path.join(LOGO_UPLOAD_DIR, new_filename))

    # Clean up a stale logo file left over from a previous upload with a different extension.
    if old_filename and old_filename != new_filename:
        old_path = os.path.join(LOGO_UPLOAD_DIR, old_filename)
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except OSError:
                pass

    cfg['logo_filename'] = new_filename
    save_site_config(cfg)

    log_action(session['user_id'], 'SITE_LOGO_UPDATE', "Uploaded a new site logo.")
    flash('Logo updated.', 'success')
    return redirect(url_for('site_management'))


@app.route('/site-management/logo/remove', methods=['POST'])
@require_site_admin
def remove_site_logo():
    """Deletes the current logo file and clears it from site_config.json,
    reverting every page back to the default fallback icon."""
    cfg = load_site_config()
    logo_filename = cfg.get('logo_filename')
    if logo_filename:
        old_path = os.path.join(LOGO_UPLOAD_DIR, logo_filename)
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except OSError:
                pass
        cfg.pop('logo_filename', None)
        save_site_config(cfg)
        log_action(session['user_id'], 'SITE_LOGO_UPDATE', "Removed the site logo.")
        flash('Logo removed.', 'success')
    else:
        flash('There is no logo to remove.', 'error')

    return redirect(url_for('site_management'))


# --- Companies: create / delete ---
# New companies automatically appear on the Global Welcome page and get the full
# welcome/overview/dashboard/data-validation/history-log flow for free, since every
# company route renders from the shared templates/company/*.html — nothing to wire
# up per company.

@app.route('/site-management/companies/create', methods=['POST'])
@require_site_admin
def create_company():
    """Creates a new company: inserts the DB row (name + generated slug),
    then builds its on-disk folder tree. If the DB insert succeeds but the
    folder tree fails (e.g. permissions), the company still exists and is
    usable -- it just needs its folders created manually, which is flagged
    to the admin rather than silently left broken or rolled back."""
    name = (request.form.get('name') or '').strip()
    if not name:
        flash('Company name is required.', 'error')
        return redirect(url_for('site_management'))

    slug = generate_slug(name)
    if not slug:
        flash('Company name must contain at least one letter or number.', 'error')
        return redirect(url_for('site_management'))

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("INSERT INTO companies (name, slug) VALUES (%s, %s)", (name, slug))
        conn.commit()
        log_action(session['user_id'], 'COMPANY_CREATE', f"Created company '{name}' (slug: {slug})")

        # Build the on-disk folder tree for this company: one folder per
        # validation data type (Claim - Paid, Claim - OCR, Premium, Balance Data Temp).
        try:
            create_company_folder_tree(slug)
            flash(f"Company '{name}' created. It's already live at /{slug}/welcome and visible on Global Welcome.", 'success')
        except OSError as folder_err:
            flash(
                f"Company '{name}' created, but its data folders could not be created automatically "
                f"({folder_err}). Please create them manually under {COMPANY_DATA_ROOT}/{slug}/.",
                'error'
            )
    except pymysql.err.IntegrityError:
        flash(f"A company named '{name}' (slug '{slug}') already exists.", 'error')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


@app.route('/site-management/companies/<int:company_id>/delete', methods=['POST'])
@require_site_admin
def delete_company(company_id):
    """
    Deletes a company outright. group_company_access rows are cleared
    automatically first (pure access-grant links, not real data), but
    company_data / history_log rows are NOT touched -- if either still has
    rows for this company, the DELETE raises IntegrityError and is caught
    below with an explanatory message, on purpose: unlike users/groups,
    real imported business data should never be silently deleted as a side
    effect of removing a company record.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT name FROM companies WHERE id = %s", (company_id,))
            comp = cursor.fetchone()
            if not comp:
                flash('Company not found.', 'error')
                return redirect(url_for('site_management'))

            # group_company_access is a pure many-to-many link -- it's not
            # real business data, just an access grant, so it's safe (and
            # expected) to clear automatically rather than block deletion on
            # it. Without this, deletion failed for essentially every
            # properly-configured company, since granting group access is
            # normal setup, not an edge case.
            cursor.execute("DELETE FROM group_company_access WHERE company_id = %s", (company_id,))
            cursor.execute("DELETE FROM companies WHERE id = %s", (company_id,))
        conn.commit()
        log_action(session['user_id'], 'COMPANY_DELETE', f"Deleted company '{comp['name']}'")
        flash(f"Company '{comp['name']}' deleted.", 'success')
    except pymysql.err.IntegrityError:
        conn.rollback()
        flash("Can't delete this company while it still has linked data (uploaded records, history log entries). Remove those first.", 'error')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


# --- Export: full group/company + user/group access matrix ---

@app.route('/site-management/export-matrix')
@require_site_admin
def export_access_matrix():
    """
    Three-sheet Excel export of the entire access model in one file:
    which groups can see which companies, which users belong to which
    groups, and the company registry itself. site-group is shown with
    access to every company on sheet 1 regardless of group_company_access
    contents, since its access is unconditional (see is_site_admin).
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, name FROM `groups` ORDER BY name")
            groups = cursor.fetchall()

            cursor.execute("SELECT id, name FROM companies ORDER BY name")
            companies = cursor.fetchall()

            cursor.execute("SELECT id, username, role FROM users ORDER BY username")
            users = cursor.fetchall()

            cursor.execute("SELECT group_id, company_id FROM group_company_access")
            group_company_map = {}
            for row in cursor.fetchall():
                group_company_map.setdefault(row['group_id'], set()).add(row['company_id'])

            cursor.execute("SELECT user_id, group_id FROM user_groups")
            user_group_map = {}
            for row in cursor.fetchall():
                user_group_map.setdefault(row['user_id'], set()).add(row['group_id'])
    finally:
        conn.close()

    # Sheet 1: Group x Company access matrix
    group_company_rows = []
    for g in groups:
        row = {'Group': g['name']}
        for c in companies:
            if g['name'] == SITE_GROUP_NAME:
                row[c['name']] = 'YES'
            else:
                row[c['name']] = 'YES' if c['id'] in group_company_map.get(g['id'], set()) else ''
        group_company_rows.append(row)
    df_group_company = pd.DataFrame(group_company_rows) if group_company_rows else pd.DataFrame(columns=['Group'])

    # Sheet 2: User x Group membership matrix
    user_group_rows = []
    for u in users:
        row = {'Username': u['username'], 'Role': u['role']}
        for g in groups:
            row[g['name']] = 'YES' if g['id'] in user_group_map.get(u['id'], set()) else ''
        user_group_rows.append(row)
    df_user_group = pd.DataFrame(user_group_rows) if user_group_rows else pd.DataFrame(columns=['Username', 'Role'])

    # Sheet 3: Company registry (name/slug)
    df_companies = pd.DataFrame(companies) if companies else pd.DataFrame(columns=['id', 'name', 'slug'])

    output_path = f"/tmp/site_access_matrix_{session['user_id']}.xlsx"
    with pd.ExcelWriter(output_path) as writer:
        df_group_company.to_excel(writer, sheet_name='Group-Company Access', index=False)
        df_user_group.to_excel(writer, sheet_name='User-Group Membership', index=False)
        df_companies.to_excel(writer, sheet_name='Companies', index=False)

    log_action(session['user_id'], 'EXPORT', "Exported full site access matrix (groups, users, companies)")
    return send_file(output_path, as_attachment=True, download_name="site_access_matrix.xlsx")


# --- Groups: create / delete / update company access ---

@app.route('/site-management/groups/create', methods=['POST'])
@require_site_admin
def create_group():
    """Creates a new group with no company access or members yet -- both
    are granted afterward via update_group_companies / update_user_groups.
    'site-group' itself is expected to already exist and isn't special-cased
    here; its unconditional-admin behavior comes entirely from its name
    matching SITE_GROUP_NAME (see is_site_admin)."""
    name = (request.form.get('name') or '').strip()
    description = (request.form.get('description') or '').strip()

    if not name:
        flash('Group name is required.', 'error')
        return redirect(url_for('site_management'))

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("INSERT INTO `groups` (name, description) VALUES (%s, %s)", (name, description))
        conn.commit()
        log_action(session['user_id'], 'GROUP_CREATE', f"Created group '{name}'")
        flash(f"Group '{name}' created.", 'success')
    except pymysql.err.IntegrityError:
        flash(f"A group named '{name}' already exists.", 'error')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


@app.route('/site-management/groups/<int:group_id>/delete', methods=['POST'])
@require_site_admin
def delete_group(group_id):
    """
    Deletes a group outright. Unlike delete_company, a group carries no
    business data of its own -- everything about it is access-control links
    (group_company_access, user_groups), so those are always cleared
    automatically and this should basically always succeed. The
    information_schema scan below is a catch-all for any OTHER FK reference
    to groups.id that isn't one of those two known links (see delete_user's
    docstring for why hardcoding table names one at a time isn't reliable
    enough on its own). 'site-group' itself is explicitly protected and can
    never be deleted through this route.
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT name FROM `groups` WHERE id = %s", (group_id,))
            group = cursor.fetchone()
            if not group:
                flash('Group not found.', 'error')
                return redirect(url_for('site_management'))
            if group['name'] == SITE_GROUP_NAME:
                flash("The 'site-group' cannot be deleted.", 'error')
                return redirect(url_for('site_management'))

            # Both of these are pure many-to-many links -- safe to clear
            # automatically when the group itself goes away, same reasoning
            # as group_company_access in delete_company.
            cursor.execute("DELETE FROM group_company_access WHERE group_id = %s", (group_id,))
            cursor.execute("DELETE FROM user_groups WHERE group_id = %s", (group_id,))

            # Catch-all for anything else referencing groups.id that isn't
            # one of the two links above -- a group carries no business data
            # of its own (unlike a company), so every dependent row here is
            # safe to detach automatically rather than block on.
            cursor.execute("""
                SELECT kcu.TABLE_NAME, kcu.COLUMN_NAME, col.IS_NULLABLE
                FROM information_schema.KEY_COLUMN_USAGE kcu
                JOIN information_schema.COLUMNS col
                  ON col.TABLE_SCHEMA = kcu.TABLE_SCHEMA
                 AND col.TABLE_NAME = kcu.TABLE_NAME
                 AND col.COLUMN_NAME = kcu.COLUMN_NAME
                WHERE kcu.TABLE_SCHEMA = DATABASE()
                  AND kcu.REFERENCED_TABLE_NAME = 'groups'
                  AND kcu.REFERENCED_COLUMN_NAME = 'id'
                  AND kcu.TABLE_NAME NOT IN ('group_company_access', 'user_groups')
            """)
            for ref in cursor.fetchall():
                table, column, nullable = ref['TABLE_NAME'], ref['COLUMN_NAME'], ref['IS_NULLABLE']
                if nullable == 'YES':
                    cursor.execute(f"UPDATE `{table}` SET `{column}` = NULL WHERE `{column}` = %s", (group_id,))
                else:
                    cursor.execute(f"DELETE FROM `{table}` WHERE `{column}` = %s", (group_id,))

            cursor.execute("DELETE FROM `groups` WHERE id = %s", (group_id,))
        conn.commit()
        log_action(session['user_id'], 'GROUP_DELETE', f"Deleted group '{group['name']}'")
        flash(f"Group '{group['name']}' deleted.", 'success')
    except pymysql.err.IntegrityError:
        conn.rollback()
        flash(f"Can't delete group '{group['name']}' -- something else still references it.", 'error')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


@app.route('/site-management/groups/<int:group_id>/companies', methods=['POST'])
@require_site_admin
def update_group_companies(group_id):
    """Overwrite a group's company access with whatever checkboxes were submitted."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT name FROM `groups` WHERE id = %s", (group_id,))
            group = cursor.fetchone()
            if not group:
                flash('Group not found.', 'error')
                return redirect(url_for('site_management'))

            if group['name'] == SITE_GROUP_NAME:
                flash("'site-group' already has full access to every company by definition.", 'error')
                return redirect(url_for('site_management'))

            selected_company_ids = request.form.getlist('company_ids', type=int)

            cursor.execute("DELETE FROM group_company_access WHERE group_id = %s", (group_id,))
            for company_id in selected_company_ids:
                cursor.execute(
                    "INSERT INTO group_company_access (group_id, company_id) VALUES (%s, %s)",
                    (group_id, company_id)
                )
        conn.commit()
        log_action(session['user_id'], 'GROUP_PERMISSIONS_UPDATE',
                   f"Updated company access for group '{group['name']}'")
        flash(f"Company access updated for '{group['name']}'.", 'success')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


# --- Users: create / delete / update group memberships ---

@app.route('/site-management/users/create', methods=['POST'])
@require_site_admin
def create_user():
    """Creates a new user account with no group memberships yet (granted
    afterward via update_user_groups) -- a brand-new user can log in
    immediately but won't see any company until added to a group with
    access to one. must_change_password is always set to 1: a brand-new
    account's password was just typed by whoever created it (usually a site
    admin), so it's treated the same as an admin-set temporary password --
    the new owner is forced to pick their own on first login."""
    username = (request.form.get('username') or '').strip()
    password = request.form.get('password') or ''
    role = (request.form.get('role') or 'user').strip()

    if not username or not password:
        flash('Username and password are required.', 'error')
        return redirect(url_for('site_management'))

    if role not in VALID_USER_ROLES:
        flash('Invalid role selected.', 'error')
        return redirect(url_for('site_management'))

    password_hash = generate_password_hash(password)

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "INSERT INTO users (username, password_hash, role, must_change_password) "
                "VALUES (%s, %s, %s, 1)",
                (username, password_hash, role)
            )
        conn.commit()
        log_action(session['user_id'], 'USER_CREATE', f"Created user '{username}'")
        flash(f"User '{username}' created. They'll be asked to set their own password on first login.", 'success')
    except pymysql.err.IntegrityError:
        flash(f"A user named '{username}' already exists.", 'error')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


@app.route('/site-management/users/<int:user_id>/delete', methods=['POST'])
@require_site_admin
def delete_user(user_id):
    """
    Deletes a user account outright -- deliberately does NOT block on
    History Log activity the way it originally did. An audit trail
    shouldn't hold an account hostage: instead, the username is baked into
    each of that user's history_log descriptions as plain text ("[deleted
    user: rootuser] ...") before the user_id reference is detached, so the
    log entries survive and stay attributable even after the account is
    gone (see the LEFT JOIN + COALESCE in company_history/export_history,
    which is what makes those orphaned rows still display correctly).

    The information_schema scan below is a catch-all for any OTHER real FK
    referencing users.id beyond history_log/user_groups: nullable columns
    get detached (row survives), non-nullable columns get their row deleted
    outright (a dependent row that can't exist without a valid user, same
    idea as user_groups membership rows). This exists because hardcoding
    table names one at a time kept missing references that only surfaced
    once someone actually hit them in production.
    """
    if user_id == session['user_id']:
        flash("You can't delete your own account while logged in.", 'error')
        return redirect(url_for('site_management'))

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT username FROM users WHERE id = %s", (user_id,))
            user = cursor.fetchone()
            if not user:
                flash('User not found.', 'error')
                return redirect(url_for('site_management'))
            username = user['username']

            # Preserve who performed each logged action before detaching the
            # reference, so it survives even after the join below can no
            # longer resolve a username from a deleted account.
            cursor.execute(
                "UPDATE history_log SET description = CONCAT('[deleted user: ', %s, '] ', description) "
                "WHERE user_id = %s",
                (username, user_id)
            )

            # user_groups is a pure membership link -- always safe to delete outright.
            cursor.execute("DELETE FROM user_groups WHERE user_id = %s", (user_id,))

            # Catch-all: rather than hardcoding every table that might
            # reference users.id (and missing one, as happened with the
            # first pass of this fix), ask MySQL's own metadata for every
            # real FK pointing at this table and detach all of them.
            # Nullable columns get NULLed so the row survives (history_log,
            # company_data, and anything else that turns up); non-nullable
            # columns get their row deleted outright, since a dependent row
            # can't exist without a valid user reference.
            cursor.execute("""
                SELECT kcu.TABLE_NAME, kcu.COLUMN_NAME, col.IS_NULLABLE
                FROM information_schema.KEY_COLUMN_USAGE kcu
                JOIN information_schema.COLUMNS col
                  ON col.TABLE_SCHEMA = kcu.TABLE_SCHEMA
                 AND col.TABLE_NAME = kcu.TABLE_NAME
                 AND col.COLUMN_NAME = kcu.COLUMN_NAME
                WHERE kcu.TABLE_SCHEMA = DATABASE()
                  AND kcu.REFERENCED_TABLE_NAME = 'users'
                  AND kcu.REFERENCED_COLUMN_NAME = 'id'
                  AND kcu.TABLE_NAME != 'user_groups'
            """)
            for ref in cursor.fetchall():
                table, column, nullable = ref['TABLE_NAME'], ref['COLUMN_NAME'], ref['IS_NULLABLE']
                if nullable == 'YES':
                    cursor.execute(f"UPDATE `{table}` SET `{column}` = NULL WHERE `{column}` = %s", (user_id,))
                else:
                    cursor.execute(f"DELETE FROM `{table}` WHERE `{column}` = %s", (user_id,))

            cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
        conn.commit()
        log_action(session['user_id'], 'USER_DELETE', f"Deleted user '{username}'")
        flash(f"User '{username}' deleted. Their History Log entries are kept for audit purposes.", 'success')
    except pymysql.err.IntegrityError:
        conn.rollback()
        flash(f"Can't delete '{username}' -- something else still references their account.", 'error')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


@app.route('/site-management/users/<int:user_id>/groups', methods=['POST'])
@require_site_admin
def update_user_groups(user_id):
    """Overwrite a user's group memberships with whatever checkboxes were submitted."""
    selected_group_ids = request.form.getlist('group_ids', type=int)

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT username FROM users WHERE id = %s", (user_id,))
            user = cursor.fetchone()
            if not user:
                flash('User not found.', 'error')
                return redirect(url_for('site_management'))

            cursor.execute("DELETE FROM user_groups WHERE user_id = %s", (user_id,))
            for group_id in selected_group_ids:
                cursor.execute(
                    "INSERT INTO user_groups (user_id, group_id) VALUES (%s, %s)",
                    (user_id, group_id)
                )
        conn.commit()
        log_action(session['user_id'], 'USER_GROUPS_UPDATE', f"Updated group memberships for '{user['username']}'")
        flash(f"Group memberships updated for '{user['username']}'.", 'success')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


@app.route('/site-management/users/<int:user_id>/reset-password', methods=['POST'])
@require_site_admin
def reset_user_password(user_id):
    """
    Admin sets a specific new password for a user directly -- no need to
    know or verify their current one, unlike the self-service
    change_password flow. Pairs with a checkbox in the same form
    ("require_change") that, when checked (the default), also sets
    must_change_password so the user is prompted to pick their own new
    password the next time they log in with the temporary one just set here.
    """
    new_password = request.form.get('new_password') or ''
    require_change = request.form.get('require_change') == '1'

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT username FROM users WHERE id = %s", (user_id,))
            user = cursor.fetchone()
            if not user:
                flash('User not found.', 'error')
                return redirect(url_for('site_management'))

            if len(new_password) < 8:
                flash('New password must be at least 8 characters long.', 'error')
                return redirect(url_for('site_management'))

            new_hash = generate_password_hash(new_password)
            cursor.execute(
                "UPDATE users SET password_hash = %s, must_change_password = %s WHERE id = %s",
                (new_hash, 1 if require_change else 0, user_id)
            )
        conn.commit()
        log_action(
            session['user_id'], 'PASSWORD_RESET',
            f"Reset password for '{user['username']}'" +
            (" (must change at next login)" if require_change else "")
        )
        flash(f"Password reset for '{user['username']}'.", 'success')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


@app.route('/site-management/users/<int:user_id>/force-password-change', methods=['POST'])
@require_site_admin
def toggle_force_password_change(user_id):
    """
    Flips must_change_password WITHOUT touching the password itself --
    for flagging an existing account to be forced through the change flow
    at its next login (e.g. a suspected compromise) without the admin
    needing to pick a temporary password themselves. Submitted from a
    checkbox in the Users table that auto-submits on change (see
    site-management.html), so this is a plain form POST + redirect like
    every other admin action here, not an AJAX toggle.
    """
    enabled = request.form.get('enabled') == '1'

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT username FROM users WHERE id = %s", (user_id,))
            user = cursor.fetchone()
            if not user:
                flash('User not found.', 'error')
                return redirect(url_for('site_management'))

            cursor.execute(
                "UPDATE users SET must_change_password = %s WHERE id = %s",
                (1 if enabled else 0, user_id)
            )
        conn.commit()
        state = "will be required to change their password at next login" if enabled \
            else "no longer required to change their password at next login"
        log_action(session['user_id'], 'PASSWORD_POLICY_TOGGLE', f"'{user['username']}' {state}")
        flash(f"'{user['username']}' {state}.", 'success')
    finally:
        conn.close()

    return redirect(url_for('site_management'))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)