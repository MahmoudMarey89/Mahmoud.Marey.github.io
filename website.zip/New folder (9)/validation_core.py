"""
validation_core.py
-------------------
The Custom-validation column rules (Policy Number / dates / LOB / Gross_RI /
amounts / Financial Year Quarter / cross-field date checks), extracted out of
app.py's validate_dataframe() so bigdata_worker.py can run the *same* rules,
chunk-by-chunk, on files far larger than what a single Flask request should
ever hold in memory.

This is a deliberate copy, not a refactor-in-place of app.py:
  - The existing small-file flow (save_validation_file -> validate_stream ->
    import_to_database) is untouched and keeps working exactly as it does
    today for the normal case (files up to the low hundreds of thousands of
    rows).
  - This module is the one used by the new bulk-import path only.

If you later want to collapse these into one implementation, the rules here
are line-for-line equivalent to app.py's validate_dataframe body checks --
diff the two if you ever change a rule, so both stay in sync.
"""
import pandas as pd

EXPECTED_HEADERS = [
    "Policy Number", "Issue Date", "Written Date", "Period From", "Period to",
    "Premium/Commission Due Date", "LOB Detailed", "Gross_RI", "RI Treaty Type",
    "GROSS Premium Amount (EGP)", "GROSS Commission Amount (EGP)",
    "RI Premium Amount (EGP)", "RI Commission Amount (EGP)",
    "Financial Year Quarter", "source_file", "source_page"
]

LOB_VALID_WORDS = [
    "MARINE_CARGO", "MOTOR_COMPREHENSIVE", "FIRE", "ENGINEERING",
    "GENERAL_ACCIDENT", "CREDIT", "MARINE_INLAND", "MEDICAL",
    "MOTOR_TPL", "AVIATION", "MARINE_HULL", "OIL", "TRAVEL_POOL", "TPL_POOL"
]
GROSS_RI_WORDS = ["GROSS", "RI"]


def header_is_valid(first_row_cells):
    """first_row_cells: list of stripped strings for the sheet's row 0."""
    header_structure_ok = (first_row_cells == EXPECTED_HEADERS)
    has_no_duplicates = (len(first_row_cells) == len(set(first_row_cells)))
    return header_structure_ok and has_no_duplicates, header_structure_ok, has_no_duplicates


def header_error_message(first_row_cells, header_structure_ok, has_no_duplicates):
    missing = [col for col in EXPECTED_HEADERS if col not in first_row_cells]
    extra = [col for col in first_row_cells if col not in EXPECTED_HEADERS]
    err_msg = "Header Mismatch Error -> "
    if missing:
        err_msg += f"Missing expected column(s): {missing}. "
    if extra:
        err_msg += f"Found unexpected column(s): {extra}. "
    if not missing and not extra and not header_structure_ok:
        err_msg += "Columns are named correctly but sequence order is out of bounds."
    if not has_no_duplicates:
        err_msg += "Duplicate headings detected inside the row."
    return err_msg


def _clean_cell_for_storage(value):
    if isinstance(value, pd.Timestamp):
        return value.strftime('%d/%m/%Y')
    return value


def validate_chunk(body, row_offset, col_width_ok=True):
    """
    Runs the full row-level rule set against one chunk of already-header-
    stripped data.

    body: DataFrame with EXPECTED_HEADERS columns, RangeIndex starting at 0
          for THIS CHUNK (not the whole file).
    row_offset: the 1-indexed spreadsheet row number of body's first row
                (e.g. chunk 3 starting at data row 400,001 -> row_offset=400001),
                used only to produce correct row numbers in error samples.
    col_width_ok: whether the chunk's original column count matched
                  len(EXPECTED_HEADERS) (checked by the caller against the
                  raw row before column names were assigned).

    Returns: (n_valid, n_invalid, error_samples, valid_rows)
      error_samples: list of dicts {row, details} -- caller is responsible
                     for capping how many of these it keeps overall.
      valid_rows: list of dicts (one per valid row), keyed by EXPECTED_HEADERS,
                  with corrected values (normalised dates, rounded amounts) --
                  same shape as app.py's payload_accum.
    """
    body = body.copy()
    n = len(body)
    if n == 0:
        return 0, 0, [], []

    str_cols = {h: body[h].astype(str).str.strip() for h in EXPECTED_HEADERS}
    row_error_lists = [[] for _ in range(n)]

    def add_error(mask, message):
        idxs = body.index[mask]
        if len(idxs) == 0:
            return
        if isinstance(message, str):
            for i in idxs:
                row_error_lists[i].append(message)
        else:
            for i in idxs:
                row_error_lists[i].append(message(i))

    if not col_width_ok:
        msg = "Width mismatch: row does not have the expected number of columns"
        for i in range(n):
            row_error_lists[i].append(msg)

    # --- Column A: Policy Number ---
    add_error(str_cols["Policy Number"] == "", "Cell Policy Number is empty")

    def parse_dates(col):
        raw = str_cols[col]
        parsed = pd.to_datetime(raw, format="mixed", dayfirst=True, errors="coerce")
        parsed = parsed.dt.tz_localize(None).dt.normalize()
        return raw, parsed

    issue_raw, issue_parsed = parse_dates("Issue Date")
    written_raw, written_parsed = parse_dates("Written Date")
    pfrom_raw, pfrom_parsed = parse_dates("Period From")
    pto_raw, pto_parsed = parse_dates("Period to")
    due_raw, due_parsed = parse_dates("Premium/Commission Due Date")

    # --- Column B: Issue Date ---
    add_error(issue_raw == "", "Cell Issue Date is empty")
    add_error((issue_raw != "") & issue_parsed.isna(), "Invalid date format in Issue Date")
    valid_issue = (issue_raw != "") & issue_parsed.notna()
    body.loc[valid_issue, "Issue Date"] = issue_parsed[valid_issue].dt.strftime('%d/%m/%Y')

    # --- Columns C, D, E: Written Date / Period From / Period to ---
    for label, raw, parsed in [
        ("Written Date", written_raw, written_parsed),
        ("Period From", pfrom_raw, pfrom_parsed),
        ("Period to", pto_raw, pto_parsed),
    ]:
        add_error(raw == "", f"Cell {label} is empty")
        add_error((raw != "") & parsed.isna(), f"Invalid date format in {label}")
        valid_mask = (raw != "") & parsed.notna()
        body.loc[valid_mask, label] = parsed[valid_mask].dt.strftime('%d/%m/%Y')

    # --- Column F: Premium/Commission Due Date (optional) ---
    add_error((due_raw != "") & due_parsed.isna(), "Invalid date format in Premium/Commission Due Date")
    valid_due = (due_raw != "") & due_parsed.notna()
    body.loc[valid_due, "Premium/Commission Due Date"] = due_parsed[valid_due].dt.strftime('%d/%m/%Y')

    # --- Column G: LOB Detailed ---
    lob_col = str_cols["LOB Detailed"]
    add_error(~lob_col.isin(LOB_VALID_WORDS),
              lambda i: f"LOB Detailed '{lob_col[i]}' is not an authorised value")

    # --- Column H: Gross_RI ---
    gross_ri_raw = str_cols["Gross_RI"]
    add_error(~gross_ri_raw.isin(GROSS_RI_WORDS),
              lambda i: f"Gross_RI '{gross_ri_raw[i]}' is not an authorised value")
    is_gross = gross_ri_raw == "GROSS"
    is_ri = gross_ri_raw == "RI"

    def numeric_amount(col, required_mask, forbidden_mask, required_msg, forbidden_msg, invalid_msg):
        raw = str_cols[col]
        empty = raw == ""
        add_error(required_mask & empty, required_msg)
        add_error(forbidden_mask & ~empty, forbidden_msg)
        candidates = required_mask & ~empty
        numeric = pd.to_numeric(raw, errors="coerce")
        add_error(candidates & numeric.isna(), invalid_msg)
        good = candidates & numeric.notna()
        body.loc[good, col] = numeric[good].round(3).map(lambda v: f"{v:.3f}")
        return empty

    gross_prem_empty = numeric_amount(
        "GROSS Premium Amount (EGP)", is_gross, is_ri,
        "GROSS Premium Amount is mandatory when Gross_RI is 'GROSS'",
        "GROSS Premium Amount must be empty when Gross_RI is 'RI'",
        "GROSS Premium Amount must be a valid number",
    )

    gcomm_raw = str_cols["GROSS Commission Amount (EGP)"]
    gcomm_present = gcomm_raw != ""
    add_error(gcomm_present & gross_prem_empty,
              "GROSS Commission Amount provided but GROSS Premium Amount is missing")
    gcomm_numeric = pd.to_numeric(gcomm_raw, errors="coerce")
    add_error(gcomm_present & ~gross_prem_empty & gcomm_numeric.isna(),
              "GROSS Commission Amount must be a valid numeric amount")
    good = gcomm_present & ~gross_prem_empty & gcomm_numeric.notna()
    body.loc[good, "GROSS Commission Amount (EGP)"] = gcomm_numeric[good].round(3).map(lambda v: f"{v:.3f}")

    ri_prem_empty = numeric_amount(
        "RI Premium Amount (EGP)", is_ri, is_gross,
        "RI Premium Amount is mandatory when Gross_RI is 'RI'",
        "RI Premium Amount must be empty when Gross_RI is 'GROSS'",
        "RI Premium Amount must be a valid number",
    )

    ricomm_raw = str_cols["RI Commission Amount (EGP)"]
    ricomm_present = ricomm_raw != ""
    add_error(ricomm_present & ri_prem_empty,
              "RI Commission Amount provided but RI Premium Amount is missing")
    ricomm_numeric = pd.to_numeric(ricomm_raw, errors="coerce")
    add_error(ricomm_present & ~ri_prem_empty & ricomm_numeric.isna(),
              "RI Commission Amount must be a valid numeric amount")
    good = ricomm_present & ~ri_prem_empty & ricomm_numeric.notna()
    body.loc[good, "RI Commission Amount (EGP)"] = ricomm_numeric[good].round(3).map(lambda v: f"{v:.3f}")

    # --- Column N: Financial Year Quarter ---
    fyq_raw = str_cols["Financial Year Quarter"]
    add_error(fyq_raw == "", "Cell Financial Year Quarter is empty")
    has_written = written_parsed.notna()
    fyq_numeric = pd.to_numeric(fyq_raw, errors="coerce")
    checkable = (fyq_raw != "") & has_written
    written_year = written_parsed.dt.year
    bad_year = checkable & fyq_numeric.notna() & (fyq_numeric != written_year)
    add_error(bad_year,
              lambda i: (f"Year mismatch: Financial Year Quarter ({fyq_raw[i]}) "
                         f"does not match Written Date year ({int(written_year[i])})"))
    add_error(checkable & fyq_numeric.isna(), "Financial Year Quarter must be a numeric year")
    add_error((fyq_raw != "") & ~has_written, "Cannot validate Financial Year Quarter: Written Date is missing")

    # --- Cross-field date range checks ---
    both_wf = written_parsed.notna() & pfrom_parsed.notna()
    add_error(both_wf & (pfrom_parsed < written_parsed), "Period From must be on or after Written Date")
    both_ft = pfrom_parsed.notna() & pto_parsed.notna()
    add_error(both_ft & (pto_parsed < pfrom_parsed), "Period to must be after Period From")
    both_issue_due = issue_parsed.notna() & due_parsed.notna()
    add_error(both_issue_due & (due_parsed < issue_parsed),
              "Premium/Commission Due Date must be on or after Issue Date")

    # --- Assemble output ---
    all_rows = body.values.tolist()
    error_samples = []
    valid_rows = []
    n_valid = 0
    n_invalid = 0

    for i, current_row_cells in enumerate(all_rows):
        row_no = row_offset + i
        row_errors = row_error_lists[i]
        if row_errors:
            n_invalid += 1
            error_samples.append({
                "row": row_no,
                "details": f"Invalid data located -> {', '.join(row_errors)}",
            })
        else:
            n_valid += 1
            row_dict = {h: _clean_cell_for_storage(v) for h, v in zip(EXPECTED_HEADERS, current_row_cells)}
            valid_rows.append(row_dict)

    return n_valid, n_invalid, error_samples, valid_rows
