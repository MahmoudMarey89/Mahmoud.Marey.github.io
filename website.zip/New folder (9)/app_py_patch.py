# =============================================================================
# PATCH FOR app.py -- IFRS 17 Validation mode
#
# This file is NOT meant to run on its own. It's a set of blocks to paste
# into your real app.py, in the locations noted. app.py is 3,600+ lines and
# I only have the file as it stood when it was last uploaded to me, so
# rather than risk silently overwriting something you've changed since then,
# I've written this as explicit, copy-pasteable additions instead of
# regenerating the whole file.
# =============================================================================


# -----------------------------------------------------------------------------
# 1) IMPORT -- add near the top of app.py, with your other imports
# -----------------------------------------------------------------------------
from ifrs17_engine import (
    IFRS17_SHEET_SCHEMAS, IFRS17_DATA_TYPES,
    read_ifrs17_upload_dataframe, validate_ifrs17_dataframe,
)


# -----------------------------------------------------------------------------
# 2) FOLDER TREE -- extend create_company_folder_tree() so BOTH new and
#    existing companies get an IFRS17/<sheet type> folder tree alongside the
#    existing Custom Validation ones. Find your existing function:
#
#    def create_company_folder_tree(slug):
#        company_dir = os.path.join(COMPANY_DATA_ROOT, slug)
#        for sub in COMPANY_SUBFOLDERS:
#            os.makedirs(os.path.join(company_dir, sub), exist_ok=True)
#        return company_dir
#
#    Replace it with:
# -----------------------------------------------------------------------------
def create_company_folder_tree(slug):
    """Creates <COMPANY_DATA_ROOT>/<slug>/<subfolder> for every
    VALIDATION_DATA_TYPES entry (Custom Validation), plus
    <COMPANY_DATA_ROOT>/<slug>/IFRS17/<sheet type> for every IFRS17 sheet
    type -- for BOTH new companies (called at creation time) and, via the
    one-off migration snippet below, existing ones."""
    company_dir = os.path.join(COMPANY_DATA_ROOT, slug)
    for sub in COMPANY_SUBFOLDERS:
        os.makedirs(os.path.join(company_dir, sub), exist_ok=True)
    for sheet in IFRS17_DATA_TYPES:
        os.makedirs(os.path.join(company_dir, 'IFRS17', sheet), exist_ok=True)
    return company_dir


# One-off migration for companies that already exist (run once, e.g. from a
# Flask shell: `python3 -c "from app import backfill_ifrs17_folders; backfill_ifrs17_folders()"`)
def backfill_ifrs17_folders():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT slug FROM companies")
            slugs = [r['slug'] for r in cursor.fetchall()]
    finally:
        conn.close()
    for slug in slugs:
        create_company_folder_tree(slug)
    print(f"Backfilled IFRS17 folders for {len(slugs)} companies.")


# -----------------------------------------------------------------------------
# 3) MODE SWITCH ROUTE -- new route, add anywhere in the
#    "Multi-Tenant Segregated Path Routes" section
# -----------------------------------------------------------------------------
@app.route('/<company_slug>/set-mode/<mode>')
@require_company_access
def set_company_mode(company_slug, mode):
    """Sets which validation workspace (Custom vs IFRS 17) this session sees
    for this company -- stored per-company in the session so switching
    companies from the global Welcome grid doesn't carry a stale mode over,
    and the sidebar (company_sider.html) only shows nav items once one of
    the two Welcome buttons has actually been clicked."""
    if mode not in ('custom', 'ifrs17'):
        flash('Unknown validation mode.', 'error')
        return redirect(url_for('company_welcome', company_slug=company_slug))

    comp = get_company_context(company_slug)
    if not comp:
        flash('Company workspace not found.', 'error')
        return redirect(url_for('welcome_site'))

    session[f'mode_{company_slug}'] = mode
    if mode == 'custom':
        return redirect(url_for('company_overview', company_slug=company_slug))
    return redirect(url_for('company_overview_ifrs17', company_slug=company_slug))


# -----------------------------------------------------------------------------
# 4) UPDATE company_welcome() -- pass active_mode so Welcome can highlight
#    whichever mode is already open. Find your existing route:
#
#    @app.route('/<company_slug>/welcome')
#    @require_company_access
#    def company_welcome(company_slug):
#        comp = get_company_context(company_slug)
#        if not comp:
#            flash("Company workspace not found.", "error")
#            return redirect(url_for('welcome_site'))
#        return render_template(
#            'company/welcome.html',
#            company=comp,
#            active_page='welcome',
#            kpis=compute_overview_dashboard(comp['id'])
#        )
#
#    IMPORTANT: clicking "Company Welcome" from the sidebar (or landing here
#    fresh) is also the one deliberate way to CLEAR the current mode, so the
#    sidebar goes back to empty and the two big buttons are shown again --
#    add the session.pop line shown below.
# -----------------------------------------------------------------------------
@app.route('/<company_slug>/welcome')
@require_company_access
def company_welcome(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        flash("Company workspace not found.", "error")
        return redirect(url_for('welcome_site'))
    return render_template(
        'company/welcome.html',
        company=comp,
        active_page='welcome',
        kpis=compute_overview_dashboard(comp['id'])
    )
    # NOTE: the redesigned welcome.html itself reads session['mode_<slug>']
    # directly (via Jinja `session.get(...)`) to decide which of the two
    # cards shows "Currently open" -- it does NOT clear the mode on load, so
    # revisiting Welcome doesn't accidentally blank the sidebar on its own.
    # The sidebar only empties out when the person explicitly picks
    # "↺ Switch Validation Mode" and then hasn't clicked either button yet
    # -- which, on the Welcome page itself, both buttons are always shown
    # regardless of active_mode, so there's always a way back in.


# -----------------------------------------------------------------------------
# 5) DASHBOARD -- let the existing company_dashboard() serve IFRS17 records
#    too, filtered by ?framework=ifrs17. Find this block inside
#    company_dashboard():
#
#        available_types, available_years = get_company_filter_options(comp['id'])
#
#        return render_template(
#            'company/dashboard.html',
#            company=comp,
#            active_page='dashboard',
#            records=page_records,
#            columns=EXPECTED_HEADERS,
#            ...
#
#    Replace those lines with:
# -----------------------------------------------------------------------------
    framework = request.args.get('framework') or ''

    if framework == 'ifrs17':
        available_types = IFRS17_DATA_TYPES
        # Table columns depend on which IFRS17 sheet type is selected --
        # each of the 6 has a different schema. Until one is picked, show a
        # minimal placeholder set (Data Type / Year / Quarter alone still
        # render from the base columns in dashboard.html).
        columns = IFRS17_SHEET_SCHEMAS.get(data_type_filter, [])
        available_years = sorted({r.get('data_year') for r in records if r.get('data_year')}, reverse=True)
        active_page = 'dashboard-ifrs17'
    else:
        available_types, available_years = get_company_filter_options(comp['id'])
        columns = EXPECTED_HEADERS
        active_page = 'dashboard'

    return render_template(
        'company/dashboard.html',
        company=comp,
        active_page=active_page,
        records=page_records,
        columns=columns,
        total_count=total_count,
        page=page,
        total_pages=total_pages,
        page_size=DASHBOARD_PAGE_SIZE,
        available_types=available_types,
        available_years=available_years,
        filters={'data_type': data_type_filter, 'year': year_filter, 'quarter': quarter_filter, 'search': search}
    )
#
# NOTE: dashboard.html's export links (export_dashboard_data) currently
# don't carry the framework param through -- add framework=filters.data_type
# and framework=request.args.get('framework') to those two <a href> calls
# in dashboard.html if you want "Export Filtered/All Data" to also work
# for IFRS17 views; not wired in this patch to keep the diff minimal.


# -----------------------------------------------------------------------------
# 6) OVERVIEW IFRS 17 -- new route: generic per-sheet row counts + Amount
#    column totals (no loss/expense-ratio business logic -- those formulas
#    in compute_overview_dashboard are specific to the Custom schema's GROSS
#    Premium/Commission columns and don't have an IFRS17 equivalent defined
#    yet; tell me the actual IFRS17 KPI formulas you want and I'll build a
#    dedicated compute_ifrs17_dashboard() to match, the same way
#    compute_overview_dashboard was built for Custom).
# -----------------------------------------------------------------------------
@app.route('/<company_slug>/overview-ifrs17')
@require_company_access
def company_overview_ifrs17(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    sheet_summaries = []
    for sheet_name, columns in IFRS17_SHEET_SCHEMAS.items():
        records = fetch_company_records(comp['id'], data_type=sheet_name)
        amount_cols = [c for c in columns if 'amount' in c.lower()]
        amount_totals = {
            c: round(sum(to_float(r.get(c)) for r in records), 2)
            for c in amount_cols
        }
        sheet_summaries.append({
            'name': sheet_name,
            'row_count': len(records),
            'amount_totals': amount_totals,
        })

    return render_template(
        'company/overview-ifrs17.html',
        company=comp,
        active_page='overview-ifrs17',
        sheet_summaries=sheet_summaries,
    )


# -----------------------------------------------------------------------------
# 7) DATA VALIDATION IFRS 17 -- GET page + POST validate + POST import
#    Deliberately SYNCHRONOUS (no SSE/live progress like the Custom
#    validator's validate-stream) to keep this addition self-contained.
#    If you'll be running very large IFRS17 files (500k+ rows) through this
#    regularly, say so and I'll port it to the same SSE + batched-events
#    pattern as validate_stream().
# -----------------------------------------------------------------------------
@app.route('/<company_slug>/data-validation-ifrs17', methods=['GET'])
@require_company_access
def company_validation_ifrs17(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    report = session.get('ifrs17_last_report')
    report_ready = bool(report and report.get('company_slug') == company_slug)

    return render_template(
        'company/data-validation-ifrs17.html',
        company=comp,
        active_page='data-validation-ifrs17',
        sheet_types=IFRS17_DATA_TYPES,
        selected_sheet_type=report.get('sheet_type') if report_ready else '',
        selected_year=report.get('data_year') if report_ready else '',
        report_ready=report_ready,
        overall_valid=report.get('overall_valid') if report_ready else False,
        header_error=report.get('header_error') if report_ready else None,
        row_count=report.get('row_count') if report_ready else 0,
        invalid_count=report.get('invalid_count') if report_ready else 0,
        preview_rows=report.get('preview_rows') if report_ready else [],
        schema_columns=IFRS17_SHEET_SCHEMAS.get(report.get('sheet_type'), []) if report_ready else [],
    )


IFRS17_PREVIEW_LIMIT = 500


@app.route('/<company_slug>/validate-ifrs17', methods=['POST'])
@require_company_access
def validate_ifrs17(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    sheet_type = request.form.get('sheet_type') or ''
    data_year = request.form.get('data_year') or ''
    file = request.files.get('file')

    if sheet_type not in IFRS17_SHEET_SCHEMAS:
        flash('Please select a valid IFRS 17 sheet type.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))
    if not data_year:
        flash('Please provide a data year.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))
    if not file or not file.filename:
        flash('Please choose a file to validate.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    filename_lower = file.filename.lower()
    if not filename_lower.endswith(('.csv', '.xlsx', '.xls')):
        flash('Only .csv, .xlsx, and .xls files are accepted.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    try:
        df = read_ifrs17_upload_dataframe(file, filename_lower)
    except Exception as e:
        flash(f'Could not read the file: {e}', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    header_valid, overall_valid, report_rows, payload_accum, header_error = \
        validate_ifrs17_dataframe(df, sheet_type)

    if not header_valid:
        session['ifrs17_last_report'] = {
            'company_slug': company_slug, 'sheet_type': sheet_type, 'data_year': data_year,
            'overall_valid': False, 'header_error': header_error,
            'row_count': 0, 'invalid_count': 0, 'preview_rows': [],
        }
        session.pop('ifrs17_last_payload', None)
        flash('Validation failed: header does not match the template.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    invalid_count = sum(1 for row in report_rows if str(row[0]).startswith('INVALID'))

    session['ifrs17_last_report'] = {
        'company_slug': company_slug, 'sheet_type': sheet_type, 'data_year': data_year,
        'overall_valid': overall_valid, 'header_error': None,
        'row_count': len(report_rows), 'invalid_count': invalid_count,
        'preview_rows': report_rows[:IFRS17_PREVIEW_LIMIT],
    }
    # Only keep the row payloads in session when the file actually passed --
    # a failing run has nothing worth importing, and there's no reason to
    # hold a large invalid payload in the session store.
    if overall_valid:
        session['ifrs17_last_payload'] = {
            'company_slug': company_slug, 'sheet_type': sheet_type,
            'data_year': data_year, 'rows': payload_accum,
        }
    else:
        session.pop('ifrs17_last_payload', None)

    log_action(
        session['user_id'], 'IFRS17_VALIDATION',
        f"Validated '{file.filename}' against IFRS17 '{sheet_type}' -- "
        f"{'PASSED' if overall_valid else f'FAILED ({invalid_count} invalid rows)'}",
        comp['id']
    )

    return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))


@app.route('/<company_slug>/import-ifrs17-to-database', methods=['POST'])
@require_company_access
def import_ifrs17_to_database(company_slug):
    comp = get_company_context(company_slug)
    if not comp:
        return redirect(url_for('welcome_site'))

    payload = session.get('ifrs17_last_payload')
    if not payload or payload.get('company_slug') != company_slug:
        flash('No validated IFRS 17 data is staged to import.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    sheet_type = payload['sheet_type']
    data_year = payload['data_year']
    rows = payload['rows']

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            for row_dict in rows:
                cursor.execute(
                    """INSERT INTO company_data (company_id, component_name, data_year, row_data, uploaded_by, created_at)
                       VALUES (%s, %s, %s, %s, %s, NOW())""",
                    (comp['id'], sheet_type, data_year, json.dumps(row_dict), session['user_id'])
                )
        conn.commit()
    finally:
        conn.close()

    log_action(
        session['user_id'], 'IFRS17_IMPORT',
        f"Imported {len(rows)} row(s) into IFRS17 '{sheet_type}' ({data_year})",
        comp['id']
    )
    session.pop('ifrs17_last_payload', None)
    session.pop('ifrs17_last_report', None)
    flash(f"Imported {len(rows)} row(s) into '{sheet_type}'.", 'success')
    return redirect(url_for('company_dashboard', company_slug=company_slug, framework='ifrs17', data_type=sheet_type))


@app.route('/<company_slug>/export-ifrs17-validation-errors')
@require_company_access
def export_ifrs17_validation_errors(company_slug):
    """Exports the last failed IFRS17 run's INVALID rows + reasons to Excel,
    same pattern as the existing export_validation_errors()."""
    report = session.get('ifrs17_last_report')
    if not report or report.get('company_slug') != company_slug or report.get('overall_valid'):
        flash('No failed IFRS 17 validation run to export.', 'error')
        return redirect(url_for('company_validation_ifrs17', company_slug=company_slug))

    sheet_type = report['sheet_type']
    columns = ['Status'] + IFRS17_SHEET_SCHEMAS[sheet_type]
    invalid_rows = [r for r in report['preview_rows'] if str(r[0]).startswith('INVALID')]

    out_df = pd.DataFrame(invalid_rows, columns=columns)
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], f"ifrs17_errors_{company_slug}_{sheet_type.replace(' ', '_')}.xlsx")
    out_df.to_excel(output_path, index=False)
    return send_file(output_path, as_attachment=True, download_name=f"{sheet_type}_validation_errors.xlsx")
