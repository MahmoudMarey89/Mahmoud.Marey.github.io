"""
add_password_policy_column.py
-------------------------------
One-time migration: adds users.must_change_password, the flag that drives
the forced-password-change flow (new users, and any existing user an admin
flags via Site Administration -> Users).

Safe to run more than once -- checks INFORMATION_SCHEMA first and only adds
the column if it doesn't already exist.

IMPORTANT: existing users are set to 0 (not forced) by this migration, on
purpose -- defaulting everyone to "must change password" the moment this
ships would force your entire team to change their password on their next
login simultaneously, which is disruptive and not really what "new users
must change their password on first login" is asking for. Flag specific
existing accounts afterward from Site Administration -> Users if you want
particular people to be forced to change theirs (e.g. after a suspected
compromise, or when handing out a temporary password yourself).

Usage:
    python3 add_password_policy_column.py

Uses the same connection settings as app.py's get_db_connection(). If you've
already applied the credentials-to-environment-variables change, this script
picks those up too (falls back to the same literals app.py used before that
change, for a one-off migration run).
"""
import os
import pymysql

CONNECTION = dict(
    host=os.environ.get('DB_HOST', 'localhost'),
    user=os.environ.get('DB_USER', 'admin'),
    password=os.environ.get('DB_PASSWORD', 'Admin123'),
    database=os.environ.get('DB_NAME', 'corporate_portal'),
    cursorclass=pymysql.cursors.DictCursor,
)


def column_exists(cursor, table, column):
    cursor.execute(
        """SELECT COUNT(*) AS cnt FROM information_schema.columns
           WHERE table_schema = DATABASE() AND table_name = %s AND column_name = %s""",
        (table, column)
    )
    return cursor.fetchone()['cnt'] > 0


def main():
    conn = pymysql.connect(**CONNECTION)
    try:
        with conn.cursor() as cursor:
            if column_exists(cursor, 'users', 'must_change_password'):
                print("[skip]   users.must_change_password already exists")
            else:
                sql = (
                    "ALTER TABLE `users` "
                    "ADD COLUMN `must_change_password` TINYINT(1) NOT NULL DEFAULT 0"
                )
                print(f"[create] {sql}")
                cursor.execute(sql)
        conn.commit()
        print("\nDone. New users created from now on will default to must_change_password = 1")
        print("(set explicitly in create_user()'s INSERT) -- existing users stay at 0 until")
        print("an admin flags them from Site Administration -> Users.")
    finally:
        conn.close()


if __name__ == '__main__':
    main()
