# ifrs17_engine.py
# -----------------------------------------------------------------------------
# Schema + validation engine for the "IFRS 17 Validation" flow.
#
# Updated based on user requirements from System_Data_Template.xlsx:
# - Each sub-sheet has its own schema and is validated separately.
# - "Policy Number" not empty.
# - "LOB Detailed" should be the same with "IFRS Class", "FRA Reporting Class" (if exists)
#   and containing one of the specified LOB values.
# - "Period From" must be equal or after "Issue Date".
# - "Written Date" <= "Issue Date".
# - "Period to" > "Period From".
# - "Premium/Commission Due Date" >= "Issue Date".
# - "Premium Amount (EGP)" / "RI Premium Amount (EGP)" / "Amount Paid (EGP)" / 
#   "Amount Received from RI (EGP)" must include data number.3digits.
# - "Commission Amount (EGP)" / "RI Commission Amount (EGP)" empty or include data number.3digits.
# - "Underwriting Year" / "As at Date" / "RI Treaty Year" taken from "Issue Date".
# - Other columns (like "Reserving Class", etc.) are optional.
# -----------------------------------------------------------------------------

import pandas as pd
from datetime import date as _pydate
from dateutil import parser as _dateutil_parser

# --- The 6 IFRS 17 sheet schemas, taken verbatim (column order + names) from
#     System_Data_Template.xlsx -----------------------------------------------
IFRS17_SHEET_SCHEMAS = {
    "Gross Premium Data": [
        "LOB Detailed", "Reserving Class", "IFRS Class", "Policy Number",
        "Issue Date", "Written Date", "Period From", "Period to",
        "Premium/Commission Due Date", "Premium Amount (EGP)",
        "Commission Amount (EGP)", "Underwriting Year",
    ],
    "RI Premium Data": [
        "LOB Detailed", "Reserving Class", "IFRS Class", "FRA Reporting Class",
        "RI Treaty Type", "Policy Number", "RI Treaty Issue Date", "Written Date",
        "Period From", "Period to", "RI Premium Payment Due Date",
        "RI Premium Amount (EGP)", "RI Commission Amount (EGP)", "RI Treaty Year",
    ],
    "Gross Claims Data": [
        "Policy Number", "Claim Number", "LOB Detailed", "Reserving Class",
        "IFRS Class", "Policy Issue Date", "Policy Written Date", "Loss Date",
        "Reporting Date", "Payment Date", "Amount Paid (EGP)",
        "Amount Outstanding (EGP)", "As at Date",
    ],
    "RI Claims Data": [
        "Policy Number", "Claim Number", "LOB Detailed", "Reserving Class",
        "IFRS Class", "FRA Reporting Class", "RI Treaty Issue Date", "Written Date",
        "RI Treaty", "Loss Date", "Reporting Date", "Payment Date",
        "Amount Received from RI (EGP)", "Amount Outstanding from RI (EGP)", "As at Date",
    ],
    "Gross Claims Data - OS": [
        "Policy Number", "Claim Number", "LOB Detailed", "Reserving Class",
        "IFRS Class", "Policy Issue Date", "Policy Written Date", "Loss Date",
        "Reporting Date", "Payment Date", "Amount Paid (EGP)",
        "Amount Outstanding (EGP)", "As at Date",
    ],
    "RI Claims Data - OS": [
        "Policy Number", "Claim Number", "LOB Detailed", "Reserving Class",
        "IFRS Class", "FRA Reporting Class", "RI Treaty Issue Date", "Written Date",
        "RI Treaty", "Loss Date", "Reporting Date", "Payment Date",
        "Amount Received from RI (EGP)", "Amount Outstanding from RI (EGP)", "As at Date",
    ],
}

IFRS17_DATA_TYPES = list(IFRS17_SHEET_SCHEMAS.keys())

# Valid LOB values
VALID_LOBS = {
    "MARINE_CARGO", "MOTOR_COMPREHENSIVE", "FIRE", "ENGINEERING",
    "GENERAL_ACCIDENT", "CREDIT", "MARINE_INLAND", "MEDICAL",
    "MOTOR_TPL", "AVIATION", "MARINE_HULL", "OIL", "TRAVEL_POOL", "TPL_POOL"
}

# Define the specific rules for each sheet type
IFRS17_RULES = {
    "Gross Premium Data": {
        "issue_date_col": "Issue Date",
        "written_date_col": "Written Date",
        "period_from_col": "Period From",
        "period_to_col": "Period to",
        "due_date_col": "Premium/Commission Due Date",
        "premium_col": "Premium Amount (EGP)",
        "commission_col": "Commission Amount (EGP)",
        "year_check_col": "Underwriting Year",
        "year_check_kind": "number",
    },
    "RI Premium Data": {
        "issue_date_col": "RI Treaty Issue Date",
        "written_date_col": "Written Date",
        "period_from_col": "Period From",
        "period_to_col": "Period to",
        "due_date_col": "RI Premium Payment Due Date",
        "premium_col": "RI Premium Amount (EGP)",
        "commission_col": "RI Commission Amount (EGP)",
        "year_check_col": "RI Treaty Year",
        "year_check_kind": "number",
    },
    "Gross Claims Data": {
        "issue_date_col": "Policy Issue Date",
        "written_date_col": "Policy Written Date",
        "period_from_col": None,
        "period_to_col": None,
        "due_date_col": None,
        "premium_col": "Amount Paid (EGP)",
        "commission_col": None,
        "year_check_col": "As at Date",
        "year_check_kind": "date",
    },
    "RI Claims Data": {
        "issue_date_col": "RI Treaty Issue Date",
        "written_date_col": "Written Date",
        "period_from_col": None,
        "period_to_col": None,
        "due_date_col": None,
        "premium_col": "Amount Received from RI (EGP)",
        "commission_col": None,
        "year_check_col": "As at Date",
        "year_check_kind": "date",
    },
    "Gross Claims Data - OS": {
        "issue_date_col": "Policy Issue Date",
        "written_date_col": "Policy Written Date",
        "period_from_col": None,
        "period_to_col": None,
        "due_date_col": None,
        "premium_col": "Amount Paid (EGP)",
        "commission_col": None,
        "year_check_col": "As at Date",
        "year_check_kind": "date",
    },
    "RI Claims Data - OS": {
        "issue_date_col": "RI Treaty Issue Date",
        "written_date_col": "Written Date",
        "period_from_col": None,
        "period_to_col": None,
        "due_date_col": None,
        "premium_col": "Amount Received from RI (EGP)",
        "commission_col": None,
        "year_check_col": "As at Date",
        "year_check_kind": "date",
    },
}

# Bare-year columns
YEAR_NUMBER_COLUMNS = {"Underwriting Year", "RI Treaty Year"}

# Required columns per sheet (all others will be treated as optional)
REQUIRED_COLUMNS_PER_SHEET = {
    "Gross Premium Data": ["LOB Detailed", "IFRS Class", "Policy Number", "Issue Date", "Written Date", "Period From", "Period to", "Premium/Commission Due Date", "Premium Amount (EGP)", "Underwriting Year"],
    "RI Premium Data": ["LOB Detailed", "IFRS Class", "FRA Reporting Class", "Policy Number", "RI Treaty Issue Date", "Written Date", "Period From", "Period to", "RI Premium Payment Due Date", "RI Premium Amount (EGP)", "RI Treaty Year"],
    "Gross Claims Data": ["Policy Number", "Claim Number", "LOB Detailed", "IFRS Class", "Policy Issue Date", "Policy Written Date", "Loss Date", "Reporting Date", "Payment Date", "Amount Paid (EGP)", "Amount Outstanding (EGP)", "As at Date"],
    "RI Claims Data": ["Policy Number", "Claim Number", "LOB Detailed", "IFRS Class", "FRA Reporting Class", "RI Treaty Issue Date", "Written Date", "RI Treaty", "Loss Date", "Reporting Date", "Payment Date", "Amount Received from RI (EGP)", "Amount Outstanding from RI (EGP)", "As at Date"],
    "Gross Claims Data - OS": ["Policy Number", "Claim Number", "LOB Detailed", "IFRS Class", "Policy Issue Date", "Policy Written Date", "Loss Date", "Reporting Date", "Payment Date", "Amount Paid (EGP)", "Amount Outstanding (EGP)", "As at Date"],
    "RI Claims Data - OS": ["Policy Number", "Claim Number", "LOB Detailed", "IFRS Class", "FRA Reporting Class", "RI Treaty Issue Date", "Written Date", "RI Treaty", "Loss Date", "Reporting Date", "Payment Date", "Amount Received from RI (EGP)", "Amount Outstanding from RI (EGP)", "As at Date"],
}

TOTAL_AMOUNT_COLUMNS = {
    "Gross Premium Data": "Premium Amount (EGP)",
    "RI Premium Data": "RI Premium Amount (EGP)",
    "Gross Claims Data": "Amount Paid (EGP)",
    "RI Claims Data": "Amount Received from RI (EGP)",
    "Gross Claims Data - OS": "Amount Paid (EGP)",
    "RI Claims Data - OS": "Amount Received from RI (EGP)",
}

# Per requirement #6: the amount column(s) summed for rows that have ANY
# validation error, grouped the way the business actually reports them --
# Claims sheets combine Paid + Outstanding into one "amount at risk" figure,
# RI Claims sheets combine the RI-side equivalents, Premium sheets use their
# single premium column on its own.
AMOUNT_GROUP_COLUMNS = {
    "Gross Premium Data": ["Premium Amount (EGP)"],
    "RI Premium Data": ["RI Premium Amount (EGP)"],
    "Gross Claims Data": ["Amount Paid (EGP)", "Amount Outstanding (EGP)"],
    "RI Claims Data": ["Amount Received from RI (EGP)", "Amount Outstanding from RI (EGP)"],
    "Gross Claims Data - OS": ["Amount Paid (EGP)", "Amount Outstanding (EGP)"],
    "RI Claims Data - OS": ["Amount Received from RI (EGP)", "Amount Outstanding from RI (EGP)"],
}
AMOUNT_GROUP_LABELS = {
    "Gross Premium Data": "Premium Amount (EGP)",
    "RI Premium Data": "RI Premium Amount (EGP)",
    "Gross Claims Data": "Amount Paid (EGP) + Amount Outstanding (EGP)",
    "RI Claims Data": "Amount Received from RI (EGP) + Amount Outstanding from RI (EGP)",
    "Gross Claims Data - OS": "Amount Paid (EGP) + Amount Outstanding (EGP)",
    "RI Claims Data - OS": "Amount Received from RI (EGP) + Amount Outstanding from RI (EGP)",
}

IFRS17_UPR_FIELD_MAP = {
    "Gross Premium Data": {
        "period_from": "Period From",
        "period_to": "Period to",
        "amount": "Premium Amount (EGP)",
        "quarter_date": "Issue Date",
    },
    "RI Premium Data": {
        "period_from": "Period From",
        "period_to": "Period to",
        "amount": "RI Premium Amount (EGP)",
        "quarter_date": "RI Treaty Issue Date",
    },
    "Gross Claims Data": {
        "period_from": "Policy Issue Date",
        "period_to": "As at Date",
        "amount": "Amount Paid (EGP)",
        "quarter_date": "Policy Issue Date",
    },
    "RI Claims Data": {
        "period_from": "RI Treaty Issue Date",
        "period_to": "As at Date",
        "amount": "Amount Received from RI (EGP)",
        "quarter_date": "RI Treaty Issue Date",
    },
    "Gross Claims Data - OS": {
        "period_from": "Policy Issue Date",
        "period_to": "As at Date",
        "amount": "Amount Paid (EGP)",
        "quarter_date": "Policy Issue Date",
    },
    "RI Claims Data - OS": {
        "period_from": "RI Treaty Issue Date",
        "period_to": "As at Date",
        "amount": "Amount Received from RI (EGP)",
        "quarter_date": "RI Treaty Issue Date",
    },
}

def _parse_dates_wide_range(raw):
    """
    Same fix as app.py's identically-named helper -- recovers validly-
    formatted dates that fall outside pandas' datetime64[ns] range (before
    1677-09-21 or after 2262-04-11). IFRS17 sheets commonly use far-future
    placeholder dates for open-ended/perpetual treaty periods (e.g.
    31/12/2275 in "Period to"), and depending on the pandas version
    installed, pd.to_datetime(errors='coerce') silently turns those into
    NaT -- indistinguishable from a genuinely malformed cell -- which is
    exactly why correctly-formatted dates were being reported as "Invalid
    date format". Returns an object-dtype Series of plain datetime.date
    values (never pandas Timestamp) so mixed fast-path/fallback values
    compare safely against each other in the cross-field date rules below.
    """
    fast = pd.to_datetime(raw, format="mixed", dayfirst=True, errors="coerce")
    if getattr(fast.dt, "tz", None) is not None:
        fast = fast.dt.tz_localize(None)
    parsed = fast.map(lambda ts: ts.date() if pd.notna(ts) else pd.NaT)

    needs_retry = (raw != "") & fast.isna()
    for idx in raw.index[needs_retry]:
        try:
            dt_val = _dateutil_parser.parse(raw[idx], dayfirst=True)
            parsed.at[idx] = _pydate(dt_val.year, dt_val.month, dt_val.day)
        except (ValueError, OverflowError, TypeError):
            pass  # genuinely invalid -- stays NaT
    return parsed


def _format_date_series(parsed):
    """dd/mm/yyyy formatting for a parsed (object-dtype date) Series --
    replaces `.dt.strftime('%Y-%m-%d')`."""
    return parsed.map(lambda d: d.strftime('%Y-%m-%d') if pd.notna(d) else d)


def _year_series(parsed):
    """Elementwise .year -- replaces `.dt.year`."""
    return parsed.map(lambda d: d.year if pd.notna(d) else None)


def _month_series(parsed):
    """Elementwise .month -- replaces `.dt.month`."""
    return parsed.map(lambda d: d.month if pd.notna(d) else None)


def _column_kind(col_name):
    if col_name in YEAR_NUMBER_COLUMNS:
        return "year"
    lower = col_name.lower()
    if "date" in lower or col_name in ["Period From", "Period to"]:
        return "date"
    if "amount" in lower:
        return "amount"
    return "text"

def mapping_is_complete(sheet_type, mapping):
    """True if every expected header for sheet_type has a non-empty mapped value."""
    if not mapping:
        return False
    expected_headers = IFRS17_SHEET_SCHEMAS.get(sheet_type, [])
    if not expected_headers:
        return False
    return all((mapping.get(h) or "").strip() for h in expected_headers)


def lob_mapping_is_complete(lob_mapping):
    """True if every canonical LOB has a non-empty 'actual value used in the
    file' entry. Mirrors mapping_is_complete()'s all-or-nothing gate, just
    keyed by canonical LOB instead of by schema column."""
    if not lob_mapping:
        return False
    return all((lob_mapping.get(lob) or "").strip() for lob in sorted(VALID_LOBS))


def remap_lob_values(df, lob_mapping):
    """
    LOB Detailed Mapping (Step 3) lets the user tell us which text their own
    file actually uses for each canonical LOB (e.g. their export writes
    "Motor Comp" instead of "MOTOR_COMPREHENSIVE"). lob_mapping is
    {canonical_lob: actual_value_in_file}. This builds the reverse,
    case-insensitive lookup and rewrites every "LOB Detailed" cell that
    matches one of those actual values to its canonical form -- run once on
    the whole (already header-remapped) dataframe before validation, so the
    existing "LOB Detailed must be one of the allowed values" /
    "must match IFRS Class" rules run completely unchanged. Values that don't
    match any mapped entry are left untouched, so genuinely invalid LOB text
    is still caught by those rules.

    df is expected in the same shape remap_uploaded_headers() produces:
    integer positional columns, with df.iloc[0] holding the canonical header
    names as data (not a real pandas header row).
    """
    if df is None or df.empty or not lob_mapping:
        return df

    reverse = {}
    for canonical, actual in lob_mapping.items():
        actual_clean = str(actual).strip()
        if actual_clean:
            reverse[actual_clean.lower()] = canonical
    if not reverse:
        return df

    header_cells = [str(v).strip() for v in df.iloc[0].tolist()]
    if "LOB Detailed" not in header_cells:
        return df
    col_pos = header_cells.index("LOB Detailed")

    df = df.copy()
    body_index = df.index[1:]

    def _map_val(v):
        return reverse.get(str(v).strip().lower(), v)

    df.loc[body_index, col_pos] = df.loc[body_index, col_pos].map(_map_val)
    return df


def remap_uploaded_headers(df, sheet_type, header_mapping):
    """
    Header Mapping (Step 2) lets the user tell us, per expected schema column,
    which header name their own source file actually uses for it (e.g. their
    export calls it "Policy No." instead of "Policy Number"). This takes the
    raw uploaded dataframe (header=None, so df.iloc[0] is the file's real
    header row) plus that {expected_header: actual_header_in_file} mapping,
    and rebuilds a dataframe whose header row is the canonical
    IFRS17_SHEET_SCHEMAS[sheet_type] order -- so the existing exact-match
    validation in validate_ifrs17_dataframe can run completely unchanged.

    Returns (remapped_df, error_message). error_message is None on success.
    """
    expected_headers = IFRS17_SHEET_SCHEMAS[sheet_type]

    if df is None or df.empty:
        return None, "The uploaded file is empty."

    actual_header_row = [str(v).strip() for v in df.iloc[0].tolist()]
    # First matching column wins if the file happens to repeat a header name.
    position_by_lower_name = {}
    for idx, cell in enumerate(actual_header_row):
        key = cell.lower()
        if key not in position_by_lower_name:
            position_by_lower_name[key] = idx

    col_positions = []
    problems = []
    for expected in expected_headers:
        mapped_name = (header_mapping.get(expected) or "").strip()
        if not mapped_name:
            problems.append(f"'{expected}' has no mapped header")
            continue
        idx = position_by_lower_name.get(mapped_name.lower())
        if idx is None:
            problems.append(f"'{expected}' is mapped to '{mapped_name}', which was not found in the uploaded file's header row")
            continue
        col_positions.append(idx)

    if problems:
        return None, "Header mapping problem(s): " + "; ".join(problems) + "."

    # Reorder/select columns in one vectorized pandas operation instead of a
    # pure-Python nested loop over every row (the previous version rebuilt
    # the whole file as Python lists -- O(rows x columns) in the interpreter,
    # which is real, avoidable overhead at hundreds of thousands of rows;
    # Custom validation never pays this cost since it has no header-mapping
    # feature at all).
    body = df.iloc[1:].reset_index(drop=True)
    max_needed = max(col_positions) + 1 if col_positions else 0
    # Defensive padding for a ragged source (a row genuinely shorter than the
    # rest) -- mirrors the old per-row "row[i] if i < len(row) else ''"
    # fallback, just applied to the whole column at once instead of per row.
    if body.shape[1] < max_needed:
        for extra_col in range(body.shape[1], max_needed):
            body[extra_col] = ""
    reordered = body.iloc[:, col_positions].copy()
    reordered.columns = range(len(expected_headers))
    header_row_df = pd.DataFrame([list(expected_headers)])
    remapped_df = pd.concat([header_row_df, reordered], ignore_index=True)
    return remapped_df, None


def read_ifrs17_upload_dataframe(source, filename_lower, sheet_name=None):
    """
    Reads the uploaded file. For Excel files, if sheet_name is provided, 
    it tries to read that specific sheet. .xlsb (Excel Binary Workbook) is
    read via the 'pyxlsb' engine -- requires the `pyxlsb` package
    (pip install pyxlsb); a missing package surfaces as a clear ImportError
    from pandas rather than a silent misread.
    """
    engine = "pyxlsb" if filename_lower.endswith(".xlsb") else None
    if filename_lower.endswith(".csv"):
        df = pd.read_csv(source, header=None)
    else:
        # For Excel, we check if the requested sheet exists
        if sheet_name:
            xl = pd.ExcelFile(source, engine=engine)
            if sheet_name in xl.sheet_names:
                df = pd.read_excel(xl, sheet_name=sheet_name, header=None)
            else:
                # Fallback to first sheet if not found, or could raise error
                df = pd.read_excel(xl, sheet_name=0, header=None)
        else:
            df = pd.read_excel(source, header=None, engine=engine)
    return df.fillna("")

def validate_ifrs17_dataframe(df, sheet_type, date_from=None, date_to=None, header_mapping=None):
    """
    date_from/date_to (datetime.date, inclusive) replace the old
    selected_quarter flag entirely (requirement #1/#4): rather than flagging
    rows whose Issue Date falls outside the chosen period as errors, rows
    outside [date_from, date_to] are filtered OUT of validation altogether --
    they're simply not part of what's being validated this run. Returns the
    row count BEFORE that filter (raw_row_count) and AFTER it
    (filtered_row_count) so the caller can report "N of M rows selected for
    this period" per requirement #4.
    """
    expected_headers = IFRS17_SHEET_SCHEMAS[sheet_type]
    rules = IFRS17_RULES[sheet_type]
    required_cols = REQUIRED_COLUMNS_PER_SHEET.get(sheet_type, [])
    header_mapping = header_mapping or {}

    def display_header(column):
        mapped = str(header_mapping.get(column) or "").strip()
        if mapped and mapped.casefold() != column.casefold():
            return f"{mapped} (mapped to {column})"
        return column

    first_row_cells = [str(v).strip() for v in df.iloc[0].tolist()]
    header_valid = (
        first_row_cells == expected_headers
        and len(first_row_cells) == len(set(first_row_cells))
    )

    if not header_valid:
        missing = [c for c in expected_headers if c not in first_row_cells]
        extra = [c for c in first_row_cells if c not in expected_headers]
        detail = f"Header does not match the '{sheet_type}' template."
        if missing:
            detail += f" Missing: {', '.join(missing)}."
        if extra:
            detail += f" Unexpected: {', '.join(extra)}."
        return False, False, [], [], detail, [], 0, 0

    body_full = df.iloc[1:].reset_index(drop=True).copy()
    body_full.columns = expected_headers
    # --- CHANGED: Fill all NaN values with empty string up front ---
    body_full = body_full.fillna("").astype(str).apply(lambda s: s.str.strip())

    str_cols = {h: body_full[h].astype(str).str.strip() for h in expected_headers}

    # Ignore rows that are completely empty across all validated columns --
    # a row with ANY non-empty cell must go through full validation.
    any_data_mask = pd.DataFrame(str_cols).ne("").any(axis=1)
    body = body_full[any_data_mask].reset_index(drop=True)
    # Re-evaluate str_cols for the remaining active rows
    str_cols = {h: body[h].astype(str).str.strip() for h in expected_headers}
    raw_row_count = len(body)

    # --- Period filter (requirement #4) -----------------------------------
    # Rows whose Issue Date (the sheet's date-of-record column) falls outside
    # the Step 1 From/To range are excluded from validation entirely -- not
    # flagged as errors, just not part of this run's selected rows.
    if date_from is not None and date_to is not None and raw_row_count > 0:
        issue_col_for_filter = rules["issue_date_col"]
        period_parsed = _parse_dates_wide_range(str_cols[issue_col_for_filter])
        # _parse_dates_wide_range can come back as either an object Series of
        # python `date` values or (depending on pandas version) get silently
        # cast to datetime64 -- comparing a raw datetime64 Series directly
        # against a bare datetime.date raises "Invalid comparison between
        # dtype=datetime64[...] and date" on some pandas versions. Normalise
        # every value to a plain python date first so the comparison below
        # never depends on the Series' underlying dtype.
        def _as_plain_date(v):
            if v is None or (isinstance(v, float) and pd.isna(v)):
                return None
            try:
                if pd.isna(v):
                    return None
            except (TypeError, ValueError):
                pass
            if isinstance(v, _pydate) and type(v) is _pydate:
                return v
            date_fn = getattr(v, "date", None)
            if callable(date_fn):
                return date_fn()
            return v
        period_dates = period_parsed.map(_as_plain_date)
        in_period_mask = period_dates.map(
            lambda d: isinstance(d, _pydate) and date_from <= d <= date_to
        )
        body = body[in_period_mask].reset_index(drop=True)
        str_cols = {h: body[h].astype(str).str.strip() for h in expected_headers}
    filtered_row_count = len(body)
    n = filtered_row_count

    report_rows = []
    payload_accum = []

    if n == 0:
        return True, True, [], [], None, [], raw_row_count, filtered_row_count

    str_cols = {c: body[c].astype(str).str.strip() for c in expected_headers}
    row_errors = [[] for _ in range(n)]
    row_error_cols = [set() for _ in range(n)]

    def add_error(mask, message, cols):
        idxs = body.index[mask]
        if len(idxs) == 0:
            return
        col_list = [cols] if isinstance(cols, str) else list(cols)
        if isinstance(message, str):
            for i in idxs:
                row_errors[i].append(message)
                row_error_cols[i].update(col_list)
        else:
            for i in idxs:
                row_errors[i].append(message(i))
                row_error_cols[i].update(col_list)

    issue_col = rules["issue_date_col"]
    written_col = rules["written_date_col"]
    pfrom_col = rules["period_from_col"]
    pto_col = rules["period_to_col"]
    due_date_col = rules["due_date_col"]
    premium_col = rules["premium_col"]
    commission_col = rules["commission_col"]
    year_col = rules["year_check_col"]
    year_kind = rules["year_check_kind"]

    parsed_dates = {}

    for col in expected_headers:
        # Underwriting Year / RI Treaty Year (requirement #5) is auto-derived
        # from Issue Date's year below and always overwritten -- skip its
        # required/format checks here entirely rather than flagging a value
        # that's about to be replaced anyway.
        if year_kind == "number" and col == year_col:
            continue

        raw = str_cols[col]
        empty_mask = raw == ""
        is_required = col in required_cols

        # --- ADDED: Universal required column checker up front ---
        if is_required:
            add_error(empty_mask, f"Cell {col} is empty", col)

        # Specific rule for Premium/Commission columns: they must be numeric if present
        if col in [premium_col, commission_col]:
            numeric = pd.to_numeric(raw, errors="coerce")
            add_error((~empty_mask) & numeric.isna(), f"{col} must be a valid number", col)
            good = (~empty_mask) & numeric.notna()
            body.loc[good, col] = numeric[good].round(3).map(lambda v: f"{v:.3f}")

        # --- CHANGED: Restructured into an else-block (Removed 'continue' and redundant required-checks) ---
        else:
            kind = _column_kind(col)
            if kind == "date":
                parsed = _parse_dates_wide_range(raw)
                parsed_dates[col] = parsed
                add_error((~empty_mask) & parsed.isna(), f"Invalid date format in {col} (expected dd/mm/yyyy)", col)
                good = (~empty_mask) & parsed.notna()
                body.loc[good, col] = _format_date_series(parsed[good])

            elif kind == "amount":
                numeric = pd.to_numeric(raw, errors="coerce")
                add_error((~empty_mask) & numeric.isna(), f"{col} must be a valid number", col)
                good = (~empty_mask) & numeric.notna()
                body.loc[good, col] = numeric[good].round(3).map(lambda v: f"{v:.3f}")

            elif kind == "year":
                numeric = pd.to_numeric(raw, errors="coerce")
                add_error((~empty_mask) & numeric.isna(), f"{col} must be a valid year", col)
                good = (~empty_mask) & numeric.notna()
                body.loc[good, col] = numeric[good].astype(int).astype(str)

    # --- LOB Detailed Cross-checks ---
    lob_raw = str_cols["LOB Detailed"]
    ifrs_raw = str_cols["IFRS Class"]
    fra_col = "FRA Reporting Class"
    
    # Rule: LOB Detailed should be same with IFRS Class
    # --- CHANGED: Only trigger mismatch errors if both cells are NOT empty ---
    valid_comparison_mask = (lob_raw != "") & (ifrs_raw != "")
    add_error(valid_comparison_mask & (lob_raw != ifrs_raw), "LOB Detailed must match IFRS Class", ["LOB Detailed", "IFRS Class"])
    
    if fra_col in expected_headers:
        fra_raw = str_cols[fra_col]
        valid_fra_mask = (lob_raw != "") & (fra_raw != "")
        add_error(valid_fra_mask & (lob_raw != fra_raw), "LOB Detailed must match FRA Reporting Class", ["LOB Detailed", fra_col])
        
    # --- CHANGED: Only trigger invalid LOB checks if the cell is NOT empty ---
    invalid_lob = (lob_raw != "") & (~lob_raw.isin(VALID_LOBS))
    add_error(invalid_lob, "LOB Detailed must be one of the allowed values", "LOB Detailed")

    # --- Date Rules ---
    issue_parsed = parsed_dates.get(issue_col)
    written_parsed = parsed_dates.get(written_col)
    
    # Rule: Written Date must be before or equal Issue Date
    if issue_parsed is not None and written_parsed is not None:
        both = issue_parsed.notna() & written_parsed.notna()
        add_error(both & (written_parsed > issue_parsed),
                  f"{written_col} must be before or equal to {issue_col}", [written_col, issue_col])

    # Rule: Period From must be equal or after Issue Date
    if pfrom_col and issue_parsed is not None:
        pfrom_parsed = parsed_dates.get(pfrom_col)
        if pfrom_parsed is not None:
            both = pfrom_parsed.notna() & issue_parsed.notna()
            add_error(both & (pfrom_parsed < issue_parsed),
                      f"{pfrom_col} must be equal or after {issue_col}", [pfrom_col, issue_col])

    # Rule: Period to must be after Period From
    if pfrom_col and pto_col:
        pfrom_parsed = parsed_dates.get(pfrom_col)
        pto_parsed = parsed_dates.get(pto_col)
        if pfrom_parsed is not None and pto_parsed is not None:
            both = pfrom_parsed.notna() & pto_parsed.notna()
            add_error(both & (pto_parsed <= pfrom_parsed),
                      f"{pto_col} must be after {pfrom_col}", [pto_col, pfrom_col])

    # Rule: Premium/Commission Due Date must be equal to or after Issue Date
    if due_date_col and issue_parsed is not None:
        due_parsed = parsed_dates.get(due_date_col)
        if due_parsed is not None:
            both = due_parsed.notna() & issue_parsed.notna()
            add_error(
                both & (due_parsed < issue_parsed),
                f"{display_header(due_date_col)} must be on or after "
                f"{display_header(issue_col)}",
                [due_date_col, issue_col],
            )

    # Period filtering (which rows are even part of this run) now happens
    # up front against date_from/date_to -- see the filter applied right
    # after blank rows are dropped, above. There's no longer a per-row
    # "Issue Date must be in the selected quarter" check here.

    # Rule: Underwriting Year / RI Treaty Year auto-filled from Issue Date
    # (requirement #5); "As at Date" (claims sheets) still gets a mismatch
    # check rather than being overwritten, since it's a full date the user
    # enters, not a bare year meant to mirror Issue Date.
    if issue_parsed is not None:
        issue_year = _year_series(issue_parsed)
        if year_kind == "number":
            fillable = issue_parsed.notna()
            body.loc[fillable, year_col] = [
                str(y) for y in issue_year[fillable]
            ]
            body.loc[~fillable, year_col] = ""
        elif year_kind == "date":
            year_parsed = parsed_dates.get(year_col)
            if year_parsed is not None:
                year_parsed_year = _year_series(year_parsed)
                checkable = year_parsed.notna() & issue_parsed.notna()
                mismatch = checkable & (year_parsed_year != issue_year)
                add_error(mismatch, lambda i: (
                    f"{year_col} year ({year_parsed_year[i]}) does not match "
                    f"{issue_col} year ({issue_year[i]})"
                ), [year_col, issue_col])

    # --- Assemble output ---
    overall_valid = True
    error_columns_accum = []
    all_rows = body.values.tolist()
    for i, row_cells in enumerate(all_rows):
        spreadsheet_row_num = i + 2
        if row_errors[i]:
            overall_valid = False
            report_rows.append([f"INVALID(Row {spreadsheet_row_num}): Invalid data located -> {', '.join(row_errors[i])}"] + row_cells)
        else:
            report_rows.append(["VALID"] + row_cells)
        error_columns_accum.append(sorted(row_error_cols[i]))
        payload_accum.append({h: v for h, v in zip(expected_headers, row_cells)})

    return True, overall_valid, report_rows, payload_accum, None, error_columns_accum, raw_row_count, filtered_row_count