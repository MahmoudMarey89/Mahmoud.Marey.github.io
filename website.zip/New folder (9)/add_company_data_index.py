"""
add_company_data_index.py
--------------------------
One-time migration: adds a basic index to `company_data` on
(company_id, component_name, data_year).

Every query in app.py that loads a company's data -- the Welcome/Overview
KPIs, the Dashboard table, exports -- filters by company_id first (often
narrowed further by component_name/data_year). Without an index on those
columns, MySQL has to scan the ENTIRE company_data table (every company's
every row) to find the ones that match, which gets dramatically slower as
the table grows. This is a big part of why opening a company with a lot of
imported data can be slow to load: the query behind it can't use an index
to jump straight to that company's rows.

This is purely additive -- adding an index doesn't change any existing
data or behavior, only how fast MySQL can filter it. Safe to run more than
once (checks INFORMATION_SCHEMA first, skips if the index already exists).

Usage:
    python3 add_company_data_index.py

Uses the same connection settings as your other migration scripts /
app.py's get_db_connection(). Edit the CONNECTION block below if your
credentials differ.
"""
import pymysql

CONNECTION = dict(
    host='localhost',
    user='admin',
    password='Admin123',
    database='corporate_portal',
    cursorclass=pymysql.cursors.DictCursor,
)

INDEX_NAME = 'idx_company_data_lookup'
INDEX_COLUMNS = ['company_id', 'component_name', 'data_year']


def index_exists(cursor, table, index_name):
    cursor.execute(
        """SELECT COUNT(*) AS cnt FROM information_schema.statistics
           WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s""",
        (table, index_name)
    )
    return cursor.fetchone()['cnt'] > 0


def main():
    conn = pymysql.connect(**CONNECTION)
    try:
        with conn.cursor() as cursor:
            if index_exists(cursor, 'company_data', INDEX_NAME):
                print(f"[skip]   company_data.{INDEX_NAME} already exists")
            else:
                col_list = ", ".join(f"`{c}`" for c in INDEX_COLUMNS)
                sql = f"ALTER TABLE `company_data` ADD INDEX `{INDEX_NAME}` ({col_list})"
                print(f"[create] {sql}")
                print("(this can take a while on a large existing table -- MySQL has "
                      "to build the index over every current row; the table stays "
                      "readable while it does, on most engines/versions)")
                cursor.execute(sql)
        conn.commit()
        print("\nDone.")
    finally:
        conn.close()


if __name__ == '__main__':
    main()
