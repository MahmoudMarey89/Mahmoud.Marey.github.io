/*
 * theme-init.js
 * --------------
 * Applies the person's saved site theme to <html> as early as possible on
 * every page -- including ones with no sidebar (login, change-password,
 * the global Welcome workspace grid, Site Administration) -- so the nine
 * Luxury palettes in site.css apply everywhere, not just on company pages
 * that happen to include company_sider.html.
 *
 * Include this with a plain <script src="..."> tag right after site.css's
 * <link> in every page's <head>, before any visible body content, so the
 * data-site-theme attribute is set before first paint (no flash of the
 * default theme). The theme picker itself (swatches, click handling)
 * still lives in company_sider.html, since only company pages have room
 * for it in the footer -- this file only restores whatever was last
 * chosen there.
 */
(function () {
    var STORAGE_KEY = 'siteTheme';
    var theme = 'lux';
    try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved) theme = saved;
    } catch (e) {
        /* storage disabled -- fall back to the default theme */
    }
    document.documentElement.setAttribute('data-site-theme', theme);
})();
