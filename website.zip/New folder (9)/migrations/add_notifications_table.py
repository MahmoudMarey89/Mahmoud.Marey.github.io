"""
Adds the `notifications` table used by the site-admin notification bell:
one row is written every time a 'client' role user uploads a file via
/<company_slug>/client-overview/upload (see create_upload_notification() in
app.py). Safe to re-run -- uses CREATE TABLE IF NOT EXISTS.

Usage:
    python3 migrations/add_notifications_table.py
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app, get_db_connection  # noqa: E402


def run():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS notifications (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    category VARCHAR(50) NOT NULL,
                    filename VARCHAR(255) NOT NULL,
                    message VARCHAR(500) NOT NULL,
                    is_read TINYINT(1) NOT NULL DEFAULT 0,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT fk_notifications_company
                        FOREIGN KEY (company_id) REFERENCES companies(id)
                        ON DELETE CASCADE,
                    INDEX idx_notifications_is_read (is_read),
                    INDEX idx_notifications_created_at (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
        conn.commit()
        print("notifications table is present (created if it wasn't already).")
    finally:
        conn.close()


if __name__ == '__main__':
    with app.app_context():
        run()
