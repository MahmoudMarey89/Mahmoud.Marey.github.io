"""
add_upr_calculations_table.py
-----------------------------
One-time migration: creates the upr_calculations table backing the Custom
and IFRS 17 UPR Calculation tabs.

One row per company_data row that's been through a UPR Calculation Search +
Save: row_id is company_data.id itself (PRIMARY KEY, FOREIGN KEY, ON DELETE
CASCADE) rather than a separate surrogate id, so re-running Search + Save
for the same Data Type/Year/Quarter later (e.g. after new rows were
imported, or to refresh the numbers) upserts via
INSERT ... ON DUPLICATE KEY UPDATE instead of accumulating duplicate
calculation rows for the same underlying data row. Deleting the underlying
company_data row cascades and removes its calculation automatically, so a
deleted data row never leaves an orphaned calculation behind.

Safe to run more than once. If the legacy pwd_calculations table exists and
upr_calculations does not, it is renamed so existing saved calculations are
preserved.

Usage:
    python3 migrations/add_upr_calculations_table.py

Uses the same connection settings as app.py's get_db_connection(). Picks up
DB_HOST/DB_USER/DB_PASSWORD/DB_NAME from the environment the same way
add_password_policy_column.py and add_performance_indexes.py do.
"""
import os
import pymysql

CONNECTION = dict(
    host=os.environ.get('DB_HOST', 'localhost'),
    user=os.environ.get('DB_USER', 'admin'),
    password=os.environ.get('DB_PASSWORD', 'Admin123'),
    database=os.environ.get('DB_NAME', 'corporate_portal'),
    cursorclass=pymysql.cursors.DictCursor,
)


def table_exists(cursor, table):
    cursor.execute(
        """SELECT COUNT(*) AS cnt FROM information_schema.tables
           WHERE table_schema = DATABASE() AND table_name = %s""",
        (table,)
    )
    return cursor.fetchone()['cnt'] > 0


def main():
    conn = pymysql.connect(**CONNECTION)
    try:
        with conn.cursor() as cursor:
            if table_exists(cursor, 'upr_calculations'):
                print("[skip]   upr_calculations already exists")
            elif table_exists(cursor, 'pwd_calculations'):
                print("[rename] pwd_calculations -> upr_calculations")
                cursor.execute("RENAME TABLE pwd_calculations TO upr_calculations")
            else:
                sql = """
                CREATE TABLE `upr_calculations` (
                    `row_id` INT NOT NULL,
                    `company_id` INT NOT NULL,
                    `component_name` VARCHAR(255) NOT NULL,
                    `data_year` VARCHAR(10) NOT NULL,
                    `quarter` VARCHAR(10) NOT NULL,
                    `quarter_end_date` DATE NOT NULL,
                    `exposure_days` INT NULL,
                    `unearned_exposure_days` INT NULL,
                    `earned_premium` DECIMAL(18,3) NULL,
                    `unearned_premium` DECIMAL(18,3) NULL,
                    `calculated_by` INT NULL,
                    `calculated_at` DATETIME NOT NULL,
                    PRIMARY KEY (`row_id`),
                    CONSTRAINT `fk_upr_calc_company_data`
                        FOREIGN KEY (`row_id`) REFERENCES `company_data` (`id`)
                        ON DELETE CASCADE,
                    INDEX `idx_upr_calc_lookup` (`company_id`, `component_name`, `data_year`, `quarter`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """
                print("[create] upr_calculations table")
                cursor.execute(sql)
        conn.commit()
        print("\nDone. UPR Calculation Save will now persist into upr_calculations.")
    finally:
        conn.close()


if __name__ == '__main__':
    main()