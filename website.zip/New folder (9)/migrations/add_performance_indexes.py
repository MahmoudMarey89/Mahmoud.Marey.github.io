"""
add_performance_indexes.py
---------------------------
One-time migration: adds the database indexes the Insurance Portal app relies
on for fast filtering. Without these, MySQL has to scan the ENTIRE
company_data table (every company's rows, not just yours) on every Dashboard
load, every Import, and every Overview visit -- which is exactly why those
pages get slower and slower as more data is imported over time.

This script is safe to run more than once: it checks INFORMATION_SCHEMA
first and only creates an index if it doesn't already exist.

Usage:
    python3 add_performance_indexes.py

Uses the same connection settings as app.py's get_db_connection(). Edit the
CONNECTION block below if your credentials differ.
"""
import pymysql

# --- Same connection settings as get_db_connection() in app.py ---
CONNECTION = dict(
    host='localhost',
    user='admin',
    password='Admin123',
    database='corporate_portal',
    cursorclass=pymysql.cursors.DictCursor,
)

# table -> list of (index_name, [columns])
INDEXES_TO_ENSURE = {
    'company_data': [
        # Every Dashboard / Overview / Export query filters by company_id,
        # and most also filter by component_name + data_year together.
        ('idx_company_data_company_id', ['company_id']),
        ('idx_company_data_company_type_year', ['company_id', 'component_name', 'data_year']),
    ],
    'history_log': [
        # History Log page: WHERE company_id = ... ORDER BY timestamp DESC
        ('idx_history_log_company_timestamp', ['company_id', 'timestamp']),
    ],
    'group_company_access': [
        ('idx_gca_group_id', ['group_id']),
        ('idx_gca_company_id', ['company_id']),
    ],
    'user_groups': [
        ('idx_user_groups_user_id', ['user_id']),
        ('idx_user_groups_group_id', ['group_id']),
    ],
}


def index_exists(cursor, table, index_name):
    cursor.execute(
        """SELECT COUNT(*) AS cnt FROM information_schema.statistics
           WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s""",
        (table, index_name)
    )
    return cursor.fetchone()['cnt'] > 0


def main():
    conn = pymysql.connect(**CONNECTION)
    try:
        with conn.cursor() as cursor:
            for table, indexes in INDEXES_TO_ENSURE.items():
                for index_name, columns in indexes:
                    if index_exists(cursor, table, index_name):
                        print(f"[skip]   {table}.{index_name} already exists")
                        continue
                    col_list = ", ".join(f"`{c}`" for c in columns)
                    sql = f"ALTER TABLE `{table}` ADD INDEX `{index_name}` ({col_list})"
                    print(f"[create] {sql}")
                    cursor.execute(sql)
        conn.commit()
        print("\nDone. Indexes are in place.")
    finally:
        conn.close()


if __name__ == '__main__':
    main()
