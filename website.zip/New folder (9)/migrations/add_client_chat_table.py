"""
Adds the `client_chat_messages` table used by the chat panel on
overview-client.html: one shared thread per company between the client role
and staff (admin/user) with access to that company. See get_chat_messages()/
add_chat_message() in app.py. Safe to re-run -- uses CREATE TABLE IF NOT
EXISTS.

Usage:
    python3 migrations/add_client_chat_table.py
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app, get_db_connection  # noqa: E402


def run():
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS client_chat_messages (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    sender_role ENUM('client', 'staff') NOT NULL,
                    sender_username VARCHAR(100) NOT NULL,
                    message VARCHAR(2000) NOT NULL,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT fk_chat_company
                        FOREIGN KEY (company_id) REFERENCES companies(id)
                        ON DELETE CASCADE,
                    INDEX idx_chat_company_id (company_id, id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            """)
        conn.commit()
        print("client_chat_messages table is present (created if it wasn't already).")
    finally:
        conn.close()


if __name__ == '__main__':
    with app.app_context():
        run()
