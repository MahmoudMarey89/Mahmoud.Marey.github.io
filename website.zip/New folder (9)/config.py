import os


def _require_env(name):
    """
    Fetches a required secret from the environment with NO fallback to a
    hardcoded default. Previously SECRET_KEY fell back to a literal value
    baked into this file -- meaning anyone who ever saw this source (or a
    git history, a backup, a support screenshot) had the production secret
    key, permanently, whether or not the env var was ever actually set on
    the server. Failing loudly here at startup is deliberate: an app that
    won't start without its secrets configured is safer than one that
    silently runs with a known one.
    """
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(
            f"Required environment variable '{name}' is not set. "
            f"See .env.example for what needs to be configured before starting the app."
        )
    return value


class Config:
    SECRET_KEY = _require_env('SECRET_KEY')

    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_USER = os.environ.get('DB_USER', 'admin')
    DB_PASSWORD = _require_env('DB_PASSWORD')
    DB_NAME = os.environ.get('DB_NAME', 'corporate_portal')

    SQLALCHEMY_DATABASE_URI = f'mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}/{DB_NAME}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    SESSION_COOKIE_HTTPONLY = True
    # Set SESSION_COOKIE_SECURE = True once the site is served over HTTPS --
    # left False here since the app was still being accessed over plain
    # http://192.168.x.x during development; a Secure cookie simply won't be
    # sent at all over a non-TLS connection, which would break login rather
    # than protect it until HTTPS is actually in front of this.
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
    SESSION_COOKIE_SAMESITE = 'Lax'

    MAX_CONTENT_LENGTH = 500 * 1024 * 1024 * 1024  # 500GB file upload safety limit
