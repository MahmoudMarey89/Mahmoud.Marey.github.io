# IFRS17 Fulfil / LOB Mapping / Period Filter update

## What changed
1. **Fulfil Data (Step 1)** — Year+Quarter replaced entirely by a From/To
   date range (calendar pickers). `.xlsb` is now accepted here (and in
   Step 4's main upload) alongside `.xlsx/.xls/.csv`. After fulfilling, a
   small breakdown table shows which (year, quarter) control-totals rows
   were summed to build the total, since the DATA sheet itself is still
   only granular to quarter level.
2. **Header Mapping (Step 2)** — unchanged.
3. **LOB Detailed Mapping (Step 3, new)** — one mapping, shared across all
   6 sheet types (LOB Detailed's allowed values are the same everywhere),
   saved in `session['ifrs17_lob_mapping']`. Gates Step 4 the same way
   Header Mapping does.
4. **Period filter (requirement #4)** — rows whose Issue Date (or its
   per-sheet equivalent) falls outside the fulfilled From/To range are
   filtered OUT of validation entirely, not flagged as errors. The results
   page shows "X of Y rows in the uploaded file fell inside this period."
5. **Underwriting Year / RI Treaty Year auto-fill** — no longer validated
   for a mismatch against Issue Date's year; it's now always overwritten
   with Issue Date's year. ("As at Date" on claims sheets is unchanged —
   still a mismatch check, not an overwrite, since it's a full date the
   user enters.)
6. **Per-column error summary** — new table: error count + % of selected
   rows per column, plus one combined "amount in error rows" figure using
   the sheet-type's amount grouping (Paid+Outstanding / Received+
   Outstanding-from-RI / Premium Amount alone).
7. **Post-validation actions** — "Download Validated Sheet (all rows)" and
   "Download Error Summary Report" are now available after every run
   (pass or fail), alongside the existing errors-only export and the
   Import-to-DB button (still gated on Differential = 0, unchanged).

## Deployment step you must not skip
`.xlsb` reading needs the `pyxlsb` package:
```
pip install pyxlsb
```
Add it to whatever requirements file/venv you deploy from — it isn't in
this bundle's existing dependency list.

## Known trade-offs / assumptions (flagging, not hiding)
- **`data_year` (DB partition key)** is now derived from the From date's
  year rather than typed in directly, since the Year+Quarter inputs are
  gone. A range that spans two calendar years still validates correctly
  against the real dates, but is tagged/stored under the From date's year.
  If you need explicit multi-year storage splitting, that's a follow-up.
- **Control-totals lookup for a date range** that doesn't line up with a
  clean quarter still pulls that whole quarter's total from the DATA
  sheet (there's nothing finer-grained in that workbook format to draw
  on). The breakdown table makes this visible rather than silent.
- **LOB Detailed Mapping is global**, not per sheet type — deliberate,
  since the allowed LOB values are identical across all 6 sheets.
- Removed the old non-streaming `/validate-ifrs17` POST route
  (`validate_ifrs17()`), which the UI hadn't called since the SSE
  streaming flow was built. Keeping it would have meant either a second,
  divergent implementation of the new period-filter/auto-fill/LOB-mapping
  logic, or a route that silently breaks. Removal is the safer option.

## Files in this delivery
- `app.py` — full file
- `ifrs17_engine.py` — full file
- `templates/company/data-validation-ifrs17.html` — full file

Everything else in your uploaded project (Custom Validation, UPR, client
portal, site admin, etc.) is untouched.
