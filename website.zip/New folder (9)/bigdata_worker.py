"""
bigdata_worker.py
------------------
Standalone background worker for the big-data (20M-100M row) bulk import
pipeline. Runs as its own OS process (see bigdata_worker.service), completely
decoupled from the Flask/gunicorn request-response cycle, so it doesn't
matter how many gunicorn workers app.py runs under and no HTTP request is
ever held open while a 100M-row import runs.

What it does, per job:
  1. Polls `import_jobs` for status='queued', atomically claims one.
  2. For each staged file (import_job_files, in file_index order):
       a. Opens it WITHOUT loading the whole thing into memory:
          - .xlsx/.xls: openpyxl in read_only mode, iterating rows.
          - .csv: pandas.read_csv(..., chunksize=CHUNK_SIZE).
       b. Validates row 0 against EXPECTED_HEADERS (same header check as
          the small-file flow) -- if it fails, the whole file is marked
          'error' and the worker moves to the next file.
       c. Streams the body in CHUNK_SIZE-row chunks through
          validation_core.validate_chunk() -- the exact same column rules
          as the existing small-file validator, just applied per-chunk
          instead of to one giant DataFrame.
       d. Valid rows are appended to a tab-delimited staging file on disk;
          every STAGE_FLUSH_ROWS rows (or at end of file) that staging file
          is bulk-loaded into `company_data` via LOAD DATA LOCAL INFILE and
          then cleared -- this is what makes multi-million-row loads take
          minutes instead of hours.
       e. Invalid rows are appended to a capped error-report file (first
          ERROR_SAMPLE_CAP rows kept verbatim; the total invalid count is
          still tracked exactly even past the cap).
       f. import_jobs.rows_processed / rows_valid / rows_invalid /
          files_done are updated after every chunk, so the UI's polling
          endpoint always reflects live progress.
  3. Marks the job 'done' (or 'error' with a message) when finished.

Run it as a long-lived service:
    python3 bigdata_worker.py
(see bigdata_worker.service for the systemd unit to keep it running)

Requires MySQL's local_infile to be enabled server-side -- see the note at
the end of migrations/add_bigdata_pipeline.py.
"""
import csv
import json
import os
import time
import traceback
from datetime import datetime

import pandas as pd
import pymysql
from openpyxl import load_workbook

from validation_core import (
    EXPECTED_HEADERS, header_is_valid, header_error_message, validate_chunk,
)

# --- Connection: same credentials as app.py's get_db_connection() ----------
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_USER = os.environ.get('DB_USER', 'admin')
DB_PASSWORD = os.environ.get('DB_PASSWORD')  # required, no hardcoded fallback
DB_NAME = os.environ.get('DB_NAME', 'corporate_portal')

if not DB_PASSWORD:
    raise RuntimeError(
        "DB_PASSWORD environment variable is not set. "
        "bigdata_worker.service should load the same environment file app.py uses."
    )

CHUNK_SIZE = 200_000          # rows validated together as one DataFrame
STAGE_FLUSH_ROWS = 500_000    # rows accumulated before one LOAD DATA INFILE call
ERROR_SAMPLE_CAP = 50_000     # verbatim error rows kept per job (count stays exact past this)
POLL_INTERVAL_SECONDS = 5

ERROR_REPORTS_DIR = '/u01/data/site/import_error_reports'
STAGING_DIR = '/u01/data/site/import_staging'
os.makedirs(ERROR_REPORTS_DIR, exist_ok=True)
os.makedirs(STAGING_DIR, exist_ok=True)


def get_conn():
    return pymysql.connect(
        host=DB_HOST, user=DB_USER, password=DB_PASSWORD, database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor,
        local_infile=True,
    )


# --- Staging-file field escaping for LOAD DATA LOCAL INFILE -----------------
# FIELDS TERMINATED BY '\t' ESCAPED BY '\\' LINES TERMINATED BY '\n'
def _escape_field(value):
    if value is None:
        return ''
    s = str(value)
    s = s.replace('\\', '\\\\').replace('\t', '\\t').replace('\n', '\\n').replace('\r', '\\r')
    return s


def _to_iso_date(ddmmyyyy):
    """Converts the 'dd/mm/yyyy' strings validate_chunk() normalises dates to
    into 'yyyy-mm-dd' for the typed `issue_date` DATE column. Returns '' (->
    NULL via the LOAD DATA SET clause) if it can't parse."""
    if not ddmmyyyy:
        return ''
    try:
        return datetime.strptime(ddmmyyyy, '%d/%m/%Y').strftime('%Y-%m-%d')
    except ValueError:
        return ''


def build_staging_row(row_dict, company_id, component_name, data_year, uploaded_by):
    """One row_dict (validate_chunk's per-row output, keyed by
    EXPECTED_HEADERS) -> one tab-delimited line for the staging file, in the
    exact column order LOAD DATA INFILE expects (see LOAD_COLUMNS below)."""
    row_data_json = json.dumps(row_dict, default=str)
    fields = [
        company_id,
        component_name,
        data_year,
        row_data_json,
        uploaded_by,
        row_dict.get("Policy Number", ""),
        _to_iso_date(row_dict.get("Issue Date", "")),
        row_dict.get("LOB Detailed", ""),
        row_dict.get("Gross_RI", ""),
        row_dict.get("GROSS Premium Amount (EGP)", ""),
        row_dict.get("RI Premium Amount (EGP)", ""),
        row_dict.get("Financial Year Quarter", ""),
    ]
    return '\t'.join(_escape_field(f) for f in fields) + '\n'


LOAD_COLUMNS_SQL = """
(company_id, component_name, data_year, row_data, uploaded_by,
 policy_number, @issue_date_raw, lob_detailed, gross_ri,
 @gross_amt_raw, @ri_amt_raw, financial_year_quarter)
SET issue_date = NULLIF(@issue_date_raw, ''),
    gross_premium_amount = NULLIF(@gross_amt_raw, ''),
    ri_premium_amount = NULLIF(@ri_amt_raw, ''),
    created_at = NOW()
"""


def bulk_load(conn, staging_path):
    """One LOAD DATA LOCAL INFILE call for whatever's currently in
    staging_path. Caller is responsible for truncating/removing it after."""
    if not os.path.exists(staging_path) or os.path.getsize(staging_path) == 0:
        return
    # staging_path is constructed by this module (job id + file id), never
    # from user input, so a literal (escaped) path is safe here -- some
    # pymysql versions detect the LOCAL INFILE clause via a regex on the raw
    # query text, which is more reliable done this way than via a %s param.
    safe_path = staging_path.replace('\\', '\\\\').replace("'", "\\'")
    with conn.cursor() as cursor:
        sql = f"""
            LOAD DATA LOCAL INFILE '{safe_path}'
            INTO TABLE company_data
            FIELDS TERMINATED BY '\\t' ESCAPED BY '\\\\'
            LINES TERMINATED BY '\\n'
            {LOAD_COLUMNS_SQL}
        """
        cursor.execute(sql)
    conn.commit()


def update_job_progress(conn, job_id, **fields):
    if not fields:
        return
    set_clause = ", ".join(f"`{k}` = %s" for k in fields)
    params = list(fields.values()) + [job_id]
    with conn.cursor() as cursor:
        cursor.execute(f"UPDATE import_jobs SET {set_clause} WHERE id = %s", params)
    conn.commit()


def mark_file(conn, file_id, **fields):
    set_clause = ", ".join(f"`{k}` = %s" for k in fields)
    params = list(fields.values()) + [file_id]
    with conn.cursor() as cursor:
        cursor.execute(f"UPDATE import_job_files SET {set_clause} WHERE id = %s", params)
    conn.commit()


def iter_xlsx_chunks(path, chunk_size):
    """Yields (header_row_or_None, list_of_row_lists) without ever holding
    the whole sheet in memory -- openpyxl read_only mode streams rows one at
    a time off disk."""
    wb = load_workbook(filename=path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    header = None
    batch = []
    for row in ws.iter_rows(values_only=True):
        cells = ['' if v is None else v for v in row]
        if header is None:
            header = [str(c).strip() for c in cells]
            continue
        batch.append(cells)
        if len(batch) >= chunk_size:
            yield header, batch
            batch = []
    if batch or header is not None:
        yield header, batch
    wb.close()


def iter_csv_chunks(path, chunk_size):
    header_df = pd.read_csv(path, header=None, nrows=1)
    header = [str(c).strip() for c in header_df.iloc[0].tolist()]
    reader = pd.read_csv(path, header=None, skiprows=1, chunksize=chunk_size, dtype=str, keep_default_na=False)
    first = True
    for chunk_df in reader:
        yield (header if first else None), chunk_df.values.tolist()
        first = False
    if first:
        # file had a header row but zero data rows
        yield header, []


def process_file(conn, job, file_row):
    job_id = job['id']
    path = file_row['staged_path']
    filename_lower = path.lower()
    mark_file(conn, file_row['id'], status='processing')
    update_job_progress(conn, job_id, current_file_name=file_row['original_filename'])

    staging_path = os.path.join(STAGING_DIR, f"job{job_id}_file{file_row['id']}.tsv")
    error_report_path = job['error_report_path'] or os.path.join(ERROR_REPORTS_DIR, f"job_{job_id}_errors.jsonl")

    chunk_iter = iter_csv_chunks(path, CHUNK_SIZE) if filename_lower.endswith('.csv') \
        else iter_xlsx_chunks(path, CHUNK_SIZE)

    file_rows_valid = 0
    file_rows_invalid = 0
    file_rows_total = 0
    staged_since_flush = 0
    row_offset = 2  # spreadsheet row numbering: row 1 is the header

    header_checked = False

    with open(staging_path, 'a') as stage_f, open(error_report_path, 'a') as err_f:
        for header, rows in chunk_iter:
            if header is not None and not header_checked:
                header_checked = True
                is_valid, structure_ok, no_dupes = header_is_valid(header)
                if not is_valid:
                    msg = header_error_message(header, structure_ok, no_dupes)
                    mark_file(conn, file_row['id'], status='error', error_message=msg)
                    return 0, 0, 0

            if not rows:
                continue

            # The header row already passed header_is_valid() above, which
            # requires an exact column-name match against EXPECTED_HEADERS --
            # so every body row from this same rectangular sheet is expected
            # to have that same width. A row that doesn't (a ragged CSV line,
            # for instance) is flagged per-row rather than raised as an
            # exception.
            row_width = len(rows[0])
            col_width_ok = (row_width == len(EXPECTED_HEADERS))
            if col_width_ok:
                body = pd.DataFrame(rows, columns=EXPECTED_HEADERS)
            else:
                fixed_rows = [
                    (list(r) + [''] * len(EXPECTED_HEADERS))[:len(EXPECTED_HEADERS)] for r in rows
                ]
                body = pd.DataFrame(fixed_rows, columns=EXPECTED_HEADERS)
            body = body.astype(str).replace('None', '')

            n_valid, n_invalid, error_samples, valid_rows = validate_chunk(body, row_offset, col_width_ok)
            row_offset += len(rows)
            file_rows_total += len(rows)
            file_rows_valid += n_valid
            file_rows_invalid += n_invalid

            for row_dict in valid_rows:
                stage_f.write(build_staging_row(
                    row_dict, job['company_id'], job['component_name'], job['data_year'], job['created_by']
                ))
            staged_since_flush += len(valid_rows)

            if file_rows_invalid <= ERROR_SAMPLE_CAP:
                for sample in error_samples:
                    err_f.write(json.dumps(sample) + '\n')

            if staged_since_flush >= STAGE_FLUSH_ROWS:
                stage_f.flush()
                bulk_load(conn, staging_path)
                open(staging_path, 'w').close()  # truncate now that it's loaded
                staged_since_flush = 0

            update_job_progress(
                conn, job_id,
                rows_processed=job['rows_processed'] + file_rows_total,
                rows_valid=job['rows_valid'] + file_rows_valid,
                rows_invalid=job['rows_invalid'] + file_rows_invalid,
            )

    stage_f_size = os.path.getsize(staging_path) if os.path.exists(staging_path) else 0
    if stage_f_size > 0:
        bulk_load(conn, staging_path)
    if os.path.exists(staging_path):
        os.remove(staging_path)

    mark_file(
        conn, file_row['id'], status='done',
        rows_in_file=file_rows_total, rows_valid=file_rows_valid, rows_invalid=file_rows_invalid,
    )
    update_job_progress(conn, job_id, error_report_path=error_report_path)
    return file_rows_total, file_rows_valid, file_rows_invalid


def claim_next_job(conn):
    with conn.cursor() as cursor:
        cursor.execute("SELECT id FROM import_jobs WHERE status = 'queued' ORDER BY created_at LIMIT 1")
        row = cursor.fetchone()
        if not row:
            return None
        job_id = row['id']
        # Atomic claim: only succeeds if still 'queued' (guards against a
        # second worker process racing to pick up the same job).
        cursor.execute(
            "UPDATE import_jobs SET status = 'running', started_at = NOW() WHERE id = %s AND status = 'queued'",
            (job_id,)
        )
        if cursor.rowcount == 0:
            return None
    conn.commit()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM import_jobs WHERE id = %s", (job_id,))
        return cursor.fetchone()


def run_job(conn, job):
    job_id = job['id']
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT * FROM import_job_files WHERE job_id = %s ORDER BY file_index", (job_id,)
            )
            files = cursor.fetchall()

        files_done = 0
        for file_row in files:
            process_file(conn, job, file_row)
            files_done += 1
            update_job_progress(conn, job_id, files_done=files_done)
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM import_jobs WHERE id = %s", (job_id,))
                job = cursor.fetchone()

        update_job_progress(conn, job_id, status='done', finished_at=datetime.now())
    except Exception as e:
        update_job_progress(
            conn, job_id, status='error',
            error_message=f"{e}\n{traceback.format_exc()[-2000:]}",
            finished_at=datetime.now(),
        )


def main_loop():
    print("bigdata_worker: starting, polling import_jobs every "
          f"{POLL_INTERVAL_SECONDS}s...")
    while True:
        conn = get_conn()
        try:
            job = claim_next_job(conn)
            if job:
                print(f"bigdata_worker: claimed job {job['id']} "
                      f"({job['component_name']}, {job['data_year']})")
                run_job(conn, job)
                print(f"bigdata_worker: finished job {job['id']}")
        finally:
            conn.close()
        time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == '__main__':
    main_loop()
