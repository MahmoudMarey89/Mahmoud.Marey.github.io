# IFRS 17 Validation — Integration Guide

## What's in this delivery

| File | Where it goes | What it does |
|---|---|---|
| `welcome.html` | `templates/company/welcome.html` (replace) | Redesigned Company Welcome: two big buttons — **Custom Validation** and **IFRS 17 Validation** |
| `company_sider.html` | `templates/company/company_sider.html` (replace) | Sidebar now shows **no nav items** until a mode is picked on Welcome, then shows either the old Custom items or the new IFRS 17 items |
| `overview-ifrs17.html` | `templates/company/overview-ifrs17.html` (new) | Row counts + amount totals per IFRS 17 sheet type |
| `data-validation-ifrs17.html` | `templates/company/data-validation-ifrs17.html` (new) | Upload + validate + import UI for the 6 IFRS 17 sheet types |
| `ifrs17_engine.py` | `/u01/data/site/ifrs17_engine.py` (new, next to `app.py`) | Schema definitions for the 6 IFRS 17 sheets + a generic, column-name-driven validator |
| `app_py_patch.py` | **not a real module** — copy its 7 numbered blocks into your real `app.py` at the noted spots | New routes: mode switching, IFRS 17 overview/validation/import/export, and a small edit to `company_dashboard()` |

## Latest IFRS 17 additions

- `templates/company/upr-calculation-ifrs17.html` adds IFRS 17 UPR calculations for all six sub-sheets.
- The IFRS 17 sidebar now links to **UPR Calculation IFRS 17**.
- Each sub-sheet uses its own date, amount, and quarter header mapping from `IFRS17_UPR_FIELD_MAP` in `ifrs17_engine.py`.
- **Run Validation** and **Import to Production DB** now show upload/processing percentage and elapsed time.
- Validation results show the server-side validation duration, and the IFRS 17 dashboard confirms the completed database-import duration.
- Both UPR save routes now create `upr_calculations` automatically when it is missing, or rename the legacy `pwd_calculations` table without losing saved rows.
- Premium due dates may equal their issue date; validation messages show the uploaded header name when it differs from the IFRS 17 template name.
- Opening **Dashboard IFRS 17** now defaults to the first available IFRS 17 sheet (preferring Gross Premium Data) and latest saved year.
- Dashboard IFRS 17 and its exports now include saved Exposure, unEarned Exposure, Earned Amount, and unEarned Amount values from UPR Calculation IFRS 17.

## How the click-through now works

1. **Global Welcome grid** (`Welcome-site.html`, not included in what you sent me) → clicking a company already goes to `company_welcome` per your existing `get_accessible_companies` + that template. If yours currently links somewhere else (e.g. straight to Overview), point that link at `url_for('company_welcome', company_slug=...)` — that's the only change needed there, and I don't have that file to edit it directly for you.
2. **Company Welcome** (`welcome.html`) → shows only the hero + the two mode buttons + the sidebar with **no nav items yet** (just Company Welcome / Client Portal / Back / Logout).
3. Clicking **Custom Validation** → `GET /<slug>/set-mode/custom` → stores `session['mode_<slug>'] = 'custom'` → redirects to the existing `company_overview`. Sidebar now shows Overview / Dashboard / Data Validation / UPR Calculation / History Log, exactly as before.
4. Clicking **IFRS 17 Validation** → `GET /<slug>/set-mode/ifrs17` → stores `session['mode_<slug>'] = 'ifrs17'` → redirects to the new `company_overview_ifrs17`. Sidebar now shows Overview IFRS 17 / Dashboard IFRS 17 / Data Validation IFRS 17 / History Log.
5. Clicking **"↺ Switch Validation Mode"** in the sidebar footer (new) takes you back to Company Welcome, where both buttons are always available again.

This works identically for **existing** companies and **newly created** ones — the mode is a session flag per company slug, not anything stored against the company row, so no DB migration is needed for the mode-switching itself.

## What you still need to do

1. **Copy the 7 blocks in `app_py_patch.py`** into your real `app.py` at the noted locations (import, folder-tree extension, mode route, Welcome route note, Dashboard edit, Overview IFRS17 route, Data Validation IFRS17 routes).
2. **Copy `ifrs17_engine.py`** next to your real `app.py`.
3. **Run the one-off folder backfill** once, for existing companies, so they also get an `IFRS17/<sheet type>` folder tree on disk (new companies get it automatically via the extended `create_company_folder_tree`):
   ```
   python3 -c "from app import backfill_ifrs17_folders; backfill_ifrs17_folders()"
   ```
4. **No new DB tables or columns are needed.** IFRS 17 rows are stored in the same `company_data` table you already have, using the sheet name (e.g. `"Gross Premium Data"`) as `component_name` — same shape as today's `"Premium"` / `"Claim - Paid"` rows, just a different set of keys inside the JSON `row_data` blob.

## Deliberate simplifications — flag these back to me if you want them closed

- **Overview IFRS 17 KPIs are generic** (row count + sum of every `...Amount (EGP)` column per sheet), not the Loss Ratio / Expense Ratio / UW Result business logic your Custom Overview has — those formulas are specific to the Custom schema's `GROSS Premium Amount` / `GROSS Commission Amount` columns and don't have a stated IFRS 17 equivalent. Tell me the actual formulas (e.g. how Gross Premium, RI Premium, Gross Claims and RI Claims should combine into a net result) and I'll build a dedicated `compute_ifrs17_dashboard()` to match the polish of the existing Overview page.
- **Data Validation IFRS 17 is synchronous** (upload → wait → see results), not the live SSE progress bar the Custom validator has. That pattern (`validate_stream`) is built specifically for very large files; if your IFRS 17 sheets will regularly be in the hundreds of thousands of rows, say so and I'll port this to the same streaming pattern.
- **Every column in every IFRS 17 sheet is currently required** (no blanks allowed). If specific columns (e.g. `RI Treaty`, `CBUAE Reporting Class`) should be optional, tell me which and I'll add them to `OPTIONAL_COLUMNS` in `ifrs17_engine.py` — a one-line change per column.
- **Control-totals reconciliation** (the differential check on the Custom validator) isn't built for IFRS 17 yet, since I don't have a stated control-totals template for these 6 sheets.
- I don't have `Welcome-site.html` or the rest of `app.py` (helpers between the truncated line ranges), so I couldn't verify every existing reference by hand — please review the diff before deploying, and paste back any error you hit and I'll fix it directly.
